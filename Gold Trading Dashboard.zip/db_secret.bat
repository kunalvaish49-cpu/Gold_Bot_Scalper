@echo off
rem Local-only database credential - kept OUT of "Start Gold Trading Dashboard.bat"
rem (audit fix R-3, 2026-09-24) so the connection string isn't sitting in the main
rem launcher script, which is far more likely to be shared/zipped/copied to another
rem machine. This file is NOT required - if it's missing, the dashboard just falls
rem back to reading the EA's JSON files directly (Postgres persistence is optional).
set "DATABASE_URL=postgresql://postgres:GoldDash2026!@127.0.0.1:5432/gold_dashboard"
