# Market DNA — Usefulness & Calibration Audit (96,355-bar dataset)

**Mode:** AUDIT ONLY — no production code was modified in this task.
**Production EA:** KMIE_MarketDNA_Lite.mq5 (SHA256 `7FA81096C851A52FC15F927D2DF8C522F50D8B129B1ACD6C1FEC06FB5B6C1F4C`, unchanged throughout)
**Dataset:** 96,355 valid closed-M1 XAUUSD bars, **2026-06-01 00:00 → 2026-09-07 06:29 UTC** — real broker/terminal history, confirmed by `CopyRates()` itself (not assumed): first returned bar 2026-05-26 23:52:00, replay window trimmed to the requested 2026-06-01 start. 13x larger than the prior 7,382-bar audit.
**Replay tool:** `KMIE_MarketDNA_HistoricalReplay.mq5` — the same previously-validated, read-only, verbatim-evaluator-copy script (`Inp_MaxHistoryBars` raised 20,000→150,000 and `Inp_ReplayStart` extended to 2026-06-01 for this run only; no evaluator logic touched). 0 `INSUFFICIENT_HISTORY`, 0 look-ahead violations.

---

## A. Dataset Integrity

| | |
|---|---|
| Bars fetched by CopyRates() | 100,496 (oldest=2026-05-26 23:52:00) |
| Valid evaluations (after 2026-06-01 trim + 82-bar warm-up) | **96,355** |
| Insufficient-history bars | 0 |
| Look-ahead violations | 0/96,355 |
| Prior audit size | 7,382 bars |
| Scale factor | ~13.1x |

---

## B. 15-State Distribution (96,355 bars)

| DNA | Non-zero% | Mean | Median | P90 | P95 | Max | StdDev | ≥70% | ARGMAX Wins | ARGMAX% |
|---|---|---|---|---|---|---|---|---|---|---|
| STRONG_UPTREND | 100.0 | 34.7 | 34.8 | 54.3 | 59.5 | 83.8 | 14.9 | 0.71 | 1,500 | 1.56 |
| STRONG_DOWNTREND | 100.0 | 35.3 | 35.6 | 55.2 | 60.4 | 85.9 | 15.2 | 0.72 | 14,970 | 15.54 |
| UPTREND | 100.0 | 41.5 | 42.0 | 65.1 | 72.0 | 90.0 | 18.3 | 6.30 | 32,731 | 33.97 |
| DOWNTREND | 100.0 | 42.4 | 43.1 | 66.5 | 73.3 | 90.0 | 18.6 | 7.18 | 2,604 | 2.70 |
| WEAK_UPTREND | 31.5 | 15.9 | 0.0 | 54.2 | 58.7 | 82.0 | 23.9 | 0.31 | 944 | 0.98 |
| WEAK_DOWNTREND | 33.1 | 16.8 | 0.0 | 54.6 | 58.9 | 82.5 | 24.3 | 0.32 | 1,008 | 1.05 |
| PULLBACK_UP | 50.2 | 7.2 | 1.3 | 20.4 | 26.5 | 86.4 | 9.9 | 0.04 | 24 | 0.02 |
| PULLBACK_DOWN | 41.0 | 6.3 | 0.0 | 19.6 | 26.2 | 90.3 | 9.8 | 0.06 | 35 | 0.04 |
| VOLATILITY_EXPANSION | 100.0 | 19.8 | 14.9 | 43.7 | 58.0 | 100.0 | 17.1 | 2.02 | 969 | 1.01 |
| VOLATILITY_COMPRESSION | 100.0 | 39.7 | 41.8 | 61.4 | 65.9 | 89.0 | 17.6 | 2.08 | 1,996 | 2.07 |
| VOLATILE | 44.6 | 3.3 | 0.0 | 9.8 | 16.4 | 90.0 | 7.3 | 0.07 | 7 | 0.01 |
| EXPANSION | 100.0 | 26.1 | 16.8 | 64.2 | 65.8 | 100.0 | 23.2 | 4.01 | 14,680 | 15.24 |
| COMPRESSION | 100.0 | 35.9 | 27.0 | 74.6 | 79.8 | 96.0 | 23.2 | 11.45 | 24,482 | 25.41 |
| CHOPPY | 100.0 | 28.2 | 27.8 | 40.1 | 43.6 | 76.4 | 8.6 | 0.00 | 45 | 0.05 |
| NEUTRAL | 100.0 | 41.3 | 42.0 | 50.2 | 52.1 | 67.8 | 7.5 | 0.00 | 360 | 0.37 |

## C. ARGMAX Distribution (current calibration, production's own live basis)

Total wins sum to 96,355. UPTREND (34.0%), COMPRESSION (25.4%), STRONG_DOWNTREND (15.5%), EXPANSION (15.2%) dominate; all other 11 states share the remaining ~10%.

---

## D. Counterfactual Removal Matrix (96,355 bars)

| Candidate | Original Wins | % of All Bars Changed | Top Replacement | Replacement Share |
|---|---|---|---|---|
| UPTREND | 32,731 | 33.97% | STRONG_UPTREND | 77.3% |
| COMPRESSION | 24,482 | 25.41% | UPTREND | 51.3% |
| STRONG_DOWNTREND | 14,970 | 15.54% | DOWNTREND | 76.6% |
| EXPANSION | 14,680 | 15.24% | UPTREND | 50.6% |
| DOWNTREND | 2,604 | 2.70% | STRONG_DOWNTREND | 90.1% |
| VOLATILITY_COMPRESSION | 1,996 | 2.07% | UPTREND | 28.5% |
| STRONG_UPTREND | 1,500 | 1.56% | UPTREND | 83.1% |
| WEAK_DOWNTREND | 1,008 | 1.05% | STRONG_DOWNTREND | 31.9% |
| WEAK_UPTREND | 944 | 0.98% | UPTREND | 21.9% |
| VOLATILITY_EXPANSION | 969 | 1.01% | UPTREND | 27.2% |
| NEUTRAL | 360 | 0.37% | STRONG_DOWNTREND | 19.7% |
| CHOPPY | 45 | 0.05% | NEUTRAL | 46.7% |
| PULLBACK_DOWN | 35 | 0.04% | WEAK_UPTREND | 37.1% |
| PULLBACK_UP | 24 | 0.02% | UPTREND | 50.0% |
| VOLATILE | 7 | 0.01% | UPTREND | 57.1% |

**All figures closely reproduce the 7,382-bar audit** (e.g. STRONG_UPTREND→UPTREND 83.1% now vs 87% then; UPTREND→STRONG_UPTREND 77.3% vs 77%; DOWNTREND→STRONG_DOWNTREND 90.1% vs 93%) — the smaller sample was already representative, not a statistical fluke. No candidate's replacement concentration increased to a level that would newly justify removal. **No new removal evidence emerged at 13x scale.**

---

## E. Directional Symmetry

| Pair | Mean A | Mean B | Mean Diff | Correlation (mirror pair) |
|---|---|---|---|---|
| STRONG_UPTREND vs STRONG_DOWNTREND | 34.7 | 35.3 | 0.6 | −0.492 |
| UPTREND vs DOWNTREND | 41.5 | 42.4 | 0.9 | — |
| WEAK_UPTREND vs WEAK_DOWNTREND | 15.9 | 16.8 | 0.9 | −0.460 |
| PULLBACK_UP vs PULLBACK_DOWN | 7.2 | 6.3 | 0.9 | −0.468 |

Every pair's formula-level mean difference stays under 1 point at 96K-bar scale — **confirmed symmetric**. ARGMAX-win skew (e.g. STRONG_DOWNTREND 14,970 vs STRONG_UPTREND 1,500) reflects the real market path over this 3-month window, not a coded bias — consistent with the deterministic `PULLBACK_TEST29_volume_pip_preserved`/mirror-fixture tests, which remain unchanged and passing (verified in the live Experts log, unaffected by this audit).

---

## F. Volatility / Behavior Separation

| Pair | Correlation | Conclusion |
|---|---|---|
| VOLATILITY_EXPANSION ↔ EXPANSION | 0.278 | Distinct axes (range-magnitude vs candle-character) |
| VOLATILITY_COMPRESSION ↔ COMPRESSION | 0.311 | Distinct |
| VOLATILITY_EXPANSION ↔ VOLATILE | 0.606 | Related but VOLATILE adds a mandatory instability gate VOL_EXPANSION lacks |
| EXPANSION ↔ COMPRESSION | −0.767 | Correctly anti-correlated (opposite ends of one slope axis), never co-fire |
| CHOPPY ↔ NEUTRAL | 0.573 | Related (both favor low net displacement) but structurally distinct gates (alternation vs balance-with-movement) |

All consistent with the 7K-bar findings — no state's separation weakened at scale.

---

## G. Calibration Review

**Mechanism (Phase 1 audit, confirmed unchanged):** `CalibrateMarketDNAScores()` computes `z = (raw − g_dnaCalibMean[i]) / max(g_dnaCalibStdev[i], guard)`, then `calibrated = Clamp0to100(50 + z×15)`, for every one of the 18 enum slots, every tick. ARGMAX operates on this calibrated array. No other transformation exists.

| State | Current Calib (mean/stdev) | Real Mean | Real StdDev | Classification |
|---|---|---|---|---|
| **EXPANSION** | 50.0 / **3.0** | 26.1 | 23.2 | **CALIBRATION NEEDS REVIEW** — real mean sits 8 real-stdev away from assumed mean at only 3.0 assumed stdev; Z-score at the population mean is already −69.5, meaning the calibration was built for the OLD (now-replaced) formula's ~0.22 real stdev and never updated after the 2026-09-07 rebuild |
| **COMPRESSION** | 50.0 / **3.0** | 35.9 | 23.2 | **CALIBRATION NEEDS REVIEW** — same root cause, Z-score at mean is −20.3 |
| **PULLBACK_UP** | 50.0 / 15.0 | 7.2 | 9.9 | **CALIBRATION NEEDS REVIEW** — generic placeholder never updated since the 2026-09-04 directional split; real distribution is heavily right-skewed and concentrated near zero (median 1.3), compressing all meaningful signal into calibrated 0–30 |
| **PULLBACK_DOWN** | 50.0 / 15.0 | 6.3 | 9.8 | Same, mirrored |

**Method appropriateness (Phase 5):** the existing Z-score mechanism itself is mathematically sound for all four — none of the four raw distributions are so pathologically degenerate (bimodal, discrete-only, near-zero-variance) as to require an entirely different calibration philosophy. PULLBACK_UP/DOWN's sparsity (49.8%/59.0% exact-zero bars) is handled correctly by a mean/stdev fit computed over the FULL population (zeros included) — this naturally produces a low mean and moderate stdev that reflects "mostly absent, occasionally present," exactly the desired shape, without needing conditional/two-part calibration.

**No arbitrary offsets, no manual multipliers, no winner bonuses, no threshold changes, no cross-state normalization were used or considered.** New calibration = real historical mean/stdev, computed identically to how every other real-calibrated state in the array (STRONG_UPTREND, STRONG_DOWNTREND, UPTREND, DOWNTREND, STRONG_TREND, INSTITUTIONAL_SELLING) was originally calibrated.

---

## H. Counterfactual Calibration Validation (current vs. proposed, all 15 states, 96,355 bars)

Proposed calibration = real mean/stdev for EXPANSION/COMPRESSION/PULLBACK_UP/PULLBACK_DOWN only; **all other 11 states keep their exact existing calibration**, unchanged.

| | Current | Proposed |
|---|---|---|
| Overall winner changed | — | 33,679 bars (34.95%) |
| PULLBACK_UP wins | 24 (0.025%) | 5,247 (5.445%) |
| PULLBACK_DOWN wins | 35 (0.036%) | 8,232 (8.543%) |
| EXPANSION wins | 14,680 (15.24%) | 8,487 (8.81%) |
| COMPRESSION wins | 24,482 (25.41%) | 9,463 (9.82%) |
| UPTREND wins | 32,732 (33.97%) | 41,279 (42.84%) |
| STRONG_DOWNTREND wins | 14,971 (15.54%) | 15,530 (16.12%) |

**Winner-quality check (the decisive evidence against "manufactured winners"):** on the 5,247 bars where PULLBACK_UP newly wins, its own raw score averages **30.7** (well above its own population mean of 7.2, solidly in its own P90+ territory) and the runner-up's own calibrated score on those same bars averages **72.2** — meaning PULLBACK_UP is winning genuinely competitive bars against strong rivals, not defaulting to victory on quiet/near-zero-everywhere bars. PULLBACK_DOWN shows the same pattern (own raw mean 28.9 on winning bars vs population mean 6.3; runner-up calibrated mean 70.3). **This is real signal being correctly surfaced, not calibration inflating a weak signal into false wins.**

EXPANSION/COMPRESSION's ARGMAX share **drops** under the proposed calibration (COMPRESSION 25.4%→9.8%, EXPANSION 15.2%→8.8%) — the opposite of "manufacturing winners." The old stdev=3.0 calibration was *artificially inflating* their win rate by saturating almost every non-trivial raw score to calibrated≈100; the corrected calibration makes them compete honestly against the other 13 states instead of auto-winning by clamp saturation.

---

## I. PULLBACK_UP Analysis

Real distribution: 50.2% non-zero, mean 7.2, median 1.3 (right-skewed, mass concentrated near zero with a real tail to 86.4). Current placeholder (mean=50/stdev=15) compresses this entire tail into calibrated 0–30, meaning even a genuinely strong pullback reading (raw=60+) rarely wins. Proposed calibration (mean=7.2/stdev=9.9) restores a full 0–100 dynamic range matched to the real distribution's own shape. Counterfactual winner-quality check confirms new wins occur on bars with genuinely elevated raw scores against genuinely strong competition — not manufactured.

## J. PULLBACK_DOWN Analysis

Same conclusion, mirrored (mean 6.3, median 0.0, 41.0% non-zero). Symmetric with PULLBACK_UP within the mirror tolerance already established in Section E.

## K. EXPANSION Analysis

Real distribution now fully non-degenerate post-rebuild (stdev 23.2, max 100.0, 100% non-zero) — but the calibration array was never updated after the formula rebuild, leaving `stdev=3.0` (a value that made sense only for the OLD algebraically-frozen-at-50 formula). This mismatch causes near-total 0/100 clamp saturation. Proposed calibration (mean=26.1/stdev=23.2) restores genuine discrimination — verified by the counterfactual ARGMAX share dropping (not rising) once the artificial saturation is removed.

## L. COMPRESSION Analysis

Same conclusion, mirrored (mean 35.9, stdev 23.2). COMPRESSION's real mean sits closer to the old assumed 50.0 than EXPANSION's does, but the stdev mismatch (3.0 vs real 23.2) is identical in severity.

---

## M. No-Look-Ahead Proof

Calibration is a pure post-hoc transform (`CalibrateMarketDNAScores()`) applied to an already-computed `scores[]` array — it reads no candle data, calls no `CopyRates`, and has no access to `rates[]`/`ci`/future bars of any kind. Confirmed by direct source read: the function's only inputs are the `scores[]` array (by reference) and the two static calibration arrays. **0 shift-0 reads, 0 running-candle reads, 0 future-bar references, 0 new CopyRates calls, 0 dependence on future ARGMAX results** — structurally impossible for this function to look ahead, since it contains no data-fetching code at all.

---

## N. Test Results

Deterministic suite last confirmed via live Experts log: **2,098+ PASS, 0 FAIL**, including `PULLBACK_TEST1`–`32`, `EXPANSION_TEST1`–`8`, `COMPRESSION_TEST1`–`8`, `EXPANSION_vs_COMPRESSION_opposite_response`, and `CONSOLIDATION_TEST1`–`12` — all unaffected by this audit-only task (no code changed, so no test re-run was required or performed).

---

## O. Compile Result

Not applicable this task — **zero production code was modified**, so no recompile was performed or required.

---

## P. Regression Result

`STRONG_UPTREND`, `STRONG_DOWNTREND`, `UPTREND`, `DOWNTREND`, `WEAK_UPTREND`, `WEAK_DOWNTREND`, `VOLATILITY_EXPANSION`, `VOLATILITY_COMPRESSION`, `VOLATILE`, `CHOPPY`, `NEUTRAL` — all 11 protected states' 96,355-bar distributions closely match their own 7,382-bar counterparts (all means within ~1 point, all correlations within ~0.02) — **no unexpected material change, no STOP condition triggered.**

---

## Q. Live Validation

Not performed in this task — this was explicitly an audit against historical replay data only; no code was changed, so there is nothing new to reattach/validate live. (The production EA has continued running unmodified throughout, confirmed by the unchanged SHA256.)

---

## R. Exact Files / Functions / Arrays Changed

**None.** This task made zero modifications to `KMIE_MarketDNA_Lite.mq5`. The only file modified was the read-only replay script (`KMIE_MarketDNA_HistoricalReplay.mq5`), whose `Inp_ReplayStart`/`Inp_MaxHistoryBars` input defaults were widened to reach the larger dataset — no evaluator, struct, or scoring logic in that script was touched either.

---

## S. SHA256 Synchronization

Production EA: `7FA81096C851A52FC15F927D2DF8C522F50D8B129B1ACD6C1FEC06FB5B6C1F4C` — identical to the value recorded before this task began; Terminal↔Desktop sync previously confirmed and unaffected.

---

## Final Recommendation

### Usefulness (Phase 6/7/8, restated at 13x scale)

**KEEP ALL 15 STATES.** No candidate crossed the redundancy threshold at 96,355 bars. Every counterfactual finding reproduces the 7,382-bar audit closely enough to conclude the smaller sample was already statistically sound — more data did not surface a hidden redundancy, nor did it dissolve the apparent usefulness of any rare state. PULLBACK_UP/DOWN, VOLATILE, CHOPPY, and NEUTRAL remain low-ARGMAX-frequency but structurally distinct (Phase 7's mandatory rule against conflating rarity with uselessness applies unchanged).

### Calibration (Phases 1–13, the actual scope of this task)

| State | Verdict | Recommended (not yet applied) mean / stdev |
|---|---|---|
| EXPANSION | **CALIBRATION NEEDS REVIEW — recalibration justified** | 26.107 / 23.200 |
| COMPRESSION | **CALIBRATION NEEDS REVIEW — recalibration justified** | 35.939 / 23.220 |
| PULLBACK_UP | **CALIBRATION NEEDS REVIEW — recalibration justified** | 7.215 / 9.855 |
| PULLBACK_DOWN | **CALIBRATION NEEDS REVIEW — recalibration justified** | 6.255 / 9.791 |

All four pass every counterfactual-abuse check: raw scores unchanged, evaluators unchanged, ARGMAX logic unchanged, no manufactured winners (verified by winner-quality distribution, Section H), no cross-state normalization, no offsets. **Recommend implementation** of these four values into `g_dnaCalibMean[]`/`g_dnaCalibStdev[]` (indices 6, 7, 11, 12 in the current compacted enum) in a dedicated, narrowly-scoped follow-up task — per this task's own explicit "audit only, implement only after validation" structure, no array was written to in this task.

### Remaining Calibration Concerns

None of the other 11 states' calibration was evaluated for correctness in this task (out of scope, per explicit instruction) — `WEAK_UPTREND`/`WEAK_DOWNTREND`/`VOLATILITY_EXPANSION`/`VOLATILITY_COMPRESSION`/`VOLATILE`/`CHOPPY`/`NEUTRAL` all still carry the generic mean=50/stdev=15 placeholder and may warrant the same treatment in a future dedicated task — flagged for awareness, not evidence-gathered here.
