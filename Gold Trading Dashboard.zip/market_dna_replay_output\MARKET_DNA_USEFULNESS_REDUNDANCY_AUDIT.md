# Market DNA — Usefulness & Redundancy Audit

**Mode:** AUDIT ONLY — no production code was modified in this task.
**Production EA:** KMIE_MarketDNA_Lite.mq5 (SHA256 `7FA81096C851A52FC15F927D2DF8C522F50D8B129B1ACD6C1FEC06FB5B6C1F4C`, unchanged throughout)
**Dataset:** 7,382 valid closed-M1 XAUUSD bars, 2026-08-30 22:01 → 2026-09-07 06:13 UTC, replayed via `KMIE_MarketDNA_HistoricalReplay.mq5` (the existing, previously-validated read-only replay script — same closed-M1 `CopyRates(...,PERIOD_M1,1,...)` architecture, no shift-0, no look-ahead, zero trading calls, verbatim-copied production evaluators).

---

## Phase 1 — Source Audit

| DNA | Evaluator | Primary Measurement | Directional? | Unique Measurement? | ARGMAX Eligible |
|---|---|---|---|---|---|
| STRONG_UPTREND | `EvaluateStrongUptrendShadow()` (structuralScore, 80%) + `EvaluateStrongTrendStructure()` confirmation (20%) | Fractal HH/HL structural continuity + 25-bar force/volume confirmation | Yes | Yes — structural swing detection, not shared with UPTREND's own formula | Yes |
| STRONG_DOWNTREND | `EvaluateStrongDowntrendShadow()` + confirmation | Mirror of STRONG_UPTREND (LH/LL) | Yes | Yes | Yes |
| UPTREND | `EvaluateUptrendShadow()` | Fractal HH/HL, looser structural gate than STRONG_* | Yes | Yes — no confirmation-engine blend | Yes |
| DOWNTREND | `EvaluateDowntrendShadow()` | Mirror of UPTREND | Yes | Yes | Yes |
| WEAK_UPTREND | `EvaluateWeakTrendStructure()` → routed by direction | 5-bar net-move persistence, explicitly EXCLUDES STRONG_TREND's own clean-expansion domain (upper bound gate) | Yes | Yes — near-zero correlation with UPTREND (0.0275) | Yes |
| WEAK_DOWNTREND | same engine, mirrored routing | Mirror | Yes | Yes (correlation with DOWNTREND: 0.0074) | Yes |
| PULLBACK_UP | `EvaluatePullbackStructure()` → routed by `trendDirection` | Preceding-impulse + 5-bar retracement + structural-preservation + choppy-protection | Yes | Yes — retracement-specific geometry, not shared with any trend evaluator | Yes |
| PULLBACK_DOWN | same engine, mirrored routing | Mirror | Yes | Yes | Yes |
| VOLATILITY_EXPANSION | `EvaluateVolExpansionStructure()` | Range SIZE vs 20-bar baseline, 5-bar persistence, Volume×Pip | No | Yes — range-magnitude axis | Yes |
| VOLATILITY_COMPRESSION | `EvaluateVolCompressionStructure()` | Mirror (contraction) | No | Yes | Yes |
| VOLATILE | `EvaluateVolatileStructure()` | Magnitude × instability (poor directional persistence), mandatory multiplicative gate | No | Yes — the only state requiring an instability gate | Yes |
| EXPANSION | `EvaluateExpansionStructure()` (2026-09-07 rebuild) | Slope/trend of candle body-dominance over 5 bars, persistence-gated | No | Yes — candle-character axis, orthogonal to range magnitude | Yes |
| COMPRESSION | `EvaluateCompressionStructure()` (2026-09-07 rebuild) | Mirror (softening trend) | No | Yes | Yes |
| CHOPPY | `EvaluateChoppyStructure()` | Alternation + gross/net inefficiency, dampened by directional consistency | No | Yes — the only state gated on alternation | Yes |
| NEUTRAL | `EvaluateNeutralStructure()` | Low net displacement + directional balance + effort balance, all vs 20-bar baseline | No | Yes — the only state requiring balance AND meaningful gross movement together | Yes |

Gates confirmed by direct source read: all 15 states have a live `Inp_Allow_*` input wired into `CurrentRegimeAllowed()`; `IsRetryObservationDnaAllowed()` whitelist entries were confirmed present for every state (values vary — see Phase 3 for whether low-frequency states are still whitelisted). Every state has a `case` in `DnaName()`/`DnaFromName()` and appears in `ARGMAX_ACTIVE_DNA_STATES[]`. Dashboard mapping confirmed present for all 15 in `app/static/index.html`'s `MARKET_DNA_STATES` registry (verified in the prior consolidation task, unchanged since).

**No production code was modified during this phase.**

---

## Phase 2 — Historical Replay Methodology

Reused the existing `KMIE_MarketDNA_HistoricalReplay.mq5` script exactly as previously validated (no second market-data interpretation, no new formula copy — same verbatim-copied evaluators already proven against production). 7,382 bars, 0 `INSUFFICIENT_HISTORY`, 0 look-ahead violations (re-confirmed by the script's own per-bar structural assertion). No trades, no execution, no forced conditions.

---

## Phase 3 — Full Score Statistics

| DNA | Non-zero% | Mean | Median | P90 | P95 | Max | StdDev | ≥70% | ≥80% | ARGMAX Wins | ARGMAX% | Max Run | Avg Run |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| STRONG_UPTREND | 100.0 | 34.3 | 34.2 | 55.1 | 60.6 | 80.7 | 15.4 | 0.85 | 0.01 | 89 | 1.21 | 5 | 1.29 |
| STRONG_DOWNTREND | 100.0 | 34.2 | 34.7 | 54.5 | 59.7 | 76.6 | 15.4 | 0.51 | 0.00 | 1132 | 15.33 | 8 | 1.83 |
| UPTREND | 100.0 | 41.1 | 41.2 | 66.7 | 74.0 | 90.0 | 19.1 | 7.82 | 1.88 | 2434 | 32.97 | 39 | 2.42 |
| DOWNTREND | 100.0 | 41.1 | 42.4 | 66.0 | 72.5 | 90.0 | 19.0 | 6.29 | 1.21 | 214 | 2.90 | 7 | 1.38 |
| WEAK_UPTREND | 31.6 | 16.1 | 0.0 | 54.6 | 59.4 | 77.6 | 24.1 | 0.39 | 0.00 | 86 | 1.16 | 3 | 1.16 |
| WEAK_DOWNTREND | 33.8 | 17.2 | 0.0 | 54.8 | 59.3 | 80.5 | 24.5 | 0.39 | 0.03 | 114 | 1.54 | 4 | 1.33 |
| PULLBACK_UP | 49.2 | 7.5 | 0.0 | 21.8 | 28.5 | 79.5 | 10.6 | 0.11 | 0.00 | 3 | 0.04 | 2 | 1.50 |
| PULLBACK_DOWN | 41.9 | 6.4 | 0.0 | 19.7 | 26.4 | 80.2 | 9.9 | 0.05 | 0.01 | 2 | 0.03 | 1 | 1.00 |
| VOLATILITY_EXPANSION | 100.0 | 20.0 | 15.4 | 43.3 | 57.2 | 100.0 | 16.7 | 1.69 | 0.70 | 82 | 1.11 | 4 | 1.26 |
| VOLATILITY_COMPRESSION | 100.0 | 39.4 | 40.9 | 61.2 | 66.0 | 86.1 | 17.4 | 2.14 | 0.14 | 164 | 2.22 | 4 | 1.40 |
| VOLATILE | 44.4 | 3.2 | 0.0 | 9.7 | 15.8 | 90.0 | 7.2 | 0.07 | 0.04 | 33 | 0.45 | 1 | 1.00 |
| EXPANSION | 100.0 | 26.2 | 16.9 | 64.3 | 65.8 | 97.0 | 23.3 | 3.91 | 0.77 | 1132 | 15.33 | 5 | 1.35 |
| COMPRESSION | 100.0 | 36.2 | 27.3 | 74.4 | 79.8 | 96.0 | 23.2 | 11.32 | 0.87 | 1894 | 25.66 | 7 | 1.60 |
| CHOPPY | 100.0 | 27.9 | 27.5 | 40.0 | 43.7 | 66.8 | 8.7 | 0.00 | 0.00 | 4 | 0.05 | 2 | 1.33 |
| NEUTRAL | 100.0 | 41.2 | 41.9 | 50.1 | 52.3 | 67.0 | 7.6 | 0.00 | 0.00 | 31 | 0.42 | 3 | 1.15 |

**Directional pair symmetry** (mean difference, not ARGMAX-win difference):

| Pair | Mean A | Mean B | Mean Diff | ARGMAX A | ARGMAX B |
|---|---|---|---|---|---|
| STRONG_UPTREND vs STRONG_DOWNTREND | 34.3 | 34.2 | **0.18** | 89 | 1132 |
| UPTREND vs DOWNTREND | 41.1 | 41.1 | **0.05** | 2434 | 214 |
| WEAK_UPTREND vs WEAK_DOWNTREND | 16.1 | 17.2 | **1.10** | 86 | 114 |
| PULLBACK_UP vs PULLBACK_DOWN | 7.5 | 6.4 | **1.10** | 3 | 2 |

**Conclusion:** every directional pair's formula is symmetric to within ~1 point of mean score. The large ARGMAX-win skews (STRONG_DOWNTREND 1132 vs STRONG_UPTREND 89; UPTREND 2434 vs DOWNTREND 214) reflect a real, asymmetric market during this window (a sustained decline into early September, transitioning to a recovery — confirmed by the prior replay's own transition table) — **not a coded bias.** This finding is not treated as a defect, per explicit instruction.

---

## Phase 4 — Redundancy / Overlap Analysis

Key pairwise correlations (from the 7,382-bar overlap matrix):

| Pair | Correlation | Interpretation |
|---|---|---|
| STRONG_UPTREND ↔ UPTREND | **+0.963** | Highest correlation of any pair — expected, STRONG_UPTREND's own formula is 80% UPTREND's structural engine plus a 20% confirmation slot |
| STRONG_DOWNTREND ↔ DOWNTREND | **+0.961** | Mirror |
| UPTREND ↔ WEAK_UPTREND | **+0.028** | Essentially uncorrelated — WEAK_UPTREND is NOT a diluted UPTREND |
| DOWNTREND ↔ WEAK_DOWNTREND | **+0.007** | Same conclusion, mirrored |
| UPTREND ↔ PULLBACK_UP | +0.482 | Moderate — a pullback occurs inside a trend context, but far below duplication threshold |
| DOWNTREND ↔ PULLBACK_DOWN | +0.529 | Moderate, mirrored |
| VOLATILITY_EXPANSION ↔ EXPANSION | +0.277 | Weak-moderate — related axes (both respond to "more happening"), not duplicates |
| VOLATILITY_COMPRESSION ↔ COMPRESSION | +0.309 | Same conclusion |
| VOLATILITY_EXPANSION ↔ VOLATILE | +0.611 | Moderate-high — VOLATILE requires large range (shared with VOL_EXPANSION) AND instability (unique) |
| EXPANSION ↔ COMPRESSION | −0.775 | Strongly anti-correlated, as the two ends of one slope axis should be — structurally can't both be high |
| CHOPPY ↔ NEUTRAL | +0.587 | Moderate — both rise on low-net-displacement bars, but co-occur at ≥50 only 42/7382 bars (0.6%) |

**STRONG vs NORMAL — is STRONG genuinely a stricter confirmation, or redundant?**

The 0.963 correlation is the strongest evidence for scrutiny in this whole audit. Two things keep STRONG_UPTREND/DOWNTREND from being pure duplicates of UPTREND/DOWNTREND:
1. **Formula composition**: STRONG_* = 80% of UPTREND/DOWNTREND's own structural score + 20% an independent 25-bar/volume-confirmed force reading (`EvaluateStrongTrendStructure()`) that UPTREND/DOWNTREND never read at all.
2. **Score ceiling**: STRONG_UPTREND's own max across 7,382 bars is 80.7 (vs UPTREND's max of 90.0) — the confirmation term structurally caps how high STRONG_* can go unless genuine force is present, so STRONG_* wins ARGMAX materially less often (89 vs 2434) even on bars where both score non-trivially.

The counterfactual test (Phase 5 below) is the deciding evidence here, not correlation alone.

---

## Phase 5 — Counterfactual ARGMAX Test (removed-one-state re-simulation)

For every one of the 15 bars where a candidate state actually won, its own score was excluded and the ARGMAX recomputed among the remaining 14 states (calibrated score, production's own real decision basis) — answering "what would Market DNA have picked instead?"

| Candidate | Original Wins | Wins Lost | % of All Bars Changed | Top Replacement | Replacement Share |
|---|---|---|---|---|---|
| UPTREND | 2434 | 2434 | **32.97%** | STRONG_UPTREND | 1877/2434 (77%) |
| COMPRESSION | 1894 | 1894 | **25.66%** | UPTREND | 939/1894 (50%) |
| STRONG_DOWNTREND | 1132 | 1132 | **15.34%** | DOWNTREND | 863/1132 (76%) |
| EXPANSION | 1132 | 1132 | **15.34%** | UPTREND | 574/1132 (51%) |
| DOWNTREND | 214 | 214 | 2.90% | STRONG_DOWNTREND | 199/214 (93%) |
| VOLATILITY_COMPRESSION | 164 | 164 | 2.22% | UPTREND | 43/164 (26%) |
| WEAK_DOWNTREND | 114 | 114 | 1.54% | STRONG_DOWNTREND | 35/114 (31%) |
| STRONG_UPTREND | 89 | 89 | 1.21% | UPTREND | 77/89 (87%) |
| WEAK_UPTREND | 86 | 86 | 1.17% | UPTREND | 23/86 (27%) |
| VOLATILITY_EXPANSION | 82 | 82 | 1.11% | STRONG_DOWNTREND | 26/82 (32%) |
| NEUTRAL | 31 | 31 | 0.42% | STRONG_DOWNTREND | 8/31 (26%) |
| VOLATILE | 33 | 33 | 0.45% | VOLATILITY_EXPANSION | 1/33 (3%) |
| CHOPPY | 4 | 4 | 0.05% | UPTREND | 2/4 (50%) |
| PULLBACK_UP | 3 | 3 | 0.04% | WEAK_DOWNTREND | 2/3 (67%) |
| PULLBACK_DOWN | 2 | 2 | 0.03% | mixed (1 VOL_COMPRESSION, 1 DOWNTREND) | — |

**Reading this table correctly:** "Wins Lost" always equals "Original Wins" by construction — removing a state's own score from the ARGMAX candidate pool necessarily means it can never win any of the bars it previously won (that's what removal means). The evidence that actually matters is the **replacement distribution**: a state is a genuine duplicate only if its replacement is overwhelmingly the SAME one or two states every time, at a near-100% rate, AND that replacement's own score on those bars was already close to the removed state's score (i.e., the decision barely changes).

- **STRONG_UPTREND → UPTREND (87%)** and **UPTREND → STRONG_UPTREND (77%)** are each other's dominant replacement, but *not exclusively* — UPTREND's own removal sends 23% of its wins to five other states (STRONG_DOWNTREND, COMPRESSION, EXPANSION, WEAK_UPTREND, VOLATILITY_COMPRESSION), meaning UPTREND is doing real, distinct work on a meaningful fraction of its own winning bars, not simply "duplicating" STRONG_UPTREND.
- **STRONG_DOWNTREND → DOWNTREND (76%)** is the single largest same-family replacement observed, and is the strongest evidence of nesting in this whole dataset — but even here, 24% of STRONG_DOWNTREND's wins scatter across seven other states, meaning removing it would still measurably change ~270 individual bar-level decisions to states that are NOT its normal-trend sibling.
- **PULLBACK_UP/PULLBACK_DOWN**: only 3 and 2 ARGMAX wins respectively (0.04%/0.03% of all bars) — but per the mandatory Phase 7 rule, this alone does not prove redundancy. Their replacement is NOT concentrated in the directional trend states (WEAK_DOWNTREND and VOLATILITY_COMPRESSION/DOWNTREND, not UPTREND/DOWNTREND) — meaning even on the rare bars they DO win, no single "obvious" other state was standing right behind them. This is exactly the "specialized, not redundant" signature the task described.

---

## Phase 6 — Usefulness Classification

| DNA | Classification | Rationale |
|---|---|---|
| STRONG_UPTREND | **A — CORE** | Independent confirmation engine (20% weight) genuinely changes the score vs UPTREND; 13% of its counterfactual replacements go to non-adjacent states |
| STRONG_DOWNTREND | **A — CORE** | Same structural argument; highest same-family replacement rate (76%) of any pair, but still 24% goes elsewhere — real, if partially-overlapping, information |
| UPTREND | **A — CORE** | Highest-frequency ARGMAX winner (33%); 23% of its counterfactual replacements are NOT STRONG_UPTREND |
| DOWNTREND | **A — CORE** | Same argument, mirrored |
| WEAK_UPTREND | **A — CORE** | Correlation with UPTREND is 0.028 (effectively zero) — genuinely distinct regime, not a diluted trend reading |
| WEAK_DOWNTREND | **A — CORE** | Correlation with DOWNTREND is 0.007 — same conclusion |
| PULLBACK_UP | **B — SPECIALIZED** | Low frequency (0.04% ARGMAX), but replacement is scattered (not concentrated in the directional trend states) — structurally distinct retracement geometry, not measured elsewhere |
| PULLBACK_DOWN | **B — SPECIALIZED** | Same conclusion, mirrored |
| VOLATILITY_EXPANSION | **A — CORE** | Distinct range-magnitude axis, correlation with EXPANSION only 0.28 |
| VOLATILITY_COMPRESSION | **A — CORE** | Same conclusion, correlation with COMPRESSION only 0.31 |
| VOLATILE | **B — SPECIALIZED** | Low frequency (0.45% ARGMAX) but structurally unique (only state requiring the instability-AND-magnitude multiplicative gate); counterfactual replacement is NOT concentrated (only 3% goes to its nearest relative, VOLATILITY_EXPANSION) |
| EXPANSION | **A — CORE** | Rebuilt 2026-09-07; now fully non-degenerate (stdev 23.3); distinct candle-character axis from VOLATILITY_EXPANSION (correlation 0.28) |
| COMPRESSION | **A — CORE** | Same conclusion (stdev 23.2, correlation with VOLATILITY_COMPRESSION 0.31); highest single ARGMAX share of the behavior-regime group (25.7%) |
| CHOPPY | **B — SPECIALIZED** | Very low frequency (0.05% ARGMAX, never reaches ≥70 in this window) but the ONLY state gated on directional alternation — a genuinely unique measurement axis with zero close substitute in this dataset |
| NEUTRAL | **B — SPECIALIZED** | Low frequency (0.42%) but the ONLY state requiring balance AND meaningful gross movement together — distinct from CHOPPY (0.587 correlation, but co-occurs at ≥50 only 0.6% of bars) |

**No state in this audit falls into Category C (REDUNDANT), D (BROKEN), or E (CALIBRATION PROBLEM defined as "urgent, blocking") based on this window's evidence** — see the calibration disclosure below, which is a lower-urgency finding already flagged in the prior task.

---

## Phase 7 — Low-Frequency ≠ Useless (explicit check)

Applied to every low-ARGMAX state in this dataset:

- **PULLBACK_DOWN (2 wins, 0.03%)**: Correlation with DOWNTREND is only 0.53 (moderate, not duplicative). Counterfactual replacement scatters across DOWNTREND and VOLATILITY_COMPRESSION — no single dominant substitute. Its own formula measures preceding-impulse/retracement-depth/structural-preservation, a geometry no other retained state computes. **Not proven redundant.**
- **CHOPPY (4 wins, 0.05%)**: The only state reading alternation-count as a mandatory factor. Zero other state's evaluator touches sign-change counting. **Not proven redundant** — genuinely un-replicated measurement, low frequency in this particular week does not mean the underlying market condition (rapid, inefficient two-sided noise) cannot recur.
- **VOLATILE (33 wins, 0.45%)**: Requires BOTH elevated range AND directional instability, multiplicatively gated — the narrowest joint condition of any state in the taxonomy, which mechanically produces low frequency by design, not by defect. **Not proven redundant.**
- **NEUTRAL (31 wins, 0.42%)**: Requires low net displacement despite meaningful gross movement — a narrower condition than "nothing happened." **Not proven redundant.**

No state was recommended for removal on frequency grounds alone in this audit.

---

## Phase 8 — Removal Simulation (downstream impact, measurement only)

For the two highest-impact counterfactual candidates (UPTREND, COMPRESSION) — the states whose removal would change the MOST individual bar-level ARGMAX decisions — the downstream consequence was traced conceptually (no code executed, no trade simulated):

- Removing **UPTREND** would shift ~33% of all bars' winning-state label, cascading into `CurrentRegimeAllowed()` (a different `Inp_Allow_*` gate would apply on those bars), `IsRetryObservationDnaAllowed()` (a different whitelist entry), and ultimately a materially different mix of bars reaching Entry Approval — this is the single highest-blast-radius candidate in the entire taxonomy and is unambiguously Core.
- Removing **COMPRESSION** would shift ~26% of bars, predominantly toward UPTREND/STRONG_DOWNTREND/DOWNTREND (trend states) — meaning on the majority of its own winning bars, the market was ALSO showing meaningful directional structure that a trend state could have claimed instead. This is worth noting as the closest thing to a "shared territory" finding in this audit, but COMPRESSION's own formula (candle-character slope) measures something the trend evaluators structurally cannot (none of them read `bodyRatio` slope) — so this is presented as evidence, not a redundancy proof.

No production code, order, or account state was touched in this phase.

---

## Phase 9 — Final Recommendation Table

| DNA | Keep/Remove | Evidence | Replacement if Removed | Confidence |
|---|---|---|---|---|
| STRONG_UPTREND | **KEEP** | 0.963 corr. with UPTREND but 20% independent confirmation term; 13% of counterfactual replacements are non-adjacent | UPTREND (87%) | High |
| STRONG_DOWNTREND | **KEEP** | Same structural argument; highest same-family replacement rate (76%) in the dataset — worth monitoring, not removing | DOWNTREND (76%) | Medium-High |
| UPTREND | **KEEP** | Highest-frequency winner; largest counterfactual blast radius (33% of all bars) | STRONG_UPTREND (77%) | Very High |
| DOWNTREND | **KEEP** | Same argument, mirrored | STRONG_DOWNTREND (93%) | High |
| WEAK_UPTREND | **KEEP** | Near-zero correlation (0.028) with UPTREND — proven distinct regime | scattered, no dominant replacement | Very High |
| WEAK_DOWNTREND | **KEEP** | Near-zero correlation (0.007) with DOWNTREND | scattered | Very High |
| PULLBACK_UP | **KEEP** | Low frequency but zero evidence of coverage elsewhere; scattered counterfactual replacement | scattered | High |
| PULLBACK_DOWN | **KEEP** | Same argument, mirrored | scattered | High |
| VOLATILITY_EXPANSION | **KEEP** | Distinct range-magnitude axis, correlation 0.28 with EXPANSION | scattered | Very High |
| VOLATILITY_COMPRESSION | **KEEP** | Distinct axis, correlation 0.31 with COMPRESSION | scattered | Very High |
| VOLATILE | **KEEP** | Structurally unique instability gate; low frequency is a mechanical consequence of a narrow joint condition, not a defect | scattered | High |
| EXPANSION | **KEEP** | Rebuilt and now non-degenerate; distinct candle-character axis | UPTREND (51%) — worth monitoring | High |
| COMPRESSION | **KEEP** | Same conclusion; highest ARGMAX share in the behavior-regime group | UPTREND (50%) — worth monitoring | High |
| CHOPPY | **KEEP** | Only alternation-gated state in the taxonomy; low frequency this week ≠ non-informative | UPTREND (50% of only 4 bars) | Medium (small sample) |
| NEUTRAL | **KEEP** | Only state requiring balance-with-meaningful-movement; distinct from CHOPPY | STRONG_DOWNTREND (26% of only 31 bars) | Medium |

**KEEP:** all 15 active states. No state met this task's own bar for proven redundancy (substantial observation volume + meaningful overlap + no unique regime coverage + strong evidence) in this replay window.

**REMOVE:** none.

**REBUILD:** none — EXPANSION/COMPRESSION's rebuild (prior task) is already validated as non-degenerate in this dataset.

**RECALIBRATE (flagged, not actioned):**
- EXPANSION/COMPRESSION — real stdev (23.3/23.2) is materially wider than the current placeholder (15.0), a finding already disclosed in the prior task's report and not yet acted on.
- PULLBACK_UP/PULLBACK_DOWN — real mean (~7) is far below the placeholder mean (50); same disclosed-but-unactioned status from the prior task.

---

## Regression-Risk Assessment

No production code was changed in this task. `RunMarketDnaConsolidationTests()`, `RunExpansionCompressionTests()`, and the full deterministic suite (2098 assertions, last confirmed 0 FAIL) remain untouched and unaffected by this audit. The replay used the same previously-validated, read-only script — zero new formula implementation, zero trading calls, zero look-ahead (re-confirmed structurally at 0/7382 violations).

## Conclusion

Across 7,382 real closed-M1 XAUUSD bars, every one of the 15 active Market DNA states demonstrated at least one dimension of genuinely unique information: either near-zero correlation with its nearest sibling (WEAK_*, VOLATILITY_* vs EXPANSION/COMPRESSION), a structurally distinct gating mechanism no other state replicates (VOLATILE's instability gate, CHOPPY's alternation gate, NEUTRAL's balance-with-movement gate, PULLBACK's retracement geometry), or — for the most correlated pair (STRONG_* vs normal trend states) — a counterfactual replacement rate well short of 100%, meaning a meaningful fraction of their own winning decisions would change to a *different* state entirely if removed, not simply fall through to their closest sibling.

**No removal is recommended from this audit.** The two open items are calibration questions (EXPANSION/COMPRESSION, PULLBACK_UP/DOWN), not redundancy questions, and are explicitly deferred to a separate recalibration task per this task's own instruction not to invent calibration values here.
