@echo off
setlocal enabledelayedexpansion
title Gold Trading Dashboard
cd /d "%~dp0"

echo ============================================================
echo   GOLD TRADING DASHBOARD - starting...
echo ============================================================
echo.

rem --- Find a working Python interpreter ---------------------------------
rem Version-pinned "py -3.X" launches are tried first because a bare
rem "python"/"py -3" can resolve to a stale/broken venv shim earlier on
rem PATH on some setups - pinning skips that ambiguity entirely.
set "PYEXE="

for %%P in ("py -3.12" "py -3.13" "py -3.11" "py -3.10" "py -3" "python" "python3") do (
    if not defined PYEXE (
        %%~P --version >nul 2>&1
        if not errorlevel 1 set "PYEXE=%%~P"
    )
)

if not defined PYEXE (
    echo [ERROR] No working Python installation was found on this PC.
    echo.
    echo Install Python 3.10+ from https://www.python.org/downloads/
    echo   ^(tick "Add python.exe to PATH" during setup^)
    echo or run:  winget install Python.Python.3.12
    echo.
    echo Then double-click this file again.
    echo.
    pause
    exit /b 1
)

echo Using interpreter: %PYEXE%
echo.

rem --- Create/reuse a local virtual environment -------------------------
if not exist ".venv\Scripts\python.exe" (
    echo Setting up local environment ^(first run only^)...
    %PYEXE% -m venv ".venv"
    if errorlevel 1 (
        echo [ERROR] Failed to create the virtual environment.
        pause
        exit /b 1
    )
)

set "VENV_PY=.venv\Scripts\python.exe"

echo Checking dependencies...
"%VENV_PY%" -m pip install --quiet --disable-pip-version-check -r requirements.txt
if errorlevel 1 (
    echo [ERROR] Failed to install dependencies. Check your internet connection.
    pause
    exit /b 1
)

rem --- Postgres auto-sync (optional) --------------------------------------
rem When set, main.py mirrors every EA-written JSON log (bars/trades/logs/
rem equity/positions/live_signal) into this Postgres database automatically
rem every few seconds. If Postgres isn't running, the dashboard falls back
rem to reading the JSON files directly - this line is safe to remove.
rem 2026-09-24, audit fix (R-3): the actual connection string (with password) now
rem lives in db_secret.bat, NOT here, so it isn't sitting in the main launcher script.
rem Missing db_secret.bat is not an error - DATABASE_URL just stays unset and the
rem dashboard falls back to JSON-file-only mode, same as if Postgres were down.
if exist "db_secret.bat" call "db_secret.bat"

echo.
echo Starting server at http://127.0.0.1:8090 ...
echo ^(Leave this window open. Close it to stop the dashboard.^)
echo.

start "" "http://127.0.0.1:8090"
"%VENV_PY%" -m uvicorn app.main:app --host 127.0.0.1 --port 8090

pause
