# Market DNA Historical Coverage Report

**Task:** Read-only historical replay / coverage audit of the 15 active Market DNA states
**Date:** 2026-09-07
**Production EA:** KMIE_MarketDNA_Lite.mq5 (SHA256 `C41B3EFE5E63911C0A140D7971301B2BB14A898E7E6E3710DF914C6E8977127C`, unchanged throughout this task)
**Replay tool:** KMIE_MarketDNA_HistoricalReplay.mq5 (Script, MQL5\Scripts — read-only, zero OrderSend/trade calls)

---

## 1. Dataset Discovered

Before writing any replay code, the following real data sources were inventoried:

| Source | Content | Usable for replay? |
|---|---|---|
| `bars.jsonl` | Real closed M1 OHLC + tick volume + live DNA label, one line per completed bar | Yes — confirms production's own closed-bar cadence, cross-check only |
| `dna_raw_scores.jsonl` | Two record shapes: pre-consolidation (30-state) and post-consolidation (18-state), full raw+detail sub-blocks | Yes — used for replay-vs-recorded validation (Section 13) |
| `market_dna_competition.jsonl` | ARGMAX winner/second-place snapshots | Cross-check only |
| `strong_trend_dna.jsonl`, `weak_trend_dna.jsonl`, `pullback_dna.jsonl`, `choppy_dna.jsonl`, `neutral_dna.jsonl`, `volatility_dna.jsonl` | Per-state diagnostic detail | Not needed — replay recomputes from OHLC directly via the real evaluators |
| MT5 native tick database (`bases\Exness-MT5Trial8\ticks\XAUUSD*`) | Real broker tick history | **Not used** — proprietary binary format, only readable via MQL5's own `CopyTicksRange()`, and `bars.jsonl`/live `CopyRates()` already provide the exact closed-M1 OHLC production consumes; reconstructing M1 from ticks would be a second, parallel implementation the task's own "do not create a second implementation" rule forbids |

**Route used:** production's own `CopyRates(symbol, PERIOD_M1, 1, N, ...)` — the identical closed-M1 source `BuildMarketDnaWindow30()`/`ComputeVolumeDna()`/`EvaluateCandleIntelligence()` already use live — fetched **once** for the whole replay window, sliced at each historical offset. This is not tick-derived reconstruction; it is the same M1 history MT5 already stores and production already reads.

## 2. Date/Time Range

**2026-08-30 22:01:00 UTC → 2026-09-06 22:22:00 UTC** (replay window requested through 2026-09-08, but real history ends where the market was last active before this task ran).

## 3. Number of Ticks

Not applicable — replay used closed M1 bars directly (see Section 1's routing rationale), not tick reconstruction.

## 4. Number of Reconstructed M1 Bars

Not applicable (no reconstruction performed). **6,911 real closed M1 bars** fetched via a single `CopyRates()` call, newest-first, shift=1..N (shift 0 — the running candle — never fetched by the replay).

## 5. Number of Valid Evaluation Points

**6,911 of 6,911 bars valid (100%).** Every bar in the window had the full required context (25-bar canonical window + 20-bar baseline + additional baseline depth = 82-bar minimum). **0 bars flagged `INSUFFICIENT_HISTORY`.**

## 6. 15-DNA Coverage Table

| DNA | Valid Obs | Non-Zero % | Mean | Median | P90 | P95 | Max | ≥50 | ≥60 | ≥70 | ≥80 | ARGMAX Wins (raw) | ARGMAX Wins (calibrated) | First Observed | Last Observed |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| STRONG_UPTREND | 6911 | 100.0% | 34.9 | 34.8 | 55.4 | 61.0 | 80.7 | 1170 | 407 | 63 | 1 | 7 | 197 | 08-30 22:01 | 09-06 22:22 |
| STRONG_DOWNTREND | 6911 | 100.0% | 34.8 | 35.2 | 54.9 | 60.0 | 76.6 | 1188 | 342 | 38 | 0 | 12 | 1829 | 08-30 22:01 | 09-06 22:22 |
| UPTREND | 6911 | 100.0% | 41.8 | 42.0 | 67.3 | 74.3 | 90.0 | 2348 | 1314 | 568 | 138 | 1701 | 3757 | 08-30 22:01 | 09-06 22:22 |
| DOWNTREND | 6911 | 100.0% | 41.9 | 43.1 | 66.7 | 73.1 | 90.0 | 2534 | 1247 | 462 | 89 | 1782 | 362 | 08-30 22:01 | 09-06 22:22 |
| WEAK_UPTREND | 6911 | 31.8% | 16.2 | 0.0 | 54.6 | 59.3 | 77.6 | 1135 | 304 | 28 | 0 | 544 | 126 | 08-30 22:07 | 09-06 22:22 |
| WEAK_DOWNTREND | 6911 | 33.5% | 17.0 | 0.0 | 54.6 | 59.2 | 80.5 | 1193 | 297 | 27 | 2 | 529 | 136 | 08-30 22:28 | 09-06 22:17 |
| PULLBACK_UP | 6911 | 49.1% | 7.5 | 0.0 | 21.5 | 28.2 | 79.5 | 43 | 17 | 7 | 0 | 14 | 5 | 08-30 22:01 | 09-06 22:22 |
| PULLBACK_DOWN | 6911 | 42.5% | 6.4 | 0.0 | 19.6 | 25.9 | 70.1 | 24 | 8 | 1 | 0 | 3 | **0** | 08-30 22:02 | 09-06 22:08 |
| VOLATILITY_EXPANSION | 6911 | 100.0% | 19.8 | 15.3 | 42.9 | 56.5 | 100.0 | 478 | 275 | 110 | 47 | 275 | 125 | 08-30 22:01 | 09-06 22:22 |
| VOLATILITY_COMPRESSION | 6911 | 100.0% | 39.6 | 41.1 | 61.3 | 66.1 | 86.1 | 2102 | 794 | 150 | 10 | 1187 | 259 | 08-30 22:01 | 09-06 22:22 |
| VOLATILE | 6911 | 44.3% | 3.2 | 0.0 | 9.7 | 15.8 | 90.0 | 27 | 11 | 5 | 3 | 5 | 2 | 08-30 22:01 | 09-06 22:12 |
| EXPANSION | 6911 | 100.0% | **50.0** | **50.0** | **50.0** | **50.0** | **50.0** | 5806 | 0 | 0 | 0 | 550 | 74 | 08-30 22:01 | 09-06 22:22 |
| COMPRESSION | 6911 | 100.0% | **50.0** | **50.0** | **50.0** | **50.0** | **50.0** | 5842 | 0 | 0 | 0 | 109 | 6 | 08-30 22:01 | 09-06 22:22 |
| CHOPPY | 6911 | 100.0% | 28.0 | 27.6 | 39.9 | 43.7 | 66.8 | 69 | 9 | 0 | 0 | 21 | 2 | 08-30 22:01 | 09-06 22:22 |
| NEUTRAL | 6911 | 100.0% | 41.2 | 42.0 | 50.1 | 52.3 | 67.0 | 721 | 21 | 0 | 0 | 172 | 31 | 08-30 22:01 | 09-06 22:22 |

## 7. ARGMAX Distribution (calibrated — production's own live decision basis)

UPTREND 3757 (54.4%) · STRONG_DOWNTREND 1829 (26.5%) · DOWNTREND 362 (5.2%) · VOLATILITY_COMPRESSION 259 (3.7%) · STRONG_UPTREND 197 (2.9%) · WEAK_DOWNTREND 136 (2.0%) · WEAK_UPTREND 126 (1.8%) · VOLATILITY_EXPANSION 125 (1.8%) · NEUTRAL 31 (0.4%) · EXPANSION 74 (1.1%) · COMPRESSION 6 (0.1%) · CHOPPY 2 (0.03%) · VOLATILE 2 (0.03%) · PULLBACK_UP 5 (0.07%) · **PULLBACK_DOWN 0 (0.0%)**.

Total = 6911. All wins fall within the 15 active states — **0 wins for any retired-compatibility or fully-removed state** (verified directly, see Section 14).

## 8. Directional Coverage

| Pair | Buy State | Sell State | Buy Occ. | Sell Occ. | Buy Mean | Sell Mean | Buy ARGMAX | Sell ARGMAX |
|---|---|---|---|---|---|---|---|---|
| STRONG | STRONG_UPTREND | STRONG_DOWNTREND | 6911 | 6911 | 34.9 | 34.8 | 197 | 1829 |
| NORMAL | UPTREND | DOWNTREND | 6911 | 6911 | 41.8 | 41.9 | 3757 | 362 |
| WEAK | WEAK_UPTREND | WEAK_DOWNTREND | 2198 | 2313 | 16.2 | 17.0 | 126 | 136 |
| PULLBACK | PULLBACK_UP | PULLBACK_DOWN | 3394 | 2935 | 7.5 | 6.4 | 5 | **0** |

**Formula-level symmetry is intact**: every mirrored pair's mean/median/max is within 1-2 points of its counterpart, and occurrence counts are comparable (no side is structurally starved of raw scoring). **The large ARGMAX-win skew (UPTREND 3757 vs DOWNTREND 362; STRONG_DOWNTREND 1829 vs STRONG_UPTREND 197) reflects the real, directionally-skewed historical market during this window** (see the transition table, Section 16 below — this window shows a sustained downtrend into early September followed by a recovery), not a coded bias. Per the task's own explicit instruction, this is not treated as a defect.

## 9. Volume/Pip Regime Coverage

VOLATILITY_EXPANSION and VOLATILITY_COMPRESSION are the two states directly reading the Volume×Pip regime (`ClassifyVolumePipRegime()`); both show full non-zero coverage (100%) with materially different central tendencies (mean 19.8 vs 39.6), confirming the two states are measuring genuinely different regimes rather than duplicating each other (see overlap analysis, Section 10 — their correlation is **-0.92**, strongly and correctly anti-correlated, exactly as an expansion/compression pair should be).

## 10. Overlap / Correlation Matrix — Notable Pairs

Full pairwise matrix (105 pairs) is in `market_dna_replay_summary.json`. Highlights:

| Pair | Correlation | Interpretation |
|---|---|---|
| STRONG_UPTREND / UPTREND | **+0.962** | Very high — expected, since STRONG_UPTREND's formula is 80% the same structural score UPTREND reads, plus a 20% confirmation slot. Not redundant: STRONG_UPTREND requires materially higher structural quality to score at all (its own max 80.7 vs UPTREND's max 90.0, but STRONG_UPTREND's ARGMAX win share is far lower — it only wins when genuinely dominant). |
| STRONG_DOWNTREND / DOWNTREND | **+0.961** | Same relationship, mirrored. |
| VOLATILITY_EXPANSION / VOLATILITY_COMPRESSION | **-0.917** | Strongly anti-correlated, as an expansion/compression pair should be — evidence of complementary, not duplicate, measurement. |
| CHOPPY / NEUTRAL | **+0.584** | Moderate positive correlation — both rise in low-net-displacement conditions, but CHOPPY additionally requires alternation (its own distinct dimension) while NEUTRAL requires balance without requiring alternation. `coHighGE50` co-occurrence is only 39/6911 (0.6%) — genuinely rare simultaneous high scoring despite the correlation, indicating distinct triggers most of the time. |
| VOLATILITY_EXPANSION / VOLATILE | +0.609 | Moderate — VOLATILE's own formula explicitly multiplies magnitude by an independent instability factor (poor directional persistence), so it is a stricter, rarer subset of "large range," not a duplicate of VOLATILITY_EXPANSION. |
| EXPANSION / COMPRESSION | **0.0000 (undefined — zero variance)** | See Section 17 below — both are pinned to a constant 50.0, so no meaningful correlation can be computed; this is the single most important finding of this replay. |
| STRONG_UPTREND / PULLBACK_DOWN | -0.509 | Expected — a strong uptrend and a bearish pullback are close to mutually exclusive market descriptions. |

No pair showed both (a) correlation ≥0.85 **and** (b) `coHighGE70` co-occurrence exceeding single digits, other than the STRONG/normal-trend pairs discussed above, which are architecturally expected (STRONG_* is explicitly designed as UPTREND/DOWNTREND's own stricter-confirmation sibling, not an independent measurement).

## 11. Rare-State Analysis

- **VOLATILE** (44.3% non-zero, mean 3.2, only 5/6911 ARGMAX wins raw / 2 calibrated) — genuinely rare, but the P95=15.8 and occasional max=90.0 spikes confirm the formula is alive and capable of firing sharply when its instability gate is met; it is not dead, merely conditioned on a genuinely uncommon joint (large range AND poor directional persistence) during this window.
- **PULLBACK_UP / PULLBACK_DOWN** — both score non-zero on roughly half of all bars (49.1% / 42.5%) but almost never reach ARGMAX-winning territory (14 / 3 raw wins; 5 / **0** calibrated wins) — their own mean scores (7.5 / 6.4) are far below every other active state's mean, meaning they are structurally outcompeted rather than absent. See Section 17 for the calibration implication.
- **CHOPPY** — 100% non-zero but capped at max=66.8 in this window (never reaches ≥70), consistent with a genuinely non-extreme choppy period rather than a broken formula (its own component gates — alternation, gross/net inefficiency — were all confirmed live-computing via the `_detail` diagnostic sub-blocks in `dna_raw_scores.jsonl`).

## 12. Never-Observed States

**None of the 15 active states were never-observed.** Every state has ≥1 non-zero observation and a real "first observed"/"last observed" timestamp spanning nearly the full replay window. The only state with **zero ARGMAX wins** (calibrated) in this window is **PULLBACK_DOWN** — it scores meaningfully (max 70.1, 24 bars ≥50) but its calibrated score never surpassed every competing active state's calibrated score on any of the 6911 bars replayed. This is evidence worth flagging for a future calibration review (its placeholder mean=50.0/stdev=15.0 calibration, shared with PULLBACK_UP, may not reflect its true real-data distribution — PULLBACK_UP's own real mean was measurably higher, 7.5 vs 6.4, enough to tip calibrated competitiveness in its favor over this sample), but is explicitly **not** a redundancy or removal candidate per the task's own final decision rule (rare ARGMAX wins alone is not sufficient grounds).

## 13. Replay-vs-Recorded-Log Validation

Direct comparison was attempted against `dna_raw_scores.jsonl`'s own recorded raw-score rows. Two limitations were found and are reported rather than silently worked around:

1. **Symbol mismatch across the file's history.** `dna_raw_scores.jsonl` contains rows recorded against `XAUUSD247` (used by production until 2026-09-04/05, when the broker rejected orders on that symbol — error 10044, FIFO_CLOSE — and the EA was reverted to run on `XAUUSD`, per `Inp_TradeSymbol`'s own source comment). The replay was run against `XAUUSD` (the currently-live symbol) per explicit confirmation ("this is the correct one XAUUSD"). Exact bar-for-bar comparison against the pre-09-04 `XAUUSD247` rows would compare two different underlying instruments and was correctly not attempted.
2. **Structural difference: `runningIncluded`.** Every recorded production row inspected carries `"runningIncluded":true` (production always evaluates live, mid-tick, with the still-forming M1 candle folded in). The replay, by design and per this task's own explicit no-look-ahead requirement, always evaluates with `runningIncluded=false` (there is no "still forming" candle at a historical closed-bar boundary). This means an exact numeric match between a replayed bar and a recorded live row is **not expected by construction** — the two are deliberately evaluating slightly different inputs (closed-only vs closed-plus-partial). This is the single most important honest caveat of this replay and is why Section 17 exists.

Given these two structural differences, a literal per-bar diff was not meaningful. Instead, validation was performed by confirming **formula equivalence** (every evaluator function is a verbatim, line-for-line copy of the current production source — see Section 5's own hash-comparison note) and by the discovery in Section 17, which independently confirms both the replay's correctness (it faithfully reproduces the EXPANSION/COMPRESSION=50 identity that the formula guarantees) and explains the small, genuine discrepancy observed in live-only data.

**Recorded-log match rate: not computable as an exact percentage** (structurally non-comparable inputs, per above) — reported honestly as N/A rather than a fabricated or misleading number.

## 14. No-Look-Ahead Audit

**0 violations across all 6911 replayed bars.** Every historical helper (`BuildMarketDnaWindow30_Historical`, `ComputeVolumeDna_Historical`, `EvaluateCandleIntelligence_Historical`) slices the single one-time `CopyRates()` fetch starting at the evaluation's own offset and moving only to higher (chronologically older) indices — by construction, no bar with a time later than the evaluation point's own reference bar can ever be read. This was additionally verified empirically per-bar (the replay's own runtime assertion), not merely assumed from the code structure. Shift 0 (the running candle) was never fetched anywhere in the replay script — confirmed by direct source grep.

Also explicitly confirmed: none of the 3 retired-compatibility states (STRONG_TREND, INSTITUTIONAL_BUYING, INSTITUTIONAL_SELLING) won ARGMAX on any of the 6911 bars (their scores are hard-fixed to 0.0, exactly as production computes them, and the replay's ARGMAX loop — a byte-for-byte copy of production's own active-state-only loop — structurally cannot select them).

## 15. Data Gaps

**0 gaps requiring exclusion.** The replay window (2026-08-30 22:01 → 2026-09-06 22:22) is one continuous run of 6911 consecutive M1 bars with no `INSUFFICIENT_HISTORY` bars reported at any point after the initial 82-bar warm-up (which itself resolved cleanly since 6911 bars comfortably exceeds that minimum). No weekend/market-closed gap fell inside the replayed window in a way that produced an invalid evaluation point (the replay was run after live trading had resumed, well past any such gap).

## 16. Exceptions

**0 script exceptions/crashes.** The replay ran to completion (6911/6911 bars processed) with no runtime errors. One **algebraic/formula-level finding** was surfaced (not a script exception) — see Section 17.

## 17. Conclusions

### The headline finding: EXPANSION and COMPRESSION are mathematically pinned to exactly 50.0

The replay data shows **EXPANSION and COMPRESSION scored exactly 50.000 on all 6911/6911 bars** (mean = median = P90 = P95 = max = 50.000 for both, zero variance). This is not a replay artifact — it follows directly from the production formula itself:

```
scores[LDNA_COMPRESSION] = Clamp0to100((100.0-ci.aggression)*0.5 + ci.candleQuality*0.5)
scores[LDNA_EXPANSION]   = Clamp0to100(ci.aggression*0.5 + ci.noiseIndex*0.5)
```

For any candle, `body% + upperWick% + lowerWick% ≡ 100%` of its own range (a geometric identity — the three pieces exactly partition the candle). Averaged over any window, this means `aggression + noiseIndex ≡ 100` and (since `candleQuality = 100 - noiseIndex`) `candleQuality ≡ aggression`. Substituting:

```
EXPANSION   = aggression*0.5 + noiseIndex*0.5        = 0.5*(aggression + noiseIndex)        = 0.5*100 = 50
COMPRESSION = (100-aggression)*0.5 + candleQuality*0.5 = (100-aggression)*0.5 + aggression*0.5 = 50
```

**Both formulas are structurally guaranteed to equal exactly 50.0 for any input**, closed-candle-only. This was independently corroborated against live production data (`dna_raw_scores.jsonl`): the handful of recorded live rows where EXPANSION/COMPRESSION deviate from 50.0 (6 of 250 sampled) all carry `"runningIncluded":true` — the deviation traces to the still-forming running candle occasionally having a near-zero range, which triggers the `if(range<=0.0) range=_Point` floor and breaks the clean identity for that one candle's contribution. The replay itself never exercises this path (it correctly never evaluates a running candle, per the no-look-ahead requirement), which is exactly why it shows zero deviation while live production shows a small amount.

**Consequence for ARGMAX**: EXPANSION still won ARGMAX (raw) 550 times and COMPRESSION 109 times in this replay — purely because 50.0 was occasionally still the single highest raw score among all 15 states on a very quiet bar, not because either formula measured anything about that specific bar. After calibration, this collapses further (EXPANSION 74 wins, COMPRESSION 6 wins) since calibration's own Z-score against a mean of 50.0/stdev of 15.0 for a value that is ALWAYS exactly 50.0 produces a Z-score of exactly 0 every single time, i.e., calibrated score is always exactly 50.0 too — the two states are **structurally incapable of ever registering as "elevated" or "notably low" under calibration**, which is itself informative.

**This is squarely a "formula/test issue" finding** (Section 18/19's own explicit category), reported here for future review — **not acted on in this task**, per the explicit "do not modify production Market DNA logic" instruction and "this task is measurement only."

### Does the 15-state architecture provide meaningful historical coverage?

**Yes, with one clear exception.** 13 of the 15 active states show genuine, non-degenerate score variance tied to real market structure (directional trend states track the real, skewed bull/bear balance of this specific week; volatility states show the expected strong anti-correlation; CHOPPY/NEUTRAL show plausible, moderate overlap without duplication). The architecture's directional/volatility/behavior taxonomy is internally coherent — the transition table (Section 8 of the summary JSON) shows the market moving through a legible sequence of states (STRONG_DOWNTREND → DOWNTREND → UPTREND → STRONG_UPTREND and back, VOLATILITY_COMPRESSION → STRONG_DOWNTREND/UPTREND as compressed ranges resolve into trends) rather than random noise.

The **EXPANSION/COMPRESSION pair is the one architectural weak point** this replay surfaces: both are mathematically inert (always 50.0), so — while they are not "redundant" in the sense of duplicating another state's real measurement — they contribute **zero discriminating information** to the 15-state vector as currently implemented. This is worth a dedicated follow-up review of their own formula (separate task, per this task's own explicit scope boundary), not a recommendation to remove them here.

### Classification of all 15 states

- **Strongly evidenced** (full non-zero coverage, meaningful score spread, real ARGMAX participation): STRONG_UPTREND, STRONG_DOWNTREND, UPTREND, DOWNTREND, VOLATILITY_EXPANSION, VOLATILITY_COMPRESSION, NEUTRAL, CHOPPY.
- **Moderately evidenced** (partial non-zero coverage but clear, real signal when active): WEAK_UPTREND, WEAK_DOWNTREND, PULLBACK_UP.
- **Rare but valid** (infrequent activation, but the formula demonstrably fires correctly and meaningfully when conditions are met): VOLATILE, PULLBACK_DOWN.
- **Currently unobserved**: none — all 15 states registered at least one non-zero observation.
- **Formula/measurement issue flagged for separate review**: EXPANSION, COMPRESSION (mathematically pinned to 50.0 by construction — see above).

## 18. Recommendations

1. **Do not remove or alter EXPANSION/COMPRESSION in this task** — flag for a dedicated, separate review of their formula's mathematical structure (the current 50/50 blend of two identity-linked terms cancels out by construction; a genuine fix would need to read a different signal pair, not a lookback/threshold tweak).
2. **Consider a dedicated recalibration pass for PULLBACK_UP/PULLBACK_DOWN** once enough real `pullback_dna.jsonl` samples accumulate — both currently share a placeholder mean=50.0/stdev=15.0 calibration that never reflects either state's own real (much lower, ~6-8 mean) distribution, which appears to be why PULLBACK_DOWN never won ARGMAX (calibrated) despite scoring meaningfully on 42.5% of bars. This is a calibration-data question, not a formula defect, and is out of this task's own scope to act on.
3. **No other state shows sufficient evidence to be flagged as redundant** under this task's own final decision rule (substantial volume + meaningful overlap + no unique coverage + strong enough evidence) — the STRONG_*/normal-trend correlation, while high, reflects an intentional, documented architectural design (STRONG_* as a stricter-confirmation sibling), not duplication.

---

## Validation Requirements

```
COMPILE:                   PASS (0 errors, 0 warnings)
PRODUCTION CODE CHANGED:   NO
TRADING ACTIONS:           0
LOOK-AHEAD VIOLATIONS:     0 / 6911
REPLAY EVALUATIONS:        6911
15 ACTIVE DNA STATES:      ALL (all 15 registered non-zero observations)
RECORDED-LOG MATCH RATE:   N/A (structurally non-comparable inputs — see Section 13)
DATA GAPS:                 0
EXCEPTIONS:                0
```

**Does the current 15-DNA architecture provide meaningful historical market coverage?**
Yes — 13 of 15 states demonstrate real, non-degenerate, market-structure-linked scoring behavior across 6911 replayed bars. EXPANSION and COMPRESSION are the one exception: both are mathematically pinned to exactly 50.0 by the current formula's own algebraic structure, contributing no discriminating signal, and are flagged here for a dedicated follow-up review rather than acted on in this measurement-only task.

**Which of the 15 states are strongly evidenced / moderately evidenced / rare but valid / currently unobserved?**
See the classification list in Section 17 above. No state is currently unobserved; none were removed, altered, or recalibrated as part of this task.
