"""Optional PostgreSQL persistence for everything the EA writes to JSON.

Activated only when the DATABASE_URL env var is set (e.g.
"postgresql://user:pass@host:5432/dbname"). When unset, or when the
connection fails, main.py falls back to reading the data/*.json(l) files
directly (or the demo fixtures) - same live/demo-degradation pattern used
everywhere else in this dashboard, so a missing/unreachable database never
breaks the UI.

main.py's background sync loop (started in the FastAPI startup hook) calls
sync_all() every few seconds, mirroring bars.jsonl / trades.jsonl /
logs.jsonl / equity.jsonl / positions.json / live_signal.json into Postgres
automatically - Postgres is the durable, queryable historical record; the
dashboard itself keeps reading straight from the EA's JSON files for
lowest latency.
"""

from __future__ import annotations

import json
import os
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

try:
    import asyncpg
except ImportError:
    asyncpg = None

DATABASE_URL = os.environ.get("DATABASE_URL")

_pool: Optional["asyncpg.Pool"] = None

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS bars (
    symbol      TEXT NOT NULL,
    timeframe   TEXT NOT NULL,
    time        TIMESTAMPTZ NOT NULL,
    open        DOUBLE PRECISION NOT NULL,
    high        DOUBLE PRECISION NOT NULL,
    low         DOUBLE PRECISION NOT NULL,
    close       DOUBLE PRECISION NOT NULL,
    event       TEXT,
    ticket      BIGINT,
    market_dna  JSONB,
    PRIMARY KEY (symbol, timeframe, time)
);
CREATE INDEX IF NOT EXISTS bars_time_idx ON bars (symbol, timeframe, time);

CREATE TABLE IF NOT EXISTS trades (
    position    BIGINT PRIMARY KEY,
    symbol      TEXT, type TEXT, volume DOUBLE PRECISION,
    open_price  DOUBLE PRECISION, close_price DOUBLE PRECISION,
    tp          DOUBLE PRECISION, sl DOUBLE PRECISION,
    open_time   TIMESTAMPTZ, close_time TIMESTAMPTZ,
    swap        DOUBLE PRECISION, commission DOUBLE PRECISION,
    reason      TEXT, pnl DOUBLE PRECISION,
    dna_state   TEXT, mind_votes JSONB
);
CREATE INDEX IF NOT EXISTS trades_close_time_idx ON trades (close_time);

CREATE TABLE IF NOT EXISTS logs (
    time    TIMESTAMPTZ NOT NULL,
    tag     TEXT NOT NULL,
    message TEXT NOT NULL,
    PRIMARY KEY (time, tag, message)
);
CREATE INDEX IF NOT EXISTS logs_time_idx ON logs (time);

CREATE TABLE IF NOT EXISTS equity (
    timestamp_iso TIMESTAMPTZ PRIMARY KEY,
    equity_usd    DOUBLE PRECISION NOT NULL
);

CREATE TABLE IF NOT EXISTS positions (
    ticket     BIGINT PRIMARY KEY,
    data       JSONB NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS live_signal (
    id         SMALLINT PRIMARY KEY DEFAULT 1,
    data       JSONB NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CHECK (id = 1)
);
"""


async def get_pool() -> Optional["asyncpg.Pool"]:
    global _pool
    if not DATABASE_URL or asyncpg is None:
        return None
    if _pool is not None:
        return _pool
    try:
        _pool = await asyncpg.create_pool(DATABASE_URL, min_size=1, max_size=4)
        async with _pool.acquire() as conn:
            await conn.execute(SCHEMA_SQL)
    except Exception:
        _pool = None
    return _pool


async def close_pool() -> None:
    global _pool
    if _pool is not None:
        await _pool.close()
        _pool = None


def _parse_time(t: Any) -> Optional[datetime]:
    try:
        return datetime.fromisoformat(str(t).replace("Z", "+00:00"))
    except Exception:
        return None


def _read_jsonl_rows(path: Path) -> list[dict]:
    if not path.exists():
        return []
    rows = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            rows.append(json.loads(line))
        except Exception:
            continue
    return rows


# 2026-09-16, explicit operator request ("why is working up too slow" -> root cause: _sync_loop() called
# sync_all() every 5 seconds, and sync_all() called _read_jsonl_rows() above on bars.jsonl/trades.jsonl/
# logs.jsonl/equity.jsonl - path.read_text() loads the ENTIRE file into memory and re-parses EVERY line,
# every single cycle, forever, even though only a handful of new lines were appended since the last pass.
# logs.jsonl alone was measured live at 50MB/269,503 lines and only grows - this cost was rising linearly
# with file size, on the SAME asyncio event loop the dashboard's own HTTP handlers run on, directly
# delaying whatever request happened to land during a sync pass). Fixed with a byte-offset cursor per
# path: each cycle seeks to the END of what was already read last time and reads ONLY the bytes appended
# since, so cost is now proportional to what's NEW per cycle (typically a handful of lines), never to the
# file's total size - matching the same "read only what's needed" principle _tail_jsonl() (main.py) already
# established for the DNA-detail files, applied here for continuous forward-incremental reading instead of
# a one-off tail. Confirmed safe because every DashAppendLine() call site in the EA (bars.jsonl/
# trades.jsonl/logs.jsonl/equity.jsonl included) is genuinely append-only (FileSeek(...,SEEK_END) then
# FileWriteString(), never a rewrite/truncate of an earlier line - verified by source inspection of the
# EA's own DashAppendLine()) - a byte offset can never point into content that later changed out from
# under it. In-memory only (module-level dict, not persisted) - a dashboard process restart naturally
# resets every offset to 0, causing exactly one full-file re-sync pass on the next cycle, which is safe
# and cheap to reason about since every upsert_*() call already uses "ON CONFLICT DO NOTHING"/idempotent
# upserts - a re-read of already-synced lines just re-upserts identical rows, never duplicates or corrupts
# anything in Postgres.
_sync_offsets: dict[str, int] = {}


def _read_jsonl_rows_incremental(path: Path) -> list[dict]:
    if not path.exists():
        return []
    key = str(path)
    offset = _sync_offsets.get(key, 0)
    try:
        size = path.stat().st_size
    except Exception:
        return []
    if size < offset:
        # File is SHORTER than last time - most likely an external truncation/rotation (this dashboard
        # never does this itself, but a future log-rotation script or a fresh EA session started against
        # a cleared data folder both plausibly could) - never seek to a negative/stale offset, restart
        # from the beginning instead. Safe for the same "every upsert is idempotent" reason as a process
        # restart above.
        offset = 0
    rows: list[dict] = []
    try:
        with path.open("rb") as f:
            f.seek(offset)
            data = f.read()
        # Only advance the offset past the LAST complete line (a line ending in \n) - a writer that is
        # mid-append when this read happens can leave a partial trailing line in `data`; re-reading that
        # same partial line (completed by then) on the NEXT cycle is correct, whereas advancing past it
        # now would silently drop the remainder of that row forever.
        last_newline = data.rfind(b"\n")
        if last_newline == -1:
            return []  # no complete line appended since the last read - nothing new yet
        usable = data[:last_newline]
        _sync_offsets[key] = offset + last_newline + 1
        for line in usable.decode("utf-8", errors="ignore").splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except Exception:
                continue
    except Exception:
        return []
    return rows


# ---------------------------------------------------------------------------
# bars
# ---------------------------------------------------------------------------

# 2026-08-30, explicit operator request (historical chart navigation +
# Trade History drill-down need per-candle DNA/volume context, using the
# EXISTING market_dna JSONB column - no schema change): bars.jsonl already
# carries per-bar "dnaState"/"dnaScore"/"tickVolume" fields on EVERY row
# (KMIE_MarketDNA_Lite.mq5's UpdateDashboardLogs(), unconditional per-bar
# write - see that file's own comment explaining these are the CURRENT
# candle's own DNA state), separate from the existing sparse "marketDna"
# object this column already stores (only present on TP/SL-event bars,
# {dnaState, minds} captured at POSITION-OPEN time - a DIFFERENT candle's
# state, per that same file's explicit comment warning these two must
# never be merged/conflated). CRITICAL SAFETY REQUIREMENT (explicit
# operator instruction): the existing sparse object must be PRESERVED, not
# overwritten - nested under its own "tradeCloseSnapshot" key, with the
# new per-bar fields nested under a separate "candleDna" key alongside it,
# so neither concept's fields collide or get silently dropped. A row with
# no event has "tradeCloseSnapshot": None but still gets a real
# "candleDna" object whenever the source line has dnaState/dnaScore.
def _build_market_dna_payload(row: dict) -> Optional[dict]:
    trade_close_snapshot = row.get("marketDna")  # existing sparse {dnaState,minds}, untouched if present
    candle_dna = None
    if row.get("dnaState") is not None or row.get("dnaScore") is not None or row.get("tickVolume") is not None:
        candle_dna = {
            "dnaState": row.get("dnaState"),
            "dnaScore": row.get("dnaScore"),
            "tickVolume": row.get("tickVolume"),
        }
    if trade_close_snapshot is None and candle_dna is None:
        return None
    return {"tradeCloseSnapshot": trade_close_snapshot, "candleDna": candle_dna}


async def upsert_bars(symbol: str, timeframe: str, rows: list[dict]) -> int:
    pool = await get_pool()
    if pool is None:
        return 0
    records = []
    for r in rows:
        t = _parse_time(r.get("time"))
        if t is None:
            continue
        dna_payload = _build_market_dna_payload(r)
        records.append((
            symbol, timeframe, t,
            float(r.get("open") or 0), float(r.get("high") or 0),
            float(r.get("low") or 0), float(r.get("close") or 0),
            r.get("event"), r.get("ticket"),
            json.dumps(dna_payload) if dna_payload is not None else None,
        ))
    if not records:
        return 0
    async with pool.acquire() as conn:
        await conn.executemany(
            """
            INSERT INTO bars (symbol, timeframe, time, open, high, low, close, event, ticket, market_dna)
            VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10::jsonb)
            ON CONFLICT (symbol, timeframe, time) DO UPDATE SET
                open = EXCLUDED.open, high = EXCLUDED.high,
                low = EXCLUDED.low, close = EXCLUDED.close,
                event = EXCLUDED.event, ticket = EXCLUDED.ticket,
                -- 2026-08-30: COALESCE-merge, not a blind overwrite - a resync of an
                -- OLDER line (e.g. this same bar's row re-read from bars.jsonl on a
                -- later sync_all() pass) always re-derives the IDENTICAL payload from
                -- the SAME append-only source line (bars.jsonl lines are never edited
                -- after being written), so this is safe/idempotent; COALESCE only
                -- protects against the theoretical case of a row somehow arriving
                -- with a null payload after already having a real one, never
                -- discarding existing data for a "no new info this pass" write.
                market_dna = COALESCE(EXCLUDED.market_dna, bars.market_dna)
            """,
            records,
        )
    return len(records)


# 2026-08-30: unpacks market_dna's nested {tradeCloseSnapshot, candleDna}
# shape (see _build_market_dna_payload's header above). Backward-compatible
# with rows written BEFORE this task (a flat {dnaState, minds} object, no
# nesting) - those are treated as a tradeCloseSnapshot with no candleDna,
# exactly matching what they always meant, never fabricating a candleDna
# value that wasn't actually recorded. Returns None for any field/key that
# genuinely isn't present - never invents a value.
def _unpack_market_dna(raw) -> dict:
    parsed = json.loads(raw) if isinstance(raw, str) else raw
    if not isinstance(parsed, dict):
        return {"marketDna": None, "dnaState": None, "dnaScore": None, "tickVolume": None}
    if "tradeCloseSnapshot" in parsed or "candleDna" in parsed:
        snapshot = parsed.get("tradeCloseSnapshot")
        candle = parsed.get("candleDna") or {}
    else:
        # Pre-existing (pre-nesting) row: the whole object IS the old sparse
        # trade-close snapshot - never reinterpreted as candleDna.
        snapshot = parsed
        candle = {}
    return {
        "marketDna": snapshot,
        "dnaState": candle.get("dnaState"),
        "dnaScore": candle.get("dnaScore"),
        "tickVolume": candle.get("tickVolume"),
    }


async def fetch_bars(symbol: str, timeframe: str, limit: int) -> Optional[list[dict]]:
    pool = await get_pool()
    if pool is None:
        return None
    async with pool.acquire() as conn:
        rows = await conn.fetch(
            """
            SELECT time, open, high, low, close, event, ticket, market_dna
            FROM bars WHERE symbol = $1 AND timeframe = $2
            ORDER BY time DESC LIMIT $3
            """,
            symbol, timeframe, limit,
        )
    out = []
    for row in reversed(rows):
        unpacked = _unpack_market_dna(row["market_dna"])
        out.append({
            "time": row["time"].isoformat().replace("+00:00", "Z"),
            "open": row["open"], "high": row["high"],
            "low": row["low"], "close": row["close"],
            "event": row["event"], "ticket": row["ticket"],
            **unpacked,
        })
    return out


# 2026-08-30, explicit operator request: PostgreSQL-only historical cursor
# read - the counterpart to fetch_bars() above but anchored BEFORE a given
# timestamp instead of "newest N". Used exclusively by the new
# /api/price/history/before endpoint (main.py) for historical chart
# panning; NEVER called from the live path (_bars() in main.py reads
# bars.jsonl directly and does not use this module for live data at all -
# see that function's own header comment). Returns None (not an empty
# list) when Postgres is unreachable, so the caller can distinguish "no
# older data exists" (empty list) from "couldn't check" (None) and report
# an honest unavailable state rather than silently substituting anything.
async def fetch_bars_before(symbol: str, timeframe: str, before: datetime, limit: int) -> Optional[list[dict]]:
    pool = await get_pool()
    if pool is None:
        return None
    async with pool.acquire() as conn:
        rows = await conn.fetch(
            """
            SELECT time, open, high, low, close, event, ticket, market_dna
            FROM bars WHERE symbol = $1 AND timeframe = $2 AND time < $3
            ORDER BY time DESC LIMIT $4
            """,
            symbol, timeframe, before, limit,
        )
    out = []
    for row in reversed(rows):
        unpacked = _unpack_market_dna(row["market_dna"])
        out.append({
            "time": row["time"].isoformat().replace("+00:00", "Z"),
            "open": row["open"], "high": row["high"],
            "low": row["low"], "close": row["close"],
            "event": row["event"], "ticket": row["ticket"],
            **unpacked,
        })
    return out


# 2026-08-31, explicit operator request (MARKET DNA VISUAL LAB - REAL
# HISTORICAL M1 DATA): every current DNA state's enum name, used ONLY to
# exclude LDNA_LIQUIDITY_HUNT (permanently removed from the EA 2026-08-30 -
# confirmed still present in bars written BEFORE that removal) from this
# historical query - never used to fabricate/relabel anything. Kept in sync
# with KMIE_MarketDNA_Lite.mq5's own ENUM_LITE_DNA by hand, same convention
# already established for the live Visual Lab (index.html's own
# MARKET_DNA_STATES list).
_CURRENT_DNA_STATES = frozenset({
    "STRONG_TREND", "WEAK_TREND", "PULLBACK", "COMPRESSION", "EXPANSION",
    "ACCUMULATION", "DISTRIBUTION", "STOP_HUNT", "BREAKOUT", "FALSE_BREAKOUT",
    "TREND_EXHAUSTION", "VOLATILITY_EXPANSION", "VOLATILITY_COMPRESSION",
    "INSTITUTIONAL_BUYING", "INSTITUTIONAL_SELLING", "CHOPPY", "NEUTRAL",
    "STRONG_UPTREND", "STRONG_DOWNTREND", "UPTREND", "DOWNTREND",
    "VOLATILE", "QUIET", "RANGE", "REVERSAL",
})


async def fetch_dna_history(symbol: str, timeframe: str, since: datetime, until: Optional[datetime] = None) -> Optional[list[dict]]:
    """Read-only: every bar (time, OHLC, dnaState, dnaScore) from `since`
    up to and including `until` (when given) for the given symbol/timeframe,
    ascending by time. This is the ONLY query the Market DNA Visual Lab's
    historical-sample endpoint runs against Postgres - grouping into
    consecutive same-state runs and ranking candidates happens in Python
    (main.py), not SQL, so the exact selection logic stays
    readable/auditable in one place. Returns None (never []) when the pool
    itself is unavailable, so the caller can tell "no database" apart from
    "database reachable, zero matching rows".
    """
    pool = await get_pool()
    if pool is None:
        return None
    async with pool.acquire() as conn:
        if until is not None:
            rows = await conn.fetch(
                """
                SELECT time, open, high, low, close, market_dna
                FROM bars WHERE symbol = $1 AND timeframe = $2 AND time >= $3 AND time <= $4
                    AND market_dna IS NOT NULL
                ORDER BY time ASC
                """,
                symbol, timeframe, since, until,
            )
        else:
            rows = await conn.fetch(
                """
                SELECT time, open, high, low, close, market_dna
                FROM bars WHERE symbol = $1 AND timeframe = $2 AND time >= $3
                    AND market_dna IS NOT NULL
                ORDER BY time ASC
                """,
                symbol, timeframe, since,
            )
    out = []
    for row in rows:
        unpacked = _unpack_market_dna(row["market_dna"])
        state = unpacked.get("dnaState")
        # LIQUIDITY_HUNT filtered here, at the single read path this
        # feature uses - never re-included downstream.
        if state is not None and state not in _CURRENT_DNA_STATES:
            continue
        out.append({
            "time": row["time"].isoformat().replace("+00:00", "Z"),
            "open": row["open"], "high": row["high"],
            "low": row["low"], "close": row["close"],
            "dnaState": state, "dnaScore": unpacked.get("dnaScore"),
        })
    return out


# ---------------------------------------------------------------------------
# trades
# ---------------------------------------------------------------------------

async def upsert_trades(rows: list[dict]) -> int:
    pool = await get_pool()
    if pool is None:
        return 0
    records = []
    for r in rows:
        pos = r.get("position")
        if pos is None:
            continue
        mv = r.get("mindVotes")
        records.append((
            int(pos), r.get("symbol"), r.get("type"), r.get("volume"),
            r.get("openPrice"), r.get("closePrice"), r.get("tp"), r.get("sl"),
            _parse_time(r.get("openTime")), _parse_time(r.get("closeTime")),
            r.get("swap"), r.get("commission"), r.get("reason"), r.get("pnl"),
            r.get("dnaState"), json.dumps(mv) if mv is not None else None,
        ))
    if not records:
        return 0
    async with pool.acquire() as conn:
        await conn.executemany(
            """
            INSERT INTO trades (position, symbol, type, volume, open_price, close_price,
                tp, sl, open_time, close_time, swap, commission, reason, pnl, dna_state, mind_votes)
            VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16::jsonb)
            ON CONFLICT (position) DO UPDATE SET
                close_price = EXCLUDED.close_price, close_time = EXCLUDED.close_time,
                swap = EXCLUDED.swap, commission = EXCLUDED.commission,
                reason = EXCLUDED.reason, pnl = EXCLUDED.pnl,
                dna_state = EXCLUDED.dna_state, mind_votes = EXCLUDED.mind_votes
            """,
            records,
        )
    return len(records)


# ---------------------------------------------------------------------------
# logs
# ---------------------------------------------------------------------------

async def upsert_logs(rows: list[dict]) -> int:
    pool = await get_pool()
    if pool is None:
        return 0
    records = []
    for r in rows:
        t = _parse_time(r.get("time"))
        if t is None:
            continue
        records.append((t, str(r.get("tag") or "LOG"), str(r.get("message") or "")))
    if not records:
        return 0
    async with pool.acquire() as conn:
        await conn.executemany(
            "INSERT INTO logs (time, tag, message) VALUES ($1,$2,$3) ON CONFLICT DO NOTHING",
            records,
        )
    return len(records)


# ---------------------------------------------------------------------------
# equity
# ---------------------------------------------------------------------------

async def upsert_equity(rows: list[dict]) -> int:
    pool = await get_pool()
    if pool is None:
        return 0
    records = []
    for r in rows:
        t = _parse_time(r.get("timestamp_iso"))
        if t is None:
            continue
        records.append((t, float(r.get("equity_usd") or 0)))
    if not records:
        return 0
    async with pool.acquire() as conn:
        await conn.executemany(
            """
            INSERT INTO equity (timestamp_iso, equity_usd) VALUES ($1,$2)
            ON CONFLICT (timestamp_iso) DO UPDATE SET equity_usd = EXCLUDED.equity_usd
            """,
            records,
        )
    return len(records)


# ---------------------------------------------------------------------------
# positions (full-snapshot replace each sync, matching positions.json's
# own overwrite-every-tick semantics)
# ---------------------------------------------------------------------------

async def replace_positions(rows: list[dict]) -> int:
    pool = await get_pool()
    if pool is None:
        return 0
    tickets = [int(r["ticket"]) for r in rows if r.get("ticket") is not None]
    async with pool.acquire() as conn:
        async with conn.transaction():
            if tickets:
                await conn.execute("DELETE FROM positions WHERE ticket <> ALL($1::bigint[])", tickets)
            else:
                await conn.execute("DELETE FROM positions")
            for r in rows:
                if r.get("ticket") is None:
                    continue
                await conn.execute(
                    """
                    INSERT INTO positions (ticket, data, updated_at) VALUES ($1, $2::jsonb, now())
                    ON CONFLICT (ticket) DO UPDATE SET data = EXCLUDED.data, updated_at = now()
                    """,
                    int(r["ticket"]), json.dumps(r),
                )
    return len(rows)


# ---------------------------------------------------------------------------
# live_signal (single row, id=1)
# ---------------------------------------------------------------------------

async def upsert_live_signal(data: dict) -> bool:
    pool = await get_pool()
    if pool is None:
        return False
    async with pool.acquire() as conn:
        await conn.execute(
            """
            INSERT INTO live_signal (id, data, updated_at) VALUES (1, $1::jsonb, now())
            ON CONFLICT (id) DO UPDATE SET data = EXCLUDED.data, updated_at = now()
            """,
            json.dumps(data),
        )
    return True


# ---------------------------------------------------------------------------
# Continuous sync: mirrors every EA-written JSON file under data_dir into
# Postgres. Safe to call repeatedly - every write is an idempotent upsert.
# ---------------------------------------------------------------------------

async def sync_all(data_dir: Path, symbol: str = "XAUUSDm", timeframe: str = "M1") -> dict:
    pool = await get_pool()
    if pool is None:
        return {}
    counts = {}
    # 2026-09-16: reads ONLY the bytes appended to each file since the last cycle (see
    # _read_jsonl_rows_incremental()'s own header for the full "why is working up too slow" root cause
    # and fix) - was _read_jsonl(...) (whole-file read + re-parse, every 5-second cycle, forever).
    counts["bars"] = await upsert_bars(symbol, timeframe, _read_jsonl_rows_incremental(data_dir / "bars.jsonl"))
    counts["trades"] = await upsert_trades(_read_jsonl_rows_incremental(data_dir / "trades.jsonl"))
    counts["logs"] = await upsert_logs(_read_jsonl_rows_incremental(data_dir / "logs.jsonl"))
    counts["equity"] = await upsert_equity(_read_jsonl_rows_incremental(data_dir / "equity.jsonl"))

    positions_path = data_dir / "positions.json"
    if positions_path.exists():
        try:
            positions = json.loads(positions_path.read_text(encoding="utf-8"))
            if isinstance(positions, list):
                counts["positions"] = await replace_positions(positions)
        except Exception:
            pass

    signal_path = data_dir / "live_signal.json"
    if signal_path.exists():
        try:
            signal = json.loads(signal_path.read_text(encoding="utf-8"))
            if isinstance(signal, dict):
                await upsert_live_signal(signal)
                counts["live_signal"] = 1
        except Exception:
            pass

    return counts


async def sync_jsonl_file(path: Path, symbol: str, timeframe: str) -> int:
    """One-shot bars ingest, kept for the FastAPI startup hook's first call
    (sync_all() below supersedes this for the recurring background loop)."""
    count = await upsert_bars(symbol, timeframe, _read_jsonl_rows(path))
    # 2026-09-16: seed the incremental cursor to the end of what THIS full read already covered, so the
    # very next _sync_loop() cycle (sync_all() -> _read_jsonl_rows_incremental()) picks up starting from
    # here instead of re-reading/re-upserting this entire file a second time on its first pass. Harmless
    # either way (idempotent upserts), just wasted work without this.
    try:
        _sync_offsets[str(path)] = path.stat().st_size
    except Exception:
        pass
    return count
