"""Gold Trading Dashboard - FastAPI backend.

This is an EXACT 1:1 clone of the operator's existing "Trading Terminal"
dashboard frontend (monitoring/dashboard/static/index.html, copied verbatim
into app/static/index.html - same panels, same CSS, same React components,
same API contract). This file re-implements that contract's server side.

Several panels in the original frontend are tied to concepts that don't
exist yet for the MT5/gold EA this dashboard will eventually watch (HMM
regime confidence, audit middleware, a SQLite alerts DB, per-bar-cycle
telemetry). Per explicit operator instruction, those are NOT remapped or
faked - they're served as honest, correctly-shaped PLACEHOLDER data (empty
lists / neutral values / ok:true) so the UI renders every panel exactly as
in the original, with nothing erroring, until real data is wired up.

Positions/logs/equity read from ../data/*.json if present (see the Steps 1-9
Entry Intelligence work this session) - same live/demo switch as before.
"""

from __future__ import annotations

import asyncio
import bisect
import json
import os
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Optional

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles

from . import db

APP_DIR = Path(__file__).resolve().parent
PACKAGE_DIR = APP_DIR.parent
STATIC_DIR = APP_DIR / "static"

# EA-written JSON logs (bars.jsonl/trades.jsonl/logs.jsonl/positions.json/
# live_signal.json/equity.jsonl) land under the MT5 terminal's own
# MQL5\Files\<Inp_DashboardLogFolder>\ sandbox - the EA cannot write
# anywhere else. DASHBOARD_DATA_DIR points this backend at that folder
# directly. Falls back to this session's known terminal path, then to
# ./data (demo mode), so the dashboard still renders with no EA running.
# 2026-09-02, explicit operator request: the EA's own Inp_DashboardLogFolder input controls which of
# two known folders actually receives live writes - "GoldDashboard" (the original shared folder) or
# "GoldDashboard_KMIE_MarketDNA_Lite" (the upgraded EA's own dedicated folder, the operator's stated
# intent). In practice this has already proven to flip unpredictably: MT5 can restore a REMEMBERED
# input value on reattach that overrides even a freshly recompiled source default, so which folder is
# actually live cannot be assumed from source/config alone - confirmed live 2026-09-02 (dashboard
# pointed at the new folder per explicit instruction, EA kept writing the old one regardless).
# _resolve_known_terminal_dir() below picks WHICHEVER of the two has the more recently modified
# live_signal.json at STARTUP - i.e. whichever the EA is actually, currently writing to - rather than
# hardcoding one. This does not re-check at runtime (a folder switch mid-session still needs a
# restart, same as any other DATA_DIR change), but it removes the need to manually flip this file
# and restart every time MT5's own reattach behavior decides which folder wins.
_GOLDDASHBOARD_OLD = (
    Path.home() / "AppData" / "Roaming" / "MetaQuotes" / "Terminal"
    / "D0E8209F77C8CF37AD8BF550E51FF075" / "MQL5" / "Files" / "GoldDashboard"
)
_GOLDDASHBOARD_NEW = (
    Path.home() / "AppData" / "Roaming" / "MetaQuotes" / "Terminal"
    / "D0E8209F77C8CF37AD8BF550E51FF075" / "MQL5" / "Files" / "GoldDashboard_KMIE_MarketDNA_Lite"
)


def _resolve_known_terminal_dir() -> Optional[Path]:
    candidates = [d for d in (_GOLDDASHBOARD_OLD, _GOLDDASHBOARD_NEW) if (d / "live_signal.json").exists()]
    if not candidates:
        # Neither has ever been written yet - fall back to whichever folder itself exists (matches
        # the old single-candidate behavior), or None (demo mode) if neither does.
        for d in (_GOLDDASHBOARD_NEW, _GOLDDASHBOARD_OLD):
            if d.exists():
                return d
        return None
    return max(candidates, key=lambda d: (d / "live_signal.json").stat().st_mtime)


_KNOWN_TERMINAL_FILES = _resolve_known_terminal_dir()
if os.environ.get("DASHBOARD_DATA_DIR"):
    DATA_DIR = Path(os.environ["DASHBOARD_DATA_DIR"])
elif _KNOWN_TERMINAL_FILES is not None:
    DATA_DIR = _KNOWN_TERMINAL_FILES
else:
    DATA_DIR = PACKAGE_DIR / "data"
print(f"[startup] DATA_DIR resolved to: {DATA_DIR}")

app = FastAPI(title="Gold Trading Dashboard", docs_url=None, redoc_url=None)

started_at = datetime.now(timezone.utc)

# In-memory halt state - a real, clickable HALT/RESUME toggle (not wired to
# any live broker/EA - there is nothing to control yet), so the button in
# the Risk panel behaves like a genuine control rather than a dead element.
_halted = {"value": False}


def _read_json(path: Path, fallback: Any) -> Any:
    if not path.exists():
        return fallback
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return fallback


def _read_jsonl(path: Path, limit: int, fallback: Any) -> Any:
    if not path.exists():
        return fallback
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except Exception:
        return fallback
    out = []
    for line in lines[-limit:]:
        line = line.strip()
        if not line:
            continue
        try:
            out.append(json.loads(line))
        except Exception:
            out.append({"time": None, "tag": "RAW", "message": line})
    return out or fallback


# 2026-08-31, explicit operator request (MARKET DNA VISUAL LAB): dna_raw_scores.jsonl
# is EA-written, once/second, and grows unbounded for the life of the EA session -
# confirmed live at 528MB+ and ~600MB/day. _read_jsonl() above (path.read_text() then
# .splitlines()) would load the ENTIRE file into memory just to keep the last few
# lines - unacceptable here. This instead seeks from the END of the file in bounded
# binary chunks, stopping as soon as enough newlines have been found, so memory/IO
# cost is proportional to `limit`, never to the file's total size. Read-only; never
# writes to the file. Returns fallback (never raises) on any I/O/parse failure -
# this is diagnostic/visualization data, a read failure here must never affect
# anything else the dashboard serves.
def _tail_jsonl(path: Path, limit: int, fallback: Any) -> Any:
    if not path.exists():
        return fallback
    try:
        chunk_size = 65536
        wanted_lines = limit + 1  # +1 pad - a partial line at the very end-of-chunk boundary is discarded below, not miscounted as real
        with path.open("rb") as f:
            f.seek(0, os.SEEK_END)
            file_size = f.tell()
            data = b""
            pos = file_size
            newline_count = 0
            while pos > 0 and newline_count <= wanted_lines:
                read_size = min(chunk_size, pos)
                pos -= read_size
                f.seek(pos)
                data = f.read(read_size) + data
                newline_count = data.count(b"\n")
        text = data.decode("utf-8", errors="ignore")
        lines = text.splitlines()
    except Exception:
        return fallback
    out = []
    for line in lines[-limit:]:
        line = line.strip()
        if not line:
            continue
        try:
            out.append(json.loads(line))
        except Exception:
            continue  # a truncated first line from the chunk boundary, or a genuinely malformed row - skip, never fabricate
    return out or fallback


# ---------------------------------------------------------------------------
# DEMO fixtures (used only while data/*.json is absent)
# ---------------------------------------------------------------------------

DEMO_POSITIONS = [
    {
        "ticket": 100200001, "symbol": "XAUUSD", "type": "BUY", "volume": 0.01,
        "openPrice": 4508.32, "currentPrice": 4511.85, "sl": 4507.60, "tp": 4509.82,
        "profit": 0.35, "openTime": "2026-08-21T09:14:02Z", "magic": 100200,
    },
    {
        "ticket": 100200002, "symbol": "XAUUSD", "type": "SELL", "volume": 0.01,
        "openPrice": 4513.10, "currentPrice": 4511.85, "sl": 4514.05, "tp": 4511.60,
        "profit": 1.25, "openTime": "2026-08-21T09:41:17Z", "magic": 100200,
    },
]

DEMO_LOGS = [
    {"time": "2026-08-21T09:11:17Z", "tag": "ENTRY_APPROVAL", "message": "decision=APPROVED path=CONTINUATION direction=SELL opportunity=42"},
    {"time": "2026-08-21T09:11:17Z", "tag": "EXECUTION", "message": "SUCCESS executionStatus=FULL ticketsSent=5 ticketsWanted=5"},
    {"time": "2026-08-21T09:22:03Z", "tag": "BREAK_EVEN", "message": "ticket=100200002 profitUSD=1.02 protectedSL=4513.10 protectionUSD=0.30"},
    {"time": "2026-08-21T09:33:41Z", "tag": "TRAILING", "message": "ticket=100200002 oldSL=4513.40 newSL=4512.95 mode=STRUCTURAL_3_BAR"},
    {"time": "2026-08-21T10:11:29Z", "tag": "ENTRY_APPROVAL", "message": "decision=BLOCKED path=PULLBACK direction=BUY opportunity=43 reason=RESUMPTION_OVER_50"},
]

DEMO_EQUITY = [
    {"timestamp_iso": "2026-08-21T08:00:00Z", "equity_usd": 10000.00},
    {"timestamp_iso": "2026-08-21T08:30:00Z", "equity_usd": 9998.40},
    {"timestamp_iso": "2026-08-21T09:00:00Z", "equity_usd": 10004.20},
    {"timestamp_iso": "2026-08-21T09:30:00Z", "equity_usd": 10002.10},
    {"timestamp_iso": "2026-08-21T10:00:00Z", "equity_usd": 10011.85},
]


# ---------------------------------------------------------------------------
# OHLC bars ("EA JSON log" contract) - one line per bar in data/bars.jsonl:
#   {"time": ISO8601, "open": f, "high": f, "low": f, "close": f,
#    "dnaState": str, "dnaScore": f,
#    "event": "TP_HIT" | "SL_HIT" | null, "ticket": int | null,
#    "marketDna": {
#        "entryPath", "activeLeg", "resumptionWindow", "microConfirmed",
#        "microDirection", "opportunityState", "trailTierUSD",
#        "minds": [{"name": str, "direction": "BUY"|"SELL"|"WAIT",
#                   "score": float, "reasoning": str}, ...] (all 16 Minds,
#                   mirroring KMIE_MarketDNA_Lite.mq5's g_minds[16] /
#                   MindResult struct: name/direction/score/reasoning)
#    } | null }
# "dnaState"/"dnaScore" are the EA's own g_dnaState/g_dnaScore (ENUM_LITE_DNA
# via DnaName(), and the raw score - NOT recalculated here) as they stood at
# the moment THIS candle was written, i.e. this candle's own completed-bar
# Market DNA classification. Present on every completed M1 bar, independent
# of trade activity. Historical bars written before this field existed will
# not have it (older rows simply omit dnaState/dnaScore - never fabricated
# retroactively).
# "event"/"ticket"/"marketDna" (the nested object above, distinct from the
# top-level dnaState/dnaScore) are only present on the bar during which a
# position closed on TP or SL - the frontend highlights that bar and shows
# the full marketDna snapshot (including all 16 Mind votes) on hover. Its
# own "dnaState" sub-field is a DIFFERENT, unrelated snapshot (captured at
# the position's OPEN time, not this candle's), which is exactly why it was
# never merged with the new top-level per-candle dnaState/dnaScore fields.
# Rows optionally get mirrored into Postgres (see db.py) when DATABASE_URL
# is set; otherwise this file is the only store. dnaState/dnaScore are now
# written by the live EA as of KMIE_MarketDNA_Lite.mq5's Phase 2 Market DNA
# persistence change; demo bars below do not yet include them.
# ---------------------------------------------------------------------------

MIND_NAMES = [
    "Trend", "Momentum", "Scalping", "Reversal", "Liquidity", "Risk",
    "Volatility", "Structure", "Memory", "Pattern", "Pressure", "Energy",
    "Breakout", "Session", "Consensus", "SR",
]

# 2026-08-31, explicit operator request (MARKET DNA VISUAL LAB - REAL HISTORICAL M1
# DATA): the current 25-state Market DNA enum, in the EA's OWN order
# (KMIE_MarketDNA_Lite.mq5's ENUM_LITE_DNA) - used only to sort
# /api/dna/visual-samples's response into a stable, human-readable order. Kept in
# sync BY HAND with db._CURRENT_DNA_STATES (the set used to actually filter out the
# removed LIQUIDITY_HUNT state) and with index.html's own MARKET_DNA_STATES list -
# three independent lists is imperfect, but each already exists for a different
# reason (a Python list needs order; a Python set only needs membership; the JS list
# is a separate runtime) and none of them compute a NEW Market DNA definition -
# they're all transcriptions of the same EA source enum.
MARKET_DNA_STATE_ORDER = [
    "STRONG_TREND", "WEAK_TREND", "PULLBACK", "COMPRESSION", "EXPANSION",
    "ACCUMULATION", "DISTRIBUTION", "STOP_HUNT", "BREAKOUT", "FALSE_BREAKOUT",
    "TREND_EXHAUSTION", "VOLATILITY_EXPANSION", "VOLATILITY_COMPRESSION",
    "INSTITUTIONAL_BUYING", "INSTITUTIONAL_SELLING", "CHOPPY", "NEUTRAL",
    "STRONG_UPTREND", "STRONG_DOWNTREND", "UPTREND", "DOWNTREND",
    "VOLATILE", "QUIET", "RANGE", "REVERSAL",
]


def _demo_minds(winning_dir: str, min_votes: int):
    minds = []
    for i, name in enumerate(MIND_NAMES):
        agrees = i < min_votes
        direction = winning_dir if agrees else ("WAIT" if i % 3 == 0 else ("SELL" if winning_dir == "BUY" else "BUY"))
        minds.append({
            "name": name, "direction": direction,
            "score": round(0.55 + (i % 5) * 0.08, 2) if agrees else round(0.2 + (i % 4) * 0.05, 2),
            "reasoning": name + " " + ("aligned" if agrees else "not aligned") + " with " + winning_dir,
        })
    return minds


def _demo_bars():
    base = datetime(2026, 8, 21, 9, 0, 0, tzinfo=timezone.utc)
    price = 4506.00
    bars = []
    # Deterministic (seeded) 120-bar pseudo-random walk - fixed so the demo
    # chart is reproducible across restarts rather than actually random.
    import random
    rng = random.Random(20260821)
    bar_count = 400
    deltas = [round(rng.uniform(-0.65, 0.75), 2) for _ in range(bar_count)]
    tp_idx = 50
    sl_idx = 100
    for i, d in enumerate(deltas):
        o = price
        c = round(price + d, 2)
        hi = round(max(o, c) + 0.15, 2)
        lo = round(min(o, c) - 0.15, 2)
        bar = {
            "time": (base + timedelta(minutes=i)).isoformat().replace("+00:00", "Z"),
            "open": o, "high": hi, "low": lo, "close": c,
            "event": None, "ticket": None, "marketDna": None,
        }
        if i == tp_idx:
            bar["event"] = "TP_HIT"
            bar["ticket"] = 100200001
            bar["marketDna"] = {
                "entryPath": "CONTINUATION", "activeLeg": "EXTENSION",
                "resumptionWindow": "0_TO_80", "microConfirmed": True,
                "microDirection": "ALIGNED", "opportunityState": "OPP_COMPLETED",
                "trailTierUSD": 1.30, "minds": _demo_minds("BUY", 10),
            }
        if i == sl_idx:
            bar["event"] = "SL_HIT"
            bar["ticket"] = 100200002
            bar["marketDna"] = {
                "entryPath": "PULLBACK", "activeLeg": "PULLBACK",
                "resumptionWindow": "OVER_80", "microConfirmed": False,
                "microDirection": "NONE", "opportunityState": "OPP_EXPIRED",
                "trailTierUSD": 0.30, "minds": _demo_minds("SELL", 6),
            }
        bars.append(bar)
        price = c
    return bars


DEMO_BARS = _demo_bars()


# ---------------------------------------------------------------------------
# Closed-trade history ("data/trades.jsonl" contract) - one line per closed
# ticket, mirroring the operator's MT5 "History" tab columns exactly, plus
# two columns MT5 doesn't have: dnaState (Market DNA state at close) and
# mindVotes (the 16-Mind Vote split at close, "BUY/SELL/WAIT" counts).
# ---------------------------------------------------------------------------

def _demo_trades():
    base = datetime(2026, 8, 21, 14, 0, 0, tzinfo=timezone.utc)
    rows = [
        dict(ticket=2288093032, type="Buy", volume=0.01, openPrice=4581.127, closePrice=4582.627,
             tp=4582.627, sl=4581.427, openTime=base, closeTime=base + timedelta(minutes=3, seconds=3),
             swap=0.0, commission=-0.11, reason="Take Profit", pnl=1.50,
             dnaState="STRONG_TREND", mindVotes={"buy": 11, "sell": 3, "wait": 2}),
        dict(ticket=2288093026, type="Buy", volume=0.01, openPrice=4581.127, closePrice=4582.627,
             tp=4582.627, sl=4581.427, openTime=base, closeTime=base + timedelta(minutes=3, seconds=3),
             swap=0.0, commission=-0.11, reason="Take Profit", pnl=1.50,
             dnaState="STRONG_TREND", mindVotes={"buy": 11, "sell": 3, "wait": 2}),
        dict(ticket=2288093024, type="Buy", volume=0.01, openPrice=4581.127, closePrice=4582.627,
             tp=4582.627, sl=4581.427, openTime=base, closeTime=base + timedelta(minutes=3, seconds=3),
             swap=0.0, commission=-0.11, reason="Take Profit", pnl=1.50,
             dnaState="STRONG_TREND", mindVotes={"buy": 11, "sell": 3, "wait": 2}),
        dict(ticket=2288093030, type="Buy", volume=0.01, openPrice=4581.127, closePrice=4582.627,
             tp=4582.627, sl=4581.427, openTime=base, closeTime=base + timedelta(minutes=3, seconds=3),
             swap=0.0, commission=-0.11, reason="Take Profit", pnl=1.50,
             dnaState="STRONG_TREND", mindVotes={"buy": 11, "sell": 3, "wait": 2}),
        dict(ticket=2288093027, type="Buy", volume=0.01, openPrice=4581.127, closePrice=4582.627,
             tp=4582.627, sl=4581.427, openTime=base, closeTime=base + timedelta(minutes=3, seconds=3),
             swap=0.0, commission=-0.11, reason="Take Profit", pnl=1.50,
             dnaState="STRONG_TREND", mindVotes={"buy": 11, "sell": 3, "wait": 2}),
        dict(ticket=2288084167, type="Buy", volume=0.01, openPrice=4579.453, closePrice=4579.023,
             tp=4582.953, sl=4579.023, openTime=base - timedelta(minutes=2, seconds=47), closeTime=base - timedelta(minutes=2, seconds=44),
             swap=0.0, commission=-0.11, reason="Stop Loss", pnl=-0.43,
             dnaState="PULLBACK", mindVotes={"buy": 5, "sell": 9, "wait": 2}),
        dict(ticket=2288084168, type="Buy", volume=0.01, openPrice=4579.575, closePrice=4579.023,
             tp=4582.953, sl=4579.023, openTime=base - timedelta(minutes=2, seconds=47), closeTime=base - timedelta(minutes=2, seconds=44),
             swap=0.0, commission=-0.11, reason="Stop Loss", pnl=-0.56,
             dnaState="PULLBACK", mindVotes={"buy": 5, "sell": 9, "wait": 2}),
    ]
    out = []
    for r in rows:
        out.append({
            "symbol": "XAUUSDm",
            "type": r["type"], "volume": r["volume"],
            "openPrice": r["openPrice"], "closePrice": r["closePrice"],
            "tp": r["tp"], "sl": r["sl"], "position": r["ticket"],
            "openTime": r["openTime"].isoformat().replace("+00:00", "Z"),
            "closeTime": r["closeTime"].isoformat().replace("+00:00", "Z"),
            "swap": r["swap"], "commission": r["commission"],
            "reason": r["reason"], "pnl": r["pnl"],
            "dnaState": r["dnaState"], "mindVotes": r["mindVotes"],
        })
    return out


DEMO_TRADES = _demo_trades()


def _equity_series():
    # EA writes one JSON object per closed bar to equity.jsonl (append-only,
    # matching bars.jsonl/trades.jsonl/logs.jsonl). Legacy equity.json (a
    # single JSON array) is still honored if present, for back-compat.
    jsonl_path = DATA_DIR / "equity.jsonl"
    if jsonl_path.exists():
        return _read_jsonl(jsonl_path, 5000, DEMO_EQUITY)
    return _read_json(DATA_DIR / "equity.json", DEMO_EQUITY)


# 2026-08-29, explicit operator request ("Today P&L should be calculated
# after a 24hr cycle - remove previous day loss/profit, only present P&L").
# Mirrors the frontend's own pnlOverWindow() (index.html) EXACTLY - same
# trailing-window filter, same bar-to-bar summation, same deposit/withdrawal
# filter - so "Today" here means the real trailing 24 hours from now, not
# "since equity.jsonl's very first ever line" (the old
# last_equity - first_equity bug this replaces).
#
# 2026-08-31, explicit operator request (fix: Today P&L reading wrong):
# the funding-event filter was 5% of starting equity, which on this EA's
# small micro-lot account (~$150-250 during the observed window) is only
# $8-12 - smaller than a single real multi-position batch close routinely
# produces (verified against real equity.jsonl: many genuine one-minute
# trading steps of $10-45, i.e. 5-25% of equity, all real wins/losses, none
# of them deposits). The 5% filter was discarding the majority of real
# trading P&L every minute, not just genuine funding events. Raised to 50%
# of starting equity - still well above the account's largest observed real
# per-minute step, while still catching an actual deposit/withdrawal (those
# are typically a much larger, discrete jump - e.g. crediting $100+ into a
# sub-$300 account - not a gradual multi-lot trading result).
def _pnl_over_window(equity_points: list[dict], window_hours: float) -> dict:
    if not equity_points or len(equity_points) < 2:
        return {"delta": None, "pct": None, "available": False}
    cutoff = datetime.now(timezone.utc) - timedelta(hours=window_hours)
    pts = []
    for p in equity_points:
        raw = p.get("timestamp_iso") or p.get("timestamp")
        if not raw:
            continue
        try:
            t = datetime.fromisoformat(str(raw).replace("Z", "+00:00"))
        except Exception:
            continue
        if t >= cutoff:
            pts.append((t, p.get("equity_usd")))
    pts.sort(key=lambda x: x[0])
    if len(pts) < 2:
        return {"delta": None, "pct": None, "available": False}
    e0 = float(pts[0][1] or 0)
    if e0 <= 0:
        return {"delta": None, "pct": None, "available": False}
    max_step = e0 * 0.50
    delta = 0.0
    for i in range(1, len(pts)):
        prev_e = float(pts[i - 1][1] or 0)
        cur_e = float(pts[i][1] or 0)
        step = cur_e - prev_e
        if abs(step) < max_step:
            delta += step
    return {"delta": delta, "pct": delta / e0, "available": True}


# 2026-08-31, explicit operator request: Today P&L must reset at CALENDAR-DAY start (IST midnight,
# UTC+5:30 - the user's own local day and the broker's own server-time offset, confirmed earlier this
# session), not a rolling 24-hours-from-now window like _pnl_over_window() above still correctly
# provides for Week/Month. A genuinely separate function - _pnl_over_window() is left completely
# unmodified since Week/Month legitimately want a rolling window, only "Today" wants a calendar reset.
# Same bar-to-bar summation and same 50%-of-starting-equity funding-event filter as
# _pnl_over_window() (kept in sync deliberately, not re-derived) - only the cutoff-selection logic differs.
_IST_OFFSET = timedelta(hours=5, minutes=30)


def _pnl_since_day_start(equity_points: list[dict]) -> dict:
    if not equity_points or len(equity_points) < 2:
        return {"delta": None, "pct": None, "available": False}

    now_ist = datetime.now(timezone.utc) + _IST_OFFSET
    ist_midnight_today = now_ist.replace(hour=0, minute=0, second=0, microsecond=0)
    cutoff = ist_midnight_today - _IST_OFFSET  # convert back to UTC for comparison against equity_points' UTC timestamps

    pts = []
    for p in equity_points:
        raw = p.get("timestamp_iso") or p.get("timestamp")
        if not raw:
            continue
        try:
            t = datetime.fromisoformat(str(raw).replace("Z", "+00:00"))
        except Exception:
            continue
        if t >= cutoff:
            pts.append((t, p.get("equity_usd")))
    pts.sort(key=lambda x: x[0])
    if len(pts) < 2:
        return {"delta": None, "pct": None, "available": False}
    e0 = float(pts[0][1] or 0)
    if e0 <= 0:
        return {"delta": None, "pct": None, "available": False}

    max_step = e0 * 0.50  # same funding-event filter as _pnl_over_window(), kept in sync deliberately
    delta = 0.0
    for i in range(1, len(pts)):
        prev_e = float(pts[i - 1][1] or 0)
        cur_e = float(pts[i][1] or 0)
        step = cur_e - prev_e
        if abs(step) < max_step:
            delta += step
    return {"delta": delta, "pct": delta / e0, "available": True}


# 2026-08-31, explicit operator request: Today P&L must be EXACT, not an equity-snapshot estimate.
# Sums the real per-trade pnl+swap+commission of every trade CLOSED since local midnight (IST,
# same offset already established this session) from trades.jsonl, plus the live "profit" field of
# every currently open position from positions.json. Deliberately does not touch
# _pnl_since_day_start()/_pnl_over_window() (equity-delta estimates) - those still back Week/Month.
def _pnl_exact_since_day_start(trades: list[dict], positions: list[dict]) -> dict:
    now_ist = datetime.now(timezone.utc) + _IST_OFFSET
    ist_midnight_today = now_ist.replace(hour=0, minute=0, second=0, microsecond=0)
    cutoff = ist_midnight_today - _IST_OFFSET  # back to UTC, for comparison against closeTime (UTC)

    closed_total = 0.0
    for t in trades:
        raw_close = t.get("closeTime")
        if not raw_close:
            continue
        try:
            close_t = datetime.fromisoformat(str(raw_close).replace("Z", "+00:00"))
        except Exception:
            continue
        if close_t < cutoff:
            continue
        pnl = t.get("pnl")
        if pnl is None:
            continue
        closed_total += float(pnl) + float(t.get("swap") or 0) + float(t.get("commission") or 0)

    open_total = 0.0
    for p in positions:
        profit = p.get("profit")
        if profit is not None:
            open_total += float(profit)

    return {"delta": closed_total + open_total, "available": True}


def _positions():
    return _read_json(DATA_DIR / "positions.json", DEMO_POSITIONS)


def _logs(limit: int = 100):
    return _read_jsonl(DATA_DIR / "logs.jsonl", limit, DEMO_LOGS)


# 2026-08-31, explicit operator request (Trade History "Original vs Retry" column, later extended
# 2026-09-02 for "Entry Volume DNA"): the EA's own entry_dna.jsonl records, per executed order, an
# "entrySource" field ("ORIGINAL"/"EARLY_REENTRY"/"C2_REFIRE") - written the instant SendMarketOrder()
# succeeds (RecordEntryDna() in KMIE_MarketDNA_Lite.mq5). Keyed by "ticket" there, which is the order
# ticket - on this hedging-mode account each order becomes its own position, so it matches
# trades.jsonl's own "position" field directly (verified: every ticket checked resolves 1:1, no
# ambiguity). entry_dna.jsonl only started being written partway through this EA's history, so most
# OLDER trades genuinely have no matching record - "Unknown"/None is reported for those rather than
# guessed. 2026-09-02: the upgraded EA additionally writes a "volumeDNA" object on newer records -
# {M1,M5,M15,H1}, each {valid,barTime,tickVolume,averageVolume,relativeVolume,volumeClass,...} - a
# genuine per-timeframe volume classification (LOW/VERY_LOW/ELEVATED/VERY_HIGH etc.), computed by the
# EA itself at entry time, not derived here. Reads the WHOLE record now (not just entrySource) so
# both features share one file read instead of two.
def _entry_dna_by_ticket() -> dict[str, dict]:
    lines = _read_jsonl(DATA_DIR / "entry_dna.jsonl", 20000, [])
    out: dict[str, dict] = {}
    for rec in lines:
        if not isinstance(rec, dict):
            continue
        ticket = rec.get("ticket")
        if ticket is None:
            continue
        out[str(ticket)] = rec
    return out


def _trade_type_label(entry_source: Optional[str], is_untraced: bool = False,
                       inferred_untracked_label: Optional[str] = None) -> str:
    if entry_source == "ORIGINAL":
        return "Original"
    if entry_source in ("EARLY_REENTRY", "C2_REFIRE"):
        return "Retry"
    # 2026-09-02, explicit operator request ("does also updating the same in trade history"): the
    # Reverse Fire trade the EA opens the instant the Early SL Watcher cuts a losing position (see
    # g_reverseFireInProgress in the .mq5) now writes entrySource="REVERSE_FIRE" to entry_dna.jsonl -
    # distinct from "Original"/"Retry" so it's identifiable in Trade History, not lumped in as a
    # normal Market-DNA/Minds-vote-driven entry.
    if entry_source == "REVERSE_FIRE":
        return "Reverse Fire"
    # 2026-09-22, explicit operator request ("can add M5 Swing break a reverse trade if ther is
    # pullback"): the NEW, separate reverse-trade mechanism (g_m5SwingReverseInProgress in the .mq5,
    # gated by the SAME M1 DNA regime-allow-list + 8-vote threshold every normal entry uses, unlike the
    # unconditional Reverse Fire above) writes entrySource="M5_SWING_REVERSE" - own distinct label so
    # it's never confused with Reverse Fire's different (unconditional) trigger in Trade History.
    if entry_source == "M5_SWING_REVERSE":
        return "M5 Swing Reverse"
    # 2026-09-03, explicit operator request ("make it permanent fix so in future there would no
    # Unknown or untracked 2nd show"): every trade without a real entrySource now gets a SPECIFIC
    # label - never the bare generic "Unknown"/"Untracked" bucket. inferred_untracked_label (see
    # _infer_untracked_label()'s own header) is a pattern-based best guess (timing/direction against
    # the preceding close) regardless of is_untraced. When no Retry/Reverse-Fire timing pattern
    # matches, the residual default is "Original" - mirroring how the AUTHORITATIVE side already
    # treats "no retry flag set" as ORIGINAL by default, never a genuinely unlabeled bucket.
    # 2026-09-03, explicit operator request ("make it correct as Retry only - there is no second EA"):
    # the "(2nd EA?)" suffix previously appended here for confirmed-untraced trades (is_untraced=True)
    # is REMOVED - operator has confirmed there is no second EA instance, so every trade on this
    # account's magic number/comment is this EA's own, regardless of whether this specific run
    # happened to have an entry_dna.jsonl record for it (a missing record reflects a logging/restart
    # gap on THIS instance, not a foreign order). is_untraced is kept as an internal signal (still read
    # by _untraced_positions_by_ticket() for other diagnostics) but no longer changes the displayed
    # label at all.
    return inferred_untracked_label or "Original"


# 2026-09-02, explicit operator request ("my trade type still showing as unknown... check deeply"):
# investigation traced most current "Unknown" trades to a REAL phenomenon the EA already has its own
# forensic log for - untraced_position_forensic.jsonl. This file is written whenever the EA's own
# CleanupTrailingSlots()/reconciliation code finds a real open/closed position on the account carrying
# THIS EA's own magic number and exact order comment ("KMIE_Lite_DNA_Minds"), that it never itself
# called OrderSend() for. Confirmed via direct log cross-reference (2026-09-02 05:35:25 batch: only 2
# ORDER_SEND lines in THIS instance's own logs.jsonl, yet 6 real matching-magic/comment positions
# exist - the other 4 are recorded here).
# 2026-09-03, explicit operator request ("there is no second EA"): this was originally documented as
# evidence of a second running instance; operator has confirmed that is not the case. The file/function
# are kept as-is (still a genuine record of positions this instance's own OrderSend() calls don't
# account for, most likely a logging/restart gap on this same instance) but no longer labeled or
# treated as proof of a second instance anywhere in this file. Keyed by position ticket, same
# convention as _entry_dna_by_ticket().
def _untraced_positions_by_ticket() -> dict[str, dict]:
    lines = _read_jsonl(DATA_DIR / "untraced_position_forensic.jsonl", 20000, [])
    out: dict[str, dict] = {}
    for rec in lines:
        if not isinstance(rec, dict):
            continue
        ticket = rec.get("position")
        if ticket is None:
            continue
        out[str(ticket)] = rec
    return out


def _parse_iso(iso_str: Optional[str]) -> Optional[datetime]:
    if not iso_str:
        return None
    try:
        return datetime.fromisoformat(str(iso_str).replace("Z", "+00:00"))
    except Exception:
        return None


# 2026-09-03, explicit operator request ("make according to Retry or Reverse Fire" - reclassify
# trades lacking a real entrySource using their timing/direction relationship to the trade that closed
# immediately before them, since a missing entry_dna.jsonl record means there is no authoritative
# entrySource to read for these, full stop. This is a BEST-EFFORT INFERENCE from data this instance
# genuinely does observe (trades.jsonl's own open/close/direction/reason/pnl fields - this instance's
# own position-sync loop sees every trade on the account, so the underlying facts are real; only the
# ATTRIBUTION - "this looks like a Retry" / "this looks like a Reverse Fire" - is inferred, never
# certain). Two patterns, checked against the CLOSEST preceding close (tracked or untracked, whichever
# genuinely closed most recently before this trade opened):
#   REVERSE_FIRE-like: that close was "Manual" (the exact close-reason signature CloseEarlyExitPosition()
#     produces) AND this trade opened in the OPPOSITE direction, within 5 seconds - mirrors this EA's
#     own VERIFIED Reverse Fire timing exactly (same-second, opposite direction, immediately after a
#     Manual close - see EvaluateEarlySlWatcher() in the .mq5).
#   RETRY-like: that close was in the SAME direction, non-negative P/L (a profit/breakeven exit -
#     Early Re-Entry/C2 Refire's own precondition of following a completed, non-losing structural move),
#     within 10 minutes.
# Anything matching neither pattern falls through to _trade_type_label()'s own "Original" default -
# never force-labeled into one bucket just to fill it.
# 2026-09-03, explicit operator request ("make it correct as Retry only - there is no second EA"): the
# "(2nd EA?)" suffix this function used to append is REMOVED (the suffix parameter itself is gone) -
# operator has confirmed there is no second EA instance, so a missing entry_dna.jsonl record reflects
# a logging/restart gap on THIS instance, never a foreign order.
def _sorted_close_events(rows: list[dict]) -> list[tuple[datetime, str, Optional[str], Optional[float]]]:
    events = []
    for r in rows:
        close_dt = _parse_iso(r.get("closeTime"))
        if close_dt is None:
            continue
        events.append((close_dt, r.get("type"), r.get("reason"), r.get("pnl")))
    events.sort(key=lambda e: e[0])
    return events


def _infer_untracked_label(open_time_str: Optional[str], direction: Optional[str],
                            sorted_closes: list[tuple[datetime, str, Optional[str], Optional[float]]]
                            ) -> Optional[str]:
    open_dt = _parse_iso(open_time_str)
    if open_dt is None or not direction or not sorted_closes:
        return None
    close_times = [c[0] for c in sorted_closes]
    idx = bisect.bisect_right(close_times, open_dt) - 1
    if idx < 0:
        return None
    close_dt, close_dir, close_reason, close_pnl = sorted_closes[idx]
    gap_seconds = (open_dt - close_dt).total_seconds()
    if gap_seconds < 0:
        return None  # this "close" is actually after our open - not a valid preceding event

    same_dir = (close_dir == direction)

    if close_reason == "Manual" and not same_dir and gap_seconds <= 5:
        return "Reverse Fire"
    if same_dir and close_pnl is not None and close_pnl >= 0 and gap_seconds <= 600:
        return "Retry"
    return None


# 2026-09-02, explicit operator request ("Early SL Watcher... if SL Watcher Don't cut the early than
# it should hit SL or Not... Mention in Trade History as Good Signal / Bad Signal"): reads
# sl_watcher.jsonl (written by the EA's SlWatcherSignalTrack pool - see its own header in the .mq5 for
# the full design), keyed by ticket. Each ticket gets exactly one line, written once by the EA
# (one-shot, per its own design) - last-wins on the rare chance of a duplicate, same convention as
# _entry_dna_by_ticket() above.
def _sl_watcher_by_ticket() -> dict[str, dict]:
    lines = _read_jsonl(DATA_DIR / "sl_watcher.jsonl", 20000, [])
    out: dict[str, dict] = {}
    for rec in lines:
        if not isinstance(rec, dict):
            continue
        ticket = rec.get("ticket")
        if ticket is None:
            continue
        out[str(ticket)] = rec
    return out


# 2026-09-02, explicit operator request: display label for the Early SL Watcher's signal-quality
# classification. "Good Signal" = the 3rd closed candle after entry moved toward the trade's own
# direction (toward profit); "Bad Signal" = it moved toward where the SL sits; "Watcher Cut" = the
# Early SL Watcher itself closed the trade before this classification could run (explicit operator
# scope - this classifier only ever runs on trades the Watcher did NOT intervene on); "—" = no record
# yet (trade too recent - fewer than 3 closed candles have elapsed since entry - or predates this
# feature entirely). Never guessed for a missing record.
def _early_sl_signal_label(sl_watcher_rec: Optional[dict]) -> str:
    if not sl_watcher_rec:
        return "—"
    if sl_watcher_rec.get("watcherCutEarly"):
        return "Watcher Cut"
    quality = sl_watcher_rec.get("signalQuality")
    if quality == "GOOD_SIGNAL":
        return "Good Signal"
    if quality == "BAD_SIGNAL":
        return "Bad Signal"
    if quality == "NEUTRAL":
        return "Neutral"
    return "—"


# 2026-09-02, explicit operator request ("Volume Average", "Entry Volume DNA {M1 tickVolume}",
# "Entry Volume DNA (relative)", "Entry Volume DNA (class)"): pulls the M1 slice of entry_dna.jsonl's
# own volumeDNA object (see _entry_dna_by_ticket()'s header above) - the EA's own authoritative
# volume classification at the moment of entry, not a client-side approximation. Returns a dict with
# all four fields None when the record (or its M1 sub-object, or "valid") is missing/false - never
# fabricated for older trades that predate this field.
def _entry_volume_dna_m1(entry_rec: Optional[dict]) -> dict:
    empty = {"tickVolume": None, "averageVolume": None, "relativeVolume": None, "volumeClass": None}
    if not entry_rec:
        return empty
    vdna = entry_rec.get("volumeDNA")
    if not isinstance(vdna, dict):
        return empty
    m1 = vdna.get("M1")
    if not isinstance(m1, dict) or not m1.get("valid"):
        return empty
    return {
        "tickVolume": m1.get("tickVolume"),
        "averageVolume": m1.get("averageVolume"),
        "relativeVolume": m1.get("relativeVolume"),
        "volumeClass": m1.get("volumeClass"),
    }


# 2026-09-03, explicit operator request ("add New Column like Vol Avg and Vol Class for Pip/Price Avg
# and Vol Pip/Price all trade history"): pulls entry_dna.jsonl's own "priceRangeDNA" object (see
# RecordEntryDna() in the .mq5 - the Price/Range DNA counterpart to volumeDNA above, added the same
# additive way). Unlike volumeDNA this is a single flat object (one M1 reading via
# ComputePriceRangeDnaLive()), not per-timeframe, so there's no "M1" sub-key to descend into. Returns
# both fields None when the record (or "valid") is missing/false - never fabricated for trades that
# predate this field.
def _entry_price_range_dna(entry_rec: Optional[dict]) -> dict:
    empty = {"avgRangePips20": None, "rangeClass": None}
    if not entry_rec:
        return empty
    prdna = entry_rec.get("priceRangeDNA")
    if not isinstance(prdna, dict) or not prdna.get("valid"):
        return empty
    return {
        "avgRangePips20": prdna.get("avgRangePips20"),
        "rangeClass": prdna.get("rangeClass"),
    }


# 2026-09-15, explicit operator request ("Add confirmation under Which Market Session, Volume Price,
# Pips & Price bot is taking the Profit and under which bot not taking the loss - add the Confirmation
# in trade history on dashboard"): pulls entry_dna.jsonl's own "entrySession" field (see RecordEntryDna()
# in the .mq5 - reuses the EA's own existing ResolveCurrentSessionLabel(), never a second/independent
# session-detection formula computed here). Returns None when the record or field is missing - never
# fabricated for trades that predate this field (same "no fallback approximation" convention as
# _entry_price_range_dna(), since unlike volume there's no bars.jsonl-derived approximation for session).
def _entry_session(entry_rec: Optional[dict]) -> Optional[str]:
    if not entry_rec:
        return None
    session = entry_rec.get("entrySession")
    return session if isinstance(session, str) and session else None


def _truncate_to_minute_iso(iso_str: Optional[str]) -> Optional[str]:
    if not iso_str:
        return None
    try:
        dt = datetime.fromisoformat(str(iso_str).replace("Z", "+00:00"))
    except Exception:
        return None
    dt = dt.replace(second=0, microsecond=0)
    return dt.isoformat().replace("+00:00", "Z")


# 2026-09-02, explicit operator request ("trade history volume"): market tick volume at the moment
# each trade OPENED - not the trade's own lot size (already shown, unrelated field), the underlying
# CANDLE's activity level. Same "captured at entry, never recomputed at close" convention already
# used for dnaState - bars.jsonl's own per-bar tickVolume is looked up by truncating the trade's
# openTime down to its containing M1 bar (bars.jsonl times are already minute-aligned). Read at a
# higher limit (20000, matching _entry_source_by_ticket()'s own raised limit) than the 500-bar chart
# window, so this join can reach back across this file's full trade history, not just recent bars.
def _bars_by_minute() -> dict[str, dict]:
    bars = _read_jsonl(DATA_DIR / "bars.jsonl", 20000, [])
    out: dict[str, dict] = {}
    for b in bars:
        if isinstance(b, dict) and b.get("time"):
            out[b["time"]] = b
    return out


def _volume_class_from_relative(relative: float) -> str:
    # Mirrors ClassifyVolumeDna()'s own fixed bins in KMIE_MarketDNA_Lite.mq5 exactly (Section 7) -
    # never a second, independently-chosen set of thresholds.
    if relative < 0.70:
        return "VERY_LOW"
    if relative < 1.00:
        return "LOW"
    if relative < 1.30:
        return "NORMAL"
    if relative < 1.60:
        return "ELEVATED"
    if relative < 2.00:
        return "HIGH"
    if relative < 3.00:
        return "VERY_HIGH"
    return "EXTREME"


# 2026-09-02, explicit operator request ("Why trade history not capturing everything" - Volume
# Average/(relative)/(class) were showing "—" for every trade with no entry_dna.jsonl record, e.g. the
# untracked trades, since _entry_volume_dna_m1() has no fallback of its own, unlike
# tickVolumeAtOpen just above it which already falls back to bars.jsonl). This is a SERVER-SIDE
# approximation of the EA's own ComputeVolumeDna() (KMIE_MarketDNA_Lite.mq5, Section 5/6/7): average of
# the 20 M1 bars immediately preceding the reference minute (EXCLUDING the reference bar itself, same
# exclusion rule the EA uses), then relative = referenceTickVolume / that average, classified through
# the identical bins above. Returns (None, None, None) - never a fabricated 0/UNKNOWN - when fewer than
# 1 baseline bar exists (e.g. right at the start of this file's own bars.jsonl history) or the
# reference tick volume itself is unavailable. This is a DASHBOARD-COMPUTED approximation, not the EA's
# own authoritative reading - only ever used when that authoritative value is missing.
def _volume_dna_fallback(sorted_times: list[str], time_index: dict[str, int], bars_by_minute: dict[str, dict],
                          minute_key: Optional[str], tick_volume: Optional[int], baseline_bars: int = 20):
    if minute_key is None or tick_volume is None:
        return None, None, None
    idx = time_index.get(minute_key)
    if idx is None:
        return None, None, None
    start = max(0, idx - baseline_bars)
    baseline_times = sorted_times[start:idx]  # strictly BEFORE the reference minute - excludes it
    if not baseline_times:
        return None, None, None
    vols = []
    for t in baseline_times:
        v = bars_by_minute.get(t, {}).get("tickVolume")
        if v is not None:
            vols.append(v)
    if not vols:
        return None, None, None
    average = sum(vols) / len(vols)
    if average <= 0:
        return None, None, None
    relative = tick_volume / average
    return average, relative, _volume_class_from_relative(relative)


def _trades():
    rows = _read_jsonl(DATA_DIR / "trades.jsonl", 5000, DEMO_TRADES)
    if rows is DEMO_TRADES:
        # Demo data has no real position tickets to join against - label everything Unknown/None
        # rather than fabricate a plausible-looking split for fake trades.
        return [dict(r, tradeType="Unknown", tickVolumeAtOpen=None,
                      volumeAverage=None, volumeRelative=None, volumeClass=None,
                      earlySlSignal="—") for r in rows]
    entry_by_ticket = _entry_dna_by_ticket()
    bars_by_minute = _bars_by_minute()
    # 2026-09-02, explicit operator request ("Why trade history not capturing everything"): built ONCE
    # per _trades() call (not per-trade) for _volume_dna_fallback()'s lookback - see its own header.
    sorted_times = sorted(bars_by_minute.keys())
    time_index = {t: i for i, t in enumerate(sorted_times)}
    sl_watcher_by_ticket = _sl_watcher_by_ticket()
    untraced_by_ticket = _untraced_positions_by_ticket()
    # 2026-09-03, explicit operator request ("make according to Retry or Reverse Fire"): built ONCE
    # per _trades() call (not per-trade) for _infer_untracked_label()'s preceding-close lookup - see
    # its own header.
    sorted_closes = _sorted_close_events(rows)
    out = []
    for r in rows:
        ticket = r.get("position")
        entry_rec = entry_by_ticket.get(str(ticket)) if ticket is not None else None
        entry_source = entry_rec.get("entrySource") if entry_rec else None
        sl_watcher_rec = sl_watcher_by_ticket.get(str(ticket)) if ticket is not None else None
        is_untraced = (str(ticket) in untraced_by_ticket) if ticket is not None else False
        # 2026-09-03, explicit operator request ("make it permanent fix so in future there would no
        # Unknown or untracked 2nd show"): inference now runs for EVERY trade lacking a real
        # entrySource, not just confirmed-untraced ones.
        # 2026-09-03, explicit operator request ("make it correct as Retry only - there is no second
        # EA"): no longer passes a "(2nd EA?)" suffix for confirmed-untraced trades - see
        # _trade_type_label()'s own header for why.
        inferred_untracked_label = (
            _infer_untracked_label(r.get("openTime"), r.get("type"), sorted_closes)
            if entry_source is None else None
        )

        # 2026-09-02: prefer the EA's own authoritative M1 volumeDNA.tickVolume (computed at the
        # exact entry tick) when available; fall back to the bars.jsonl minute-join below only for
        # older trades that predate the volumeDNA field entirely - never overwritten once present.
        vol_m1 = _entry_volume_dna_m1(entry_rec)
        minute_key = _truncate_to_minute_iso(r.get("openTime"))
        tick_volume_at_open = vol_m1["tickVolume"]
        if tick_volume_at_open is None:
            bar = bars_by_minute.get(minute_key) if minute_key else None
            tick_volume_at_open = bar.get("tickVolume") if bar else None

        # 2026-09-02, explicit operator request ("Why trade history not capturing everything"):
        # Volume Average/(relative)/(class) previously had NO fallback at all - every trade missing an
        # entry_dna.jsonl record (older trades, and other untracked trades) showed "—" for all three,
        # even though bars.jsonl has enough real data to compute a genuine approximation. Same "prefer
        # EA's own authoritative value, fall back only when
        # missing" pattern as tickVolumeAtOpen above.
        volume_average, volume_relative, volume_class = vol_m1["averageVolume"], vol_m1["relativeVolume"], vol_m1["volumeClass"]
        if volume_average is None:
            volume_average, volume_relative, volume_class = _volume_dna_fallback(
                sorted_times, time_index, bars_by_minute, minute_key, tick_volume_at_open)

        # 2026-09-03, explicit operator request ("add New Column like Vol Avg and Vol Class for
        # Pip/Price Avg and Vol Pip/Price all trade history"): the EA's own authoritative Price/Range
        # DNA reading at entry (avgRangePips20/rangeClass) - see _entry_price_range_dna()'s own header.
        # No fallback approximation exists for this (unlike volume, which bars.jsonl can approximate) -
        # trades that predate this field show "—" client-side, never fabricated.
        price_range = _entry_price_range_dna(entry_rec)

        # 2026-09-15, explicit operator request ("Add confirmation under Which Market Session, Volume
        # Price, Pips & Price bot is taking the Profit and under which bot not taking the loss"): prefer
        # the EA's own authoritative session label at entry (see _entry_session()'s own header). 2026-09-16
        # fix ("We do have Session block in history trade you take from there" - the operator pointed out
        # the main Trade History table's own Session column already shows a value for every trade, via
        # the client-side getActiveMarketSessions()/openTime fallback in index.html - but the NEW
        # Performance Breakdown panel is computed entirely server-side and never ran that same fallback,
        # so every group showed "—" for Session even though the table right next to it wasn't blank).
        # Falls back to the SAME server-side derivation the Excel export already uses
        # (_active_sessions_for(), same UTC-hour windows as the frontend's own getActiveMarketSessions())
        # for any trade lacking the EA's own field - mirrors the frontend's own
        # "t.entrySession || getActiveMarketSessions(...)" precedence exactly, just computed here too so
        # server-side aggregation (the breakdown endpoint) sees the same value the table displays.
        entry_session = _entry_session(entry_rec) or _active_sessions_for(r.get("openTime")) or None

        # 2026-09-16, explicit operator request (PERFORMANCE BREAKDOWN - "tell us about the market DNA
        # M1 and M5 when Trade execute"): the EA's own entry-time DNA regime for both timeframes, read
        # straight from entry_dna.jsonl (never trade-close-time dnaState, which is a DIFFERENT reading
        # taken when the position closed, not when it was opened - see entry_dna.jsonl's own "dnaState"
        # field vs trades.jsonl's own "dnaState" field, two genuinely different snapshots). dnaStateM5
        # only exists on entry_dna.jsonl records written since the M5 parallel pipeline shipped
        # (2026-09-16) - older trades simply have no M5 reading, never fabricated, shown as None/"—".
        entry_dna_state_m1 = entry_rec.get("dnaState") if entry_rec else None
        entry_dna_state_m5 = entry_rec.get("dnaStateM5") if entry_rec else None

        out.append(dict(
            r,
            tradeType=_trade_type_label(entry_source, is_untraced, inferred_untracked_label),
            tickVolumeAtOpen=tick_volume_at_open,
            volumeAverage=volume_average,
            volumeRelative=volume_relative,
            volumeClass=volume_class,
            pipPriceAvg=price_range["avgRangePips20"],
            pipPriceClass=price_range["rangeClass"],
            earlySlSignal=_early_sl_signal_label(sl_watcher_rec),
            entrySession=entry_session,
            entryDnaStateM1=entry_dna_state_m1,
            entryDnaStateM5=entry_dna_state_m5,
        ))
    return out


def _bars_file(limit: int = 500):
    return _read_jsonl(DATA_DIR / "bars.jsonl", limit, DEMO_BARS)


# 2026-09-11, explicit operator request (ACTIVE_PING chart highlight): active_ping.jsonl is EA-written,
# once per new CLOSED M1 bar (see the EA's own EvaluateActivePing() cadence), and grows unbounded for the
# life of the EA session - same unbounded-growth shape as dna_raw_scores.jsonl, so this uses _tail_jsonl()
# (bounded-IO tail read) rather than _read_jsonl() (which would load the entire file). Keyed by the row's
# own "barTime" field, which is already minute-aligned and uses the EXACT SAME ISO format as bars.jsonl's
# "time" field (both come from the same EA/MqlRates.time source) - a direct string-equality join, no
# parsing/truncation needed (unlike _bars_by_minute() above, which truncates a trade's own openTime down
# to its containing bar - active_ping.jsonl rows are already bar-aligned at the source). Read at a
# generous limit so the join can reach back across the live chart's default window; if a bar has no
# corresponding active_ping.jsonl row (e.g. EA restart gap, or a row written before this feature existed),
# the join below simply omits activePingActive for that bar - never a fabricated true/false.
# 2026-09-18, explicit operator request (ACTIVE_PING CHART OVERLAY - purple/light-yellow zones): ALSO
# carries corridorActive now (not just the final active bool) - the chart needs to distinguish "inside the
# EMA20/50 corridor" (light yellow) from "outside it but still active via trendingSideActive/crossing"
# (purple), which the single active bool alone cannot express. corridorActive is read straight from the
# EA's own active_ping.jsonl field (EvaluateActivePing()'s own r.corridorActive) - never recomputed here.
def _active_ping_by_bartime(limit: int = 20000) -> dict[str, dict]:
    rows = _tail_jsonl(DATA_DIR / "active_ping.jsonl", limit, [])
    out: dict[str, dict] = {}
    for r in rows:
        bar_time = r.get("barTime")
        active = r.get("active")
        if bar_time is None or active is None:
            continue
        out[bar_time] = {"active": bool(active), "corridorActive": bool(r.get("corridorActive", False))}
    return out


# 2026-08-30, explicit operator request (LIVE data source must remain the
# EA log, never PostgreSQL): _bars() is the live tail's ONLY data source
# (via /api/price/history below) - it now reads bars.jsonl directly and
# NEVER consults Postgres. Previously this tried db.fetch_bars() (Postgres)
# first, falling back to the file only when Postgres returned zero rows -
# since Postgres is normally fully synced, that meant the live chart was
# actually reading Postgres almost all the time, which fails the required
# "EA log = live, Postgres = historical" architecture (a live candle must
# show up the instant the EA writes it, never waiting on the 5-second
# sync_all() cadence). Historical (older-than-the-live-buffer) data is
# served exclusively by the separate /api/price/history/before endpoint,
# which DOES use Postgres - see api_price_history_before() below.
async def _bars(symbol: str = "XAUUSDm", timeframe: str = "M1", limit: int = 500):
    return _bars_file(limit)


# The EA only ever logs M1 candles (bars.jsonl / the "bars" Postgres table
# are always timeframe="M1"). M5/M15 aren't a second data stream from the
# EA - they're built here by grouping consecutive M1 bars into 5- or
# 15-minute buckets, same as any charting platform derives higher
# timeframes from the base resolution it actually has.
TIMEFRAME_MINUTES = {"M1": 1, "M5": 5, "M15": 15}


def _parse_bar_time(t) -> Optional[datetime]:
    try:
        return datetime.fromisoformat(str(t).replace("Z", "+00:00"))
    except Exception:
        return None


def _aggregate_bars(m1_bars: list, minutes: int) -> list:
    if minutes <= 1:
        return m1_bars
    buckets: dict = {}
    order: list = []
    for b in m1_bars:
        t = _parse_bar_time(b.get("time"))
        if t is None:
            continue
        floored_minute = (t.minute // minutes) * minutes
        bucket_start = t.replace(minute=floored_minute, second=0, microsecond=0)
        key = bucket_start.isoformat()
        agg = buckets.get(key)
        if agg is None:
            agg = {
                "time": key.replace("+00:00", "Z"),
                "open": b.get("open"), "high": b.get("high"),
                "low": b.get("low"), "close": b.get("close"),
                # Real MT5 tick volume (rates[].tick_volume via the EA),
                # never a fabricated number. Missing on older bars.jsonl
                # rows written before this field existed - None there,
                # NOT 0, since "unavailable" and "zero ticks" are
                # different facts.
                "tickVolume": b.get("tickVolume"),
                "dnaState": b.get("dnaState"), "dnaScore": b.get("dnaScore"),
                "event": b.get("event"), "ticket": b.get("ticket"), "marketDna": b.get("marketDna"),
                # 2026-09-11, explicit operator request (ACTIVE_PING chart highlight): same "close"
                # semantics as dnaState just above - the M5/M15 candle's own ACTIVE_PING reading is
                # whichever constituent M1 bar's reading was current as of THIS bucket's own close.
                "activePingActive": b.get("activePingActive"),
                # 2026-09-18, explicit operator request (ACTIVE_PING CHART OVERLAY): corridorActive carried
                # forward with the SAME close semantics as activePingActive just above.
                "activePingCorridorActive": b.get("activePingCorridorActive"),
            }
            buckets[key] = agg
            order.append(key)
        else:
            agg["high"] = max(agg["high"], b.get("high", agg["high"]))
            agg["low"] = min(agg["low"], b.get("low", agg["low"]))
            agg["close"] = b.get("close", agg["close"])
            if b.get("activePingActive") is not None:
                agg["activePingActive"] = b.get("activePingActive")
            if b.get("activePingCorridorActive") is not None:
                agg["activePingCorridorActive"] = b.get("activePingCorridorActive")
            # Aggregated tick volume = sum of constituent M1 bars' real
            # tick volume - but ONLY when every constituent bar actually
            # has one. If any source bar in this bucket is missing
            # tickVolume (old pre-field data, or the still-forming
            # candle), the bucket's own tickVolume becomes unavailable
            # (None) rather than a dishonest partial sum.
            bar_tv = b.get("tickVolume")
            if agg["tickVolume"] is None or bar_tv is None:
                agg["tickVolume"] = None
            else:
                agg["tickVolume"] = agg["tickVolume"] + bar_tv
            # dnaState/dnaScore follow "close" semantics (always the
            # newest M1 bar in the bucket) - the M5/M15 candle's DNA is
            # its state as of its own close, same as its close price.
            if b.get("dnaState") is not None:
                agg["dnaState"] = b.get("dnaState")
                agg["dnaScore"] = b.get("dnaScore")
            # Carry the TP/SL event forward onto the candle it actually
            # fell inside, whichever M1 bar within the bucket carried it.
            if b.get("event"):
                agg["event"] = b["event"]
                agg["ticket"] = b.get("ticket")
                agg["marketDna"] = b.get("marketDna")
    return [buckets[k] for k in order]


_sync_task: Optional[asyncio.Task] = None
_SYNC_INTERVAL_SECONDS = 5


async def _sync_loop() -> None:
    """Background loop: mirrors every EA-written JSON file under DATA_DIR
    into Postgres every few seconds, for as long as this process runs.
    Every write is an idempotent upsert, so a missed tick or a duplicate
    read is harmless. Silently no-ops (via db.sync_all's own pool==None
    check) when DATABASE_URL isn't set - the dashboard keeps working
    straight off the JSON files either way."""
    while True:
        try:
            await db.sync_all(DATA_DIR)
        except Exception:
            pass
        await asyncio.sleep(_SYNC_INTERVAL_SECONDS)


@app.on_event("startup")
async def _on_startup() -> None:
    global _sync_task
    pool = await db.get_pool()
    if pool is not None:
        await db.sync_jsonl_file(DATA_DIR / "bars.jsonl", "XAUUSDm", "M1")
        _sync_task = asyncio.create_task(_sync_loop())


@app.on_event("shutdown")
async def _on_shutdown() -> None:
    global _sync_task
    if _sync_task is not None:
        _sync_task.cancel()
        _sync_task = None
    await db.close_pool()


# ---------------------------------------------------------------------------
# JSON API - mirrors monitoring/dashboard/server.py's contract exactly
# ---------------------------------------------------------------------------

@app.get("/api/status")
async def api_status() -> JSONResponse:
    positions = _positions()
    equity = _equity_series()
    last_equity = equity[-1]["equity_usd"] if equity else None
    first_equity = equity[0]["equity_usd"] if equity else None

    # Real account balance/equity: the EA writes AccountInfoDouble(ACCOUNT_
    # BALANCE/ACCOUNT_EQUITY) into live_signal.json every tick. Prefer that
    # over the old equity.jsonl-first-entry approximation, which wasn't the
    # actual broker balance - just whatever equity happened to be logged
    # when the EA (or this dashboard) first started.
    live = _read_json(DATA_DIR / "live_signal.json", None)
    real_balance = live.get("balanceUsd") if live else None
    real_equity = live.get("equityUsd") if live else None
    balance_usd = real_balance if real_balance is not None else first_equity
    equity_usd = real_equity if real_equity is not None else last_equity

    # 2026-08-29, explicit operator request: Today P&L is now a genuine
    # window, not last_equity-first_equity over the ENTIRE unbounded
    # equity.jsonl history (that bug silently accumulated every prior day's
    # P&L forever into "Today").
    # 2026-08-31, explicit operator request: switched from a rolling
    # trailing-24h window to a genuine CALENDAR-DAY reset at IST midnight.
    # 2026-08-31, further operator request: switched from an equity-snapshot
    # ESTIMATE to an EXACT sum of real per-trade pnl+swap+commission (closed
    # since IST midnight) plus live open-position profit (_pnl_exact_since_day_start).
    # equity-based daily_pnl_pct is still derived from the exact delta against
    # first_equity below (no equity-based estimate feeds the dollar figure anymore).
    daily_window = _pnl_exact_since_day_start(_trades(), positions)
    daily_pnl = daily_window["delta"]
    daily_pnl_pct = (daily_pnl / first_equity) if (first_equity and daily_pnl is not None) else None
    live_trading = (DATA_DIR / "positions.json").exists()

    # 2026-09-02, explicit operator request ("Volume running"): the STILL-FORMING candle's own live
    # tick volume, from current_bar.json (written every tick, independent of bars.jsonl which only
    # gets a new line once a bar actually closes) - genuinely live, updates every poll, not a
    # once-per-minute snapshot.
    current_bar = _read_json(DATA_DIR / "current_bar.json", None)
    live_volume = current_bar.get("tickVolume") if current_bar else None

    return JSONResponse({
        "ok": True,
        "is_halted": _halted["value"],
        "is_live_trading": live_trading,
        "equity_usd": equity_usd,
        "balance_usd": balance_usd,
        "daily_pnl_usd": daily_pnl,
        "daily_pnl_pct": daily_pnl_pct,
        "live_volume": live_volume,
        "drawdown_pct": 0.0,
        "active_symbols": ["XAUUSD"],
        "open_positions": positions,
        "current_margin_tier": "OK",
        "current_drawdown_tier": "OK",
        "server_time_iso": datetime.now(timezone.utc).isoformat(),
    })


@app.get("/api/positions")
async def api_positions() -> JSONResponse:
    return JSONResponse(_positions())


@app.get("/api/alerts")
async def api_alerts() -> JSONResponse:
    return JSONResponse([])


def _parse_range_bound(v: Optional[str]) -> Optional[datetime]:
    if not v:
        return None
    try:
        dt = datetime.fromisoformat(v.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt
    except Exception:
        return None


def _filter_trades(trades: list, date_from: Optional[str], date_to: Optional[str]) -> list:
    lo = _parse_range_bound(date_from)
    hi = _parse_range_bound(date_to)
    if lo is None and hi is None:
        return trades
    out = []
    for t in trades:
        ct = _parse_range_bound(t.get("closeTime"))
        if ct is None:
            continue
        if lo is not None and ct < lo:
            continue
        if hi is not None and ct > hi:
            continue
        out.append(t)
    return out


@app.get("/api/trades")
async def api_trades(date_from: Optional[str] = None, date_to: Optional[str] = None) -> JSONResponse:
    return JSONResponse(_filter_trades(_trades(), date_from, date_to))


def _active_sessions_for(iso_time: Optional[str]) -> str:
    # Mirrors the frontend's getActiveMarketSessions() exactly (same UTC
    # hour windows: Sydney 22-07, Tokyo 0-9, London 8-17, New York 13-22,
    # overlaps reported together) - kept in sync by hand since the export
    # is generated server-side (openpyxl) and can't share the JS function.
    if not iso_time:
        return ""
    try:
        dt = datetime.fromisoformat(str(iso_time).replace("Z", "+00:00"))
    except Exception:
        return ""
    h = dt.astimezone(timezone.utc).hour
    names = []
    if h >= 22 or h < 7:
        names.append("SYDNEY")
    if 0 <= h < 9:
        names.append("TOKYO")
    if 8 <= h < 17:
        names.append("LONDON")
    if 13 <= h < 22:
        names.append("NEW YORK")
    return " / ".join(names)


@app.get("/api/trades/export")
async def api_trades_export(date_from: Optional[str] = None, date_to: Optional[str] = None):
    from fastapi.responses import StreamingResponse
    import io
    from openpyxl import Workbook
    from openpyxl.styles import Font

    rows = _filter_trades(_trades(), date_from, date_to)

    wb = Workbook()
    ws = wb.active
    ws.title = "Trade History"
    headers = [
        "Symbol", "Type", "Trade Type", "Session", "Volume, lot", "Open price", "Close price", "T/P", "S/L",
        "Position", "Open time", "Close time", "Swap, USD", "Commission, USD",
        # 2026-09-18, explicit operator request ("also add the DNA M1 DNA M5 in dashboard under Trade
        # history"): split the single "Market DNA" export column into DNA M1/DNA M5, mirroring the
        # dashboard table's own DNA M1/DNA M5 columns - same t["entryDnaStateM1"]/t["entryDnaStateM5"]
        # fields _trades() already populates (see its own header, line ~946-954), no new computation.
        "DNA M1", "DNA M5", "16-Mind Votes (Buy/Sell/Wait)", "Reason", "P/L, USD",
        "Pullback Recovery, USD",
        "DNA Correction Note",
        "Entry Volume DNA {M1 tickVolume}",
        "Volume Average",
        "Entry Volume DNA (relative)",
        "Entry Volume DNA (class)",
        # 2026-09-03, explicit operator request ("when export the file from dashboard its don't have
        # new columns we have added"): Pip/Price Avg and Vol Pip/Price mirror the dashboard table's own
        # columns exactly - same t["pipPriceAvg"]/t["pipPriceClass"] fields _trades() already populates
        # via _entry_price_range_dna() (see its own header) - no new computation, just carried into the
        # export the same way Entry Volume DNA's fields already were.
        "Pip/Price Avg",
        "Vol Pip/Price",
        "Early SL Signal",
        # 2026-09-03, same request: Outcome mirrors the dashboard's own Profit/Loss/Breakeven
        # classification (index.html's Outcome column) - same 3-way sign check on the SAME t["pnl"]
        # value already exported as "P/L, USD" above, just also labeled here for readability.
        "Outcome",
    ]
    ws.append(headers)
    for cell in ws[1]:
        cell.font = Font(bold=True)
    for t in rows:
        mv = t.get("mindVotes") or {}
        # Pullback Recovery Difference - analytics-only field (see KMIE_MarketDNA_Lite.mq5's
        # ManageOpenPositions()); three distinct states kept distinct in the export same as the
        # dashboard UI - no pullback, pullback with no completed recovery, or a real USD value
        # (converted server-side by the EA, at the ticket's own lot size).
        if not t.get("pullback_detected"):
            pb_cell = "No pullback"
        elif t.get("pullback_recovery_difference_usd") is None:
            pb_cell = "Pullback (closed before recovery)"
        else:
            pb_cell = t.get("pullback_recovery_difference_usd")
        # 2026-08-28: 50 historical trades had their dnaState corrected against the Experts log
        # (restart-related capture gap, since fixed) - see dnaState_corrected/dnaState_original on
        # the underlying trade record. Disclosed here too so the export carries the same audit
        # trail as the dashboard UI, never silently.
        dna_note = ("was \"" + str(t.get("dnaState_original")) + "\" - corrected 2026-08-28"
                    if t.get("dnaState_corrected") else "")
        # 2026-09-03, explicit operator request: same 3-way sign check the dashboard's own Outcome
        # column uses (pnl > 0 -> Profit, pnl < 0 -> Loss, else Breakeven) - on the SAME pnl value
        # already exported as "P/L, USD" above, never a second/independent source.
        pnl_val = t.get("pnl")
        outcome = "Profit" if (pnl_val is not None and pnl_val > 0) else "Loss" if (pnl_val is not None and pnl_val < 0) else "Breakeven"
        # 2026-09-15, explicit operator request ("Add confirmation under Which Market Session...add the
        # Confirmation in trade history on dashboard"): prefer the EA's OWN authoritative entrySession
        # (t["entrySession"], populated by _trades() via _entry_session() - see its own header) over the
        # export's client-independent _active_sessions_for() re-derivation, which only ever assumes AUTO
        # session mode from openTime and cannot reflect an Inp_SessionMode=MANUAL override. Falls back to
        # the old derivation only for trades that predate this field - same pattern already used for
        # tradeType/volumeAverage/etc above.
        session_cell = t.get("entrySession") or _active_sessions_for(t.get("openTime"))
        ws.append([
            t.get("symbol"), t.get("type"), t.get("tradeType"), session_cell, t.get("volume"),
            t.get("openPrice"), t.get("closePrice"), t.get("tp"), t.get("sl"),
            t.get("position"), t.get("openTime"), t.get("closeTime"),
            t.get("swap"), t.get("commission"),
            t.get("entryDnaStateM1") or t.get("dnaState"),
            t.get("entryDnaStateM5"),
            str(mv.get("buy", 0)) + "/" + str(mv.get("sell", 0)) + "/" + str(mv.get("wait", 0)),
            t.get("reason"), t.get("pnl"),
            pb_cell,
            dna_note,
            t.get("tickVolumeAtOpen"),
            t.get("volumeAverage"),
            t.get("volumeRelative"),
            t.get("volumeClass"),
            t.get("pipPriceAvg"),
            t.get("pipPriceClass"),
            t.get("earlySlSignal"),
            outcome,
        ])
    for col in ws.columns:
        width = max((len(str(c.value)) if c.value is not None else 0) for c in col) + 2
        ws.column_dimensions[col[0].column_letter].width = min(width, 32)

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    filename = "trade_history_" + datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S") + ".xlsx"
    return StreamingResponse(
        buf,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": 'attachment; filename="' + filename + '"'},
    )


# 2026-09-16, explicit operator request ("under performance session i also need the selection like Date
# week month selection only for them performance should show"): translates a preset range keyword into
# the SAME date_from/date_to ISO bounds _filter_trades() already accepts (used by /api/trades and the
# XLSX export) - never a second/independent date-window implementation. "today"/"week"/"month" are all
# anchored to the CURRENT UTC moment (datetime.now(timezone.utc)), matching this file's own existing
# UTC convention (DashIsoTime()/_active_sessions_for() etc. all reason in UTC). "all" (or anything else
# unrecognized) returns (None, None) - _filter_trades()'s own documented behavior for both bounds None is
# "return trades unchanged", i.e. no filtering at all.
def _range_bounds_for_preset(range_preset: Optional[str]) -> tuple[Optional[str], Optional[str]]:
    now = datetime.now(timezone.utc)
    if range_preset == "today":
        start = now.replace(hour=0, minute=0, second=0, microsecond=0)
    elif range_preset == "week":
        start = (now - timedelta(days=now.weekday())).replace(hour=0, minute=0, second=0, microsecond=0)
    elif range_preset == "month":
        start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    else:
        return (None, None)
    return (start.isoformat().replace("+00:00", "Z"), now.isoformat().replace("+00:00", "Z"))


# 2026-09-16, explicit operator request ("now i need only for today should be have date selection
# selection where i multi date"): a SEPARATE filter from the Today/Week/Month/All-Time presets above
# (confirmed via AskUserQuestion - "Pick Dates" sits alongside those, not a replacement) - keeps
# individual calendar dates (each a "YYYY-MM-DD" string, UTC calendar day per this file's own existing
# UTC convention), and keeps a trade if its closeTime falls on ANY of them (a union, not an intersection -
# picking Sep 10 and Sep 12 shows trades from EITHER day combined, not only trades somehow on both).
def _filter_trades_by_dates(trades: list, dates: list[str]) -> list:
    if not dates:
        return trades
    wanted = set()
    for d in dates:
        try:
            wanted.add(datetime.strptime(d.strip(), "%Y-%m-%d").date())
        except Exception:
            continue  # malformed date string - silently ignored, never raises for the whole request
    if not wanted:
        return trades
    out = []
    for t in trades:
        ct = _parse_range_bound(t.get("closeTime"))
        if ct is None:
            continue
        if ct.date() in wanted:
            out.append(t)
    return out


# 2026-09-15, explicit operator request ("Add confirmation under Which Market Session, Volume Price,
# Pips & Price bot is taking the Profit and under which bot not taking the loss - add the Confirmation
# in trade history on dashboard"): groups the SAME closed trades _trades()/api_trades() already exposes
# by (Session, Volume Class, Pip/Price Class) - the exact three fields named in the request - and
# reports win/loss/win-rate/total P&L per group, so the operator can see which combination the bot
# actually profits under vs which it loses under, without eyeballing every row. Pure aggregation over
# already-computed fields (entrySession/volumeClass/pipPriceClass/pnl) - no new EA-side computation, no
# new data source. A trade missing any of the three dimensions (predates entrySession, or lacks
# volume/pip DNA) is grouped under "—" for that dimension rather than dropped - visible as its own row
# so gaps in historical coverage are honest, not silently hidden.
# 2026-09-16, explicit operator request (Date/Week/Month selection): now accepts an OPTIONAL
# range_preset ("today"/"week"/"month"/None or "all") - filters via the SAME _filter_trades() every
# other date-ranged view already uses, applied BEFORE grouping, so a narrower window only ever
# considers trades that closed within it.
# 2026-09-16, explicit operator request ("multi date" picker, confirmed via AskUserQuestion to sit
# ALONGSIDE the presets, not replace them): also accepts an OPTIONAL `dates` list (each "YYYY-MM-DD") -
# when given, this TAKES PRECEDENCE over range_preset (the frontend only ever sends one or the other,
# never both at once - see the panel's own "Pick Dates" vs preset-button mutual-exclusivity), applying
# the union-of-selected-calendar-days filter from _filter_trades_by_dates() instead of the preset window.
def _trade_breakdown_groups(range_preset: Optional[str] = None, dates: Optional[list[str]] = None) -> list[dict]:
    trades = _trades()
    if dates:
        trades = _filter_trades_by_dates(trades, dates)
    else:
        date_from, date_to = _range_bounds_for_preset(range_preset)
        if date_from or date_to:
            trades = _filter_trades(trades, date_from, date_to)
    groups: dict[tuple, dict] = {}
    for t in trades:
        # Only CLOSED trades have a meaningful win/loss outcome - an open position's "pnl" is its
        # current floating P&L, not a settled result, and would misclassify a currently-winning-but-
        # still-open trade as a permanent "win" for this bar-session/volume/pip combination.
        if not t.get("closeTime"):
            continue
        pnl = t.get("pnl")
        if pnl is None:
            continue
        key = (t.get("entrySession") or "—", t.get("volumeClass") or "—", t.get("pipPriceClass") or "—")
        g = groups.setdefault(key, {
            "session": key[0], "volumeClass": key[1], "pipPriceClass": key[2],
            "wins": 0, "losses": 0, "breakeven": 0, "totalPnl": 0.0,
            "_dnaM1Counts": {}, "_dnaM5Counts": {},
        })
        if pnl > 0:
            g["wins"] += 1
        elif pnl < 0:
            g["losses"] += 1
        else:
            g["breakeven"] += 1
        g["totalPnl"] += pnl
        # 2026-09-16, explicit operator request: tally each trade's own entry-time DNA regime (M1/M5,
        # from entryDnaStateM1/entryDnaStateM5 - see _trades()'s own header) per group, so the group's
        # displayed "DNA M1"/"DNA M5" is the MOST COMMON regime this session/volume/pip combination
        # actually traded under, not a single arbitrary trade's reading.
        dna_m1 = t.get("entryDnaStateM1") or "—"
        dna_m5 = t.get("entryDnaStateM5") or "—"
        g["_dnaM1Counts"][dna_m1] = g["_dnaM1Counts"].get(dna_m1, 0) + 1
        g["_dnaM5Counts"][dna_m5] = g["_dnaM5Counts"].get(dna_m5, 0) + 1

    out = []
    for g in groups.values():
        total = g["wins"] + g["losses"] + g["breakeven"]
        g["totalTrades"] = total
        g["winRate"] = round((g["wins"] / total) * 100.0, 1) if total > 0 else None
        g["totalPnl"] = round(g["totalPnl"], 2)
        dna_m1_counts = g.pop("_dnaM1Counts")
        dna_m5_counts = g.pop("_dnaM5Counts")
        g["dnaM1"] = max(dna_m1_counts, key=dna_m1_counts.get) if dna_m1_counts else "—"
        g["dnaM5"] = max(dna_m5_counts, key=dna_m5_counts.get) if dna_m5_counts else "—"
        out.append(g)
    # Most-active groups first (highest trade count), so the operator sees the statistically
    # meaningful combinations before single-trade noise.
    out.sort(key=lambda g: g["totalTrades"], reverse=True)
    return out


@app.get("/api/trades/breakdown")
async def api_trades_breakdown(range: Optional[str] = None, dates: Optional[str] = None) -> JSONResponse:
    # `dates` arrives as one comma-separated query param (e.g. "2026-09-10,2026-09-12") rather than a
    # repeated-key list - simpler for the frontend to build from an array of picked dates with
    # URLSearchParams, and avoids FastAPI's repeated-query-param list syntax for what's otherwise a very
    # simple case.
    date_list = [d for d in dates.split(",") if d.strip()] if dates else None
    return JSONResponse(_trade_breakdown_groups(range, date_list))


# 2026-09-16, explicit operator request ("also add option like trade history download it also have
# option download it" - confirmed via AskUserQuestion: a SEPARATE download button for the Performance
# Breakdown table, distinct from the existing Trade History "Export XLSX" button at /api/trades/export,
# which already covers the raw trade rows). Same query-param contract as /api/trades/breakdown itself
# (range OR dates, dates takes precedence) so "download what I'm currently looking at" holds exactly -
# calls the SAME _trade_breakdown_groups() the on-screen table renders from, never a second/independent
# aggregation.
@app.get("/api/trades/breakdown/export")
async def api_trades_breakdown_export(range: Optional[str] = None, dates: Optional[str] = None):
    from fastapi.responses import StreamingResponse
    import io
    from openpyxl import Workbook
    from openpyxl.styles import Font

    date_list = [d for d in dates.split(",") if d.strip()] if dates else None
    groups = _trade_breakdown_groups(range, date_list)

    wb = Workbook()
    ws = wb.active
    ws.title = "Performance Breakdown"
    headers = [
        "Session", "Vol Class", "Pip/Price Class", "DNA M1", "DNA M5",
        "Wins", "Losses", "Breakeven", "Total Trades", "Win Rate %", "Total P/L USD",
    ]
    ws.append(headers)
    for cell in ws[1]:
        cell.font = Font(bold=True)
    for g in groups:
        ws.append([
            g.get("session"), g.get("volumeClass"), g.get("pipPriceClass"),
            g.get("dnaM1"), g.get("dnaM5"),
            g.get("wins"), g.get("losses"), g.get("breakeven"), g.get("totalTrades"),
            g.get("winRate"), g.get("totalPnl"),
        ])
    for col in ws.columns:
        width = max((len(str(c.value)) if c.value is not None else 0) for c in col) + 2
        ws.column_dimensions[col[0].column_letter].width = min(width, 32)

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    filename = "performance_breakdown_" + datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S") + ".xlsx"
    return StreamingResponse(
        buf,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": 'attachment; filename="' + filename + '"'},
    )


@app.get("/api/equity/history")
async def api_equity_history(hours: Optional[int] = None) -> JSONResponse:
    points = _equity_series()
    if hours is not None:
        cutoff = datetime.now(timezone.utc) - timedelta(hours=hours)
        def _in_window(p):
            try:
                return datetime.fromisoformat(str(p.get("timestamp_iso", "")).replace("Z", "+00:00")) >= cutoff
            except Exception:
                return True
        points = [p for p in points if _in_window(p)] or points
    return JSONResponse(points)


@app.get("/api/cycles/recent")
async def api_cycles_recent(limit: Optional[int] = None) -> JSONResponse:
    # PLACEHOLDER - the EA's OnTick() cycle isn't logged to a bar-cycle
    # stream yet. Correctly-shaped empty result, not a fake history.
    return JSONResponse([])


@app.get("/api/price/history")
async def api_price_history(symbol: str, timeframe: str = "M1", bars: int = 100) -> JSONResponse:
    bars = max(bars, 1)
    minutes = TIMEFRAME_MINUTES.get(timeframe, 1)
    # Fetch enough underlying M1 bars to build `bars` candles at the
    # requested timeframe (plus a little slack for a partially-filled
    # trailing bucket).
    m1_rows = await _bars(symbol, "M1", bars * minutes + minutes)

    # 2026-09-11, explicit operator request (ACTIVE_PING chart highlight - "highlight in Red where
    # active, Green where not"): join active_ping.jsonl's own "active" flag onto each M1 bar by
    # barTime==time BEFORE aggregation, exactly the same "attach a per-bar field, then let
    # _aggregate_bars() carry it forward with close semantics" pattern dnaState already uses. New dict
    # per row (never mutates the underlying _bars_file()/_read_jsonl() cache) - a bar with no matching
    # active_ping.jsonl row (EA restart gap, or a row from before this feature existed) simply omits
    # the field, never a fabricated true/false.
    active_ping_map = _active_ping_by_bartime()
    if active_ping_map:
        # 2026-09-18, explicit operator request (ACTIVE_PING CHART OVERLAY - purple/light-yellow zones):
        # _active_ping_by_bartime() now returns {"active":bool,"corridorActive":bool} per bar time instead
        # of a bare bool - unpack both fields onto the row here rather than assigning the dict itself
        # (which would break _aggregate_bars()' own bool-typed carry-forward logic below).
        m1_rows = [
            {**row, "activePingActive": active_ping_map[row["time"]]["active"],
             "activePingCorridorActive": active_ping_map[row["time"]]["corridorActive"]}
            if row.get("time") in active_ping_map else row
            for row in m1_rows
        ]

    # Append the still-forming M1 candle (current_bar.json, overwritten by
    # the EA every tick) so the last candle on the chart updates live
    # instead of only refreshing once per minute on close. Appending it
    # after the closed rows means _aggregate_bars naturally extends/
    # overwrites whichever bucket (M1/M5/M15) it belongs to.
    current = _read_json(DATA_DIR / "current_bar.json", None)
    if current and current.get("time"):
        m1_rows = m1_rows + [current]

    agg = _aggregate_bars(m1_rows, minutes)
    return JSONResponse({"ok": True, "symbol": symbol, "timeframe": timeframe, "bars": agg[-bars:]})


# 2026-08-30, explicit operator request: explicit/canonical symbol mapping
# for historical lookups, NOT a generic regex like replace(/m$/, ''). The
# `bars` table has only ever stored "XAUUSDm" (confirmed via direct query);
# `trades.symbol` contains a mix of "XAUUSD" and "XAUUSDm" across different
# rows (a real, pre-existing broker-suffix inconsistency in the EA's own
# historical data, not something this task creates or fixes). This mapping
# exists ONLY to resolve which bars-table symbol a given trade's/request's
# symbol should query against - it never writes back to or modifies any
# existing database row.
CANONICAL_BAR_SYMBOL = {"XAUUSD": "XAUUSDm", "XAUUSDm": "XAUUSDm"}


def _resolve_bar_symbol(requested_symbol: str) -> str:
    return CANONICAL_BAR_SYMBOL.get(requested_symbol, requested_symbol)


@app.get("/api/price/history/before")
async def api_price_history_before(symbol: str, before: str, timeframe: str = "M1", bars: int = 300) -> JSONResponse:
    # 2026-08-30, explicit operator request: HISTORICAL-ONLY endpoint,
    # PostgreSQL-exclusive - never reads bars.jsonl, never falls back to
    # it. This is the counterpart to /api/price/history (which is now
    # EA-log-only, see _bars()'s own header) - the two endpoints together
    # implement "LIVE = EA log, HISTORICAL = PostgreSQL" as two genuinely
    # separate data paths, not one endpoint silently switching sources.
    bars = max(bars, 1)
    minutes = TIMEFRAME_MINUTES.get(timeframe, 1)
    before_dt = _parse_bar_time(before)
    if before_dt is None:
        return JSONResponse({"ok": False, "error": "invalid 'before' timestamp", "bars": [], "has_more": False}, status_code=400)

    bar_symbol = _resolve_bar_symbol(symbol)
    # Fetch enough underlying M1 bars for `bars` candles at the requested
    # timeframe, same slack logic as the live endpoint above.
    requested_m1 = bars * minutes + minutes
    m1_rows = await db.fetch_bars_before(bar_symbol, "M1", before_dt, requested_m1)

    if m1_rows is None:
        # PostgreSQL unreachable - an HONEST unavailable response, never a
        # silent substitution of the live JSONL rolling window (that would
        # violate the "historical must come from PostgreSQL only" rule).
        return JSONResponse({
            "ok": False, "error": "PostgreSQL unavailable - historical data cannot be loaded right now.",
            "symbol": symbol, "timeframe": timeframe, "bars": [], "has_more": False,
        })

    # has_more: a full page came back, so there may be still-older rows
    # beyond this page. Fewer than requested means Postgres has been
    # exhausted going further back - the true historical boundary.
    has_more = len(m1_rows) >= requested_m1
    agg = _aggregate_bars(m1_rows, minutes)
    return JSONResponse({
        "ok": True, "symbol": symbol, "timeframe": timeframe,
        "bars": agg[-bars:], "has_more": has_more,
    })


@app.get("/api/signal/latest")
async def api_signal_latest() -> JSONResponse:
    # Live path: the EA overwrites live_signal.json every tick with its
    # actual current direction/confidence/regime/dnaState/16-Mind Vote -
    # no text-log parsing needed. Falls back to the logs.jsonl-derived
    # heuristic below only when the EA isn't writing this file yet (demo).
    live = _read_json(DATA_DIR / "live_signal.json", None)
    if live is not None:
        return JSONResponse({
            "ok": True,
            "direction": live.get("direction", "NONE"),
            "confidence": live.get("confidence", 0.0),
            "regime": live.get("regime", "UNKNOWN"),
            "symbol": live.get("symbol", "XAUUSD"),
            "status": live.get("status", "no_data"),
            "gate_summary": {"master_enabled": True, "total": 6, "passed": 6 if live.get("status") == "approved" else 3},
            "minds": live.get("minds", []),
            "dnaState": live.get("dnaState", "NEUTRAL"),
            "dnaScore": live.get("dnaScore"),
            # 2026-09-01, explicit operator request ("show on the dashboard how many bars are being
            # used currently on Market DNA and Minds"): dnaBarsUsed/dnaBarsRequested/barsPoolAvailable
            # are written by the EA itself every tick (KMIE_MarketDNA_Lite.mq5's live_signal.json
            # writer, mirroring EvaluateMarketDNA()'s own k=min(Inp_MarketDNALookbackCandles, n)) -
            # passed through unchanged, never recomputed here. Each entry in "minds" above already
            # carries its own "candles" field from the same EA write - no extra work needed for
            # per-Mind bar usage, it rides along with the existing minds array.
            "dnaBarsUsed": live.get("dnaBarsUsed"),
            "dnaBarsRequested": live.get("dnaBarsRequested"),
            "barsPoolAvailable": live.get("barsPoolAvailable"),
            # 2026-09-16, M5 parallel pipeline (KMIE_MarketDNA_Lite.mq5, Inp_DnaTimeframeMode): sibling
            # M5 fields, same pure pass-through convention as every field above - the EA itself computes
            # g_dnaStateM5/g_dnaScoreM5/mindsM5 from its own parallel M5 DNA+18-Mind Vote pipeline and
            # writes them into this same live_signal.json; zero computation happens here.
            "dnaStateM5": live.get("dnaStateM5", "NEUTRAL"),
            "dnaScoreM5": live.get("dnaScoreM5"),
            "mindsM5": live.get("mindsM5", []),
            "dnaBarsUsedM5": live.get("dnaBarsUsedM5"),
            "dnaBarsRequestedM5": live.get("dnaBarsRequestedM5"),
            # 2026-09-23, M15 parallel pipeline (KMIE_MarketDNA_Lite.mq5): sibling M15 fields, same pure
            # pass-through convention as the M5 fields immediately above - the EA writes
            # g_dnaStateM15/g_dnaScoreM15/mindsM15 (its own fixed-8-bar M15 DNA+18-Mind Vote pipeline)
            # into this same live_signal.json; zero computation happens here. These were missing from
            # this endpoint entirely (the EA-side write existed, but this pass-through never forwarded
            # them to the frontend, which is why the dashboard's Market M15 cards showed nothing).
            "dnaStateM15": live.get("dnaStateM15", "NEUTRAL"),
            "dnaScoreM15": live.get("dnaScoreM15"),
            "mindsM15": live.get("mindsM15", []),
            "dnaBarsUsedM15": live.get("dnaBarsUsedM15"),
            "dnaBarsRequestedM15": live.get("dnaBarsRequestedM15"),
            "dnaTimeframeMode": live.get("dnaTimeframeMode", "M1_ONLY"),
        })

    logs = _logs(50)
    last_approval = None
    for entry in reversed(logs):
        if entry.get("tag") == "ENTRY_APPROVAL":
            last_approval = entry
            break
    if last_approval is None:
        return JSONResponse({
            "ok": True, "direction": "NONE", "confidence": 0.0, "regime": "UNKNOWN",
            "symbol": "XAUUSD", "status": "no_data", "minds": _demo_minds("BUY", 8),
            "dnaState": "NEUTRAL",
        })
    msg = str(last_approval.get("message", ""))
    import re
    ea_direction = (re.search(r"direction=(\w+)", msg) or [None, "NONE"])[1] if re.search(r"direction=(\w+)", msg) else "NONE"
    decision = (re.search(r"decision=(\w+)", msg) or [None, None])[1] if re.search(r"decision=(\w+)", msg) else None
    path = (re.search(r"path=(\w+)", msg) or [None, None])[1] if re.search(r"path=(\w+)", msg) else None
    # The original frontend's SignalPanel recognizes UP/DOWN/NONE (also
    # LONG/SHORT/PLACED/FLAT) for its direction colouring - not BUY/SELL.
    direction = {"BUY": "UP", "SELL": "DOWN"}.get(ea_direction, "NONE")
    # 16-Mind Vote breakdown (KMIE_MarketDNA_Lite.mq5's g_minds[16] /
    # MindResult: name/direction/score) - the EA's real signal source for
    # this bot, shown in the SignalPanel's "why this trade" section in
    # place of the original dashboard's HMM-gate rows (not applicable here).
    minds = _demo_minds(ea_direction if ea_direction in ("BUY", "SELL") else "BUY", 10 if decision == "APPROVED" else 6)
    # Market DNA state (KMIE_MarketDNA_Lite.mq5's g_dnaState / ENUM_LITE_DNA,
    # 18-state regime classifier that gates the 16-Mind Vote) - approximated
    # here from the entry path until the EA logs g_dnaState directly.
    dna_state = {"CONTINUATION": "STRONG_TREND", "PULLBACK": "PULLBACK"}.get(path, "NEUTRAL")
    return JSONResponse({
        "ok": True,
        "direction": direction,
        "confidence": 0.7 if decision == "APPROVED" else 0.3,
        "regime": path or "UNKNOWN",
        "symbol": "XAUUSD",
        "status": "approved" if decision == "APPROVED" else "blocked",
        "gate_summary": {"master_enabled": True, "total": 6, "passed": 6 if decision == "APPROVED" else 3},
        "minds": minds,
        "dnaState": dna_state,
        "dnaScore": 72.0 if decision == "APPROVED" else 48.0,
    })


# 2026-09-21, explicit operator request ("show that on dashboard as well" - the M5 Swing Breakeven
# pullback tracker rebuilt 2026-09-19, already visible live on the MT5 chart via DrawSwingBreakevenLine()
# in the EA itself). This is a LIVE, per-tick state (multiple transitions per minute, per the EA's own
# swing_breakeven.jsonl - see KMIE_MarketDNA_Lite.mq5's LogActivePingSwingBreakevenResult() for the
# writer), not a per-closed-bar value like active_ping.jsonl's corridorActive - so rather than joining it
# onto historical bars.jsonl rows (which would force it into a "closed at bar-close" semantic it doesn't
# actually have), this returns just the LATEST real row per direction, the same "poll the newest tail
# row" pattern /api/signal/latest already uses for live_signal.json. The frontend draws this as a live
# horizontal line overlay, mirroring the EA's own MT5 chart line - not baked into candle data.
@app.get("/api/swing-breakeven/latest")
async def api_swing_breakeven_latest() -> JSONResponse:
    rows = _tail_jsonl(DATA_DIR / "swing_breakeven.jsonl", 200, [])
    latest: dict[str, Optional[dict]] = {"BUY": None, "SELL": None}
    for row in rows:
        direction = row.get("direction")
        if direction in latest:
            latest[direction] = row
    return JSONResponse({"ok": True, "buy": latest["BUY"], "sell": latest["SELL"]})


# 2026-08-31, explicit operator request (MARKET DNA VISUAL LAB - READ-ONLY
# VISUALIZATION): exposes the EA's own dna_raw_scores.jsonl - the ONLY place all 25
# Market DNA states' scores are serialized (live_signal.json/bars.jsonl publish only
# the single argmax WINNER). This endpoint performs NO calculation of its own - it
# tails the most recent line(s) the EA already wrote (via _tail_jsonl(), safe against
# the file's real 500MB+ size) and passes the EA's own numbers straight through.
#
# IMPORTANT, confirmed during this feature's own pre-implementation audit: the "raw"
# object in this file is PRE-calibration (computed inside EvaluateMarketDNA() before
# CalibrateMarketDNAScores() runs) - it is NOT the same scale as g_dnaScore/dnaState
# (which are POST-calibration, from a strict argmax over the calibrated array). The
# two are not comparable and the raw scores do NOT necessarily agree with which DNA
# state actually won. The frontend must label this "RAW (pre-calibration)" and never
# present it as "the score that decided the winner" - see this endpoint's own
# "calibration_note" field, always populated, so the frontend has no excuse to omit
# the caveat.
#
# A second, distinct record type ("type":"structural_dna_calibrated") is written to
# the SAME file, less frequently, carrying REAL calibrated scores but only for 4 of
# the 25 states (strong_uptrend/strong_downtrend/uptrend/downtrend) plus the overall
# selected_live_dna/selected_live_score. Both the latest "raw" record and the latest
# "calibrated" record (if one exists in the tailed window) are returned separately -
# never merged into one object, so the frontend cannot accidentally conflate them.
@app.get("/api/dna/raw-scores")
async def api_dna_raw_scores() -> JSONResponse:
    # Tail window sized generously (200 lines) so a "calibrated" record (written less
    # often than "raw") is very likely present even though this endpoint always
    # returns only the SINGLE newest of each type - never a history/list from here.
    lines = _tail_jsonl(DATA_DIR / "dna_raw_scores.jsonl", 200, [])
    latest_raw = None
    latest_calibrated = None
    for entry in reversed(lines):
        if not isinstance(entry, dict):
            continue
        if entry.get("type") == "structural_dna_calibrated":
            if latest_calibrated is None:
                latest_calibrated = entry
        else:
            if latest_raw is None and isinstance(entry.get("raw"), dict):
                latest_raw = entry
        if latest_raw is not None and latest_calibrated is not None:
            break
    return JSONResponse({
        "ok": True,
        "raw": latest_raw,
        "calibrated": latest_calibrated,
        "calibration_note": (
            "raw scores are PRE-calibration (0-100 per-DNA evidence strength) and are "
            "NOT the scale g_dnaState/g_dnaScore are selected from - only 4 of 25 "
            "states (strong/weak uptrend/downtrend) have live calibrated scores; the "
            "rest are calibration-array defaults documented in the EA source as "
            "PLACEHOLDER, not real fitted values."
        ),
    })


# 2026-08-31, explicit operator request (MARKET DNA VISUAL LAB - REAL HISTORICAL M1
# DATA): every value the new /api/dna/visual-samples endpoint returns is derived from
# db.fetch_dna_history() (Postgres, the SAME market_dna column every other historical
# endpoint already reads via db._unpack_market_dna) - this module performs run-
# grouping/scoring/windowing on top of that real data, but computes NO Market DNA
# classification of its own. A DNA label on a sample always comes from that bar's own
# stored dnaState, never inferred from candle shape.
#
# CACHING (section 26's explicit performance requirement - "do not scan the entire
# historical dataset on every render"): the ~4-8k row Postgres scan + grouping runs at
# most once per _DNA_SAMPLES_CACHE_TTL_SECONDS, not once per request. A plain
# process-local dict is sufficient here (single-worker uvicorn, matching how this
# whole app is already run) - not a new caching framework.
_DNA_SAMPLES_CACHE: dict = {}
_DNA_SAMPLES_CACHE_TTL_SECONDS = 60

# 2026-08-31, explicit operator request (section 7 - "diagnose zero-sample states"):
# a state with 0 Postgres observations could mean (A) it genuinely never occurred,
# or (B) the raw formula computes non-zero evidence but never wins the calibrated
# argmax against stronger competing states that cycle - these are DIFFERENT findings
# and must be reported differently, never collapsed into one "0 occurrences" line.
# Distinguished by sampling dna_raw_scores.jsonl's tail (via the SAME _tail_jsonl
# safety wrapper used elsewhere - never a full 500MB+ read) for whether that state's
# RAW score is ever meaningfully non-zero. This is diagnostic-only: it does not
# affect which DNA a bar IS, does not change argmax, and is cached at process level
# (computed once, not per-request) since dna_raw_scores.jsonl's tail is a much
# heavier read than the small Postgres query the rest of this endpoint runs.
_ZERO_SAMPLE_DIAGNOSIS_CACHE: dict = {}


def _diagnose_zero_sample_reason(dna_name: str) -> str:
    if dna_name in _ZERO_SAMPLE_DIAGNOSIS_CACHE:
        return _ZERO_SAMPLE_DIAGNOSIS_CACHE[dna_name]
    lines = _tail_jsonl(DATA_DIR / "dna_raw_scores.jsonl", 300, [])
    max_seen = 0.0
    nonzero_count = 0
    total = 0
    for entry in lines:
        if not isinstance(entry, dict) or entry.get("type") == "structural_dna_calibrated":
            continue
        raw = entry.get("raw")
        if not isinstance(raw, dict):
            continue
        v = raw.get(dna_name)
        if isinstance(v, (int, float)):
            total += 1
            if v > max_seen:
                max_seen = v
            if v > 0:
                nonzero_count += 1
    if total == 0:
        reason = "Unable to sample dna_raw_scores.jsonl (file unavailable) - cannot distinguish 'never occurs' from 'never wins argmax'."
    elif max_seen < 1.0:
        reason = (
            f"Historical window 2026-08-24 -> 2026-08-28: 0 occurrences. Diagnostic (NOT scoped "
            f"to this window - sampled from the {total} most recent live ticks, max={max_seen:.2f}): "
            "this DNA's own formula is essentially never triggering under current live market "
            "conditions either, not merely losing to a stronger competitor. Genuine absence "
            "(cause A), not a pipeline bug."
        )
    else:
        reason = (
            f"Historical window 2026-08-24 -> 2026-08-28: 0 occurrences. Diagnostic (NOT scoped "
            f"to this window - sampled from the {total} most recent live ticks, max={max_seen:.2f}, "
            f"non-zero in {nonzero_count}/{total} samples): the EA computes real evidence for this "
            "DNA but it consistently loses the calibrated argmax to a stronger competing state "
            "(cause B, not a data pipeline bug - see main.py's own _diagnose_zero_sample_reason() "
            "for the sampling method)."
        )
    _ZERO_SAMPLE_DIAGNOSIS_CACHE[dna_name] = reason
    return reason


def _group_dna_runs(rows: list) -> list:
    """Group consecutive same-dnaState bars into runs. Each run:
    {dnaState, startIdx, endIdx, scores: [...], bars: [...]}. A bar with a
    null dnaState (the forming candle, or a gap) breaks the current run
    without starting a new one. Pure grouping - no scoring/selection here.
    """
    runs = []
    current = None
    for i, r in enumerate(rows):
        state = r.get("dnaState")
        if state is None:
            current = None
            continue
        if current is not None and current["dnaState"] == state and current["endIdx"] == i - 1:
            current["endIdx"] = i
            current["scores"].append(r.get("dnaScore"))
        else:
            current = {"dnaState": state, "startIdx": i, "endIdx": i, "scores": [r.get("dnaScore")]}
            runs.append(current)
    return runs


def _score_run_quality(run: dict, rows: list) -> tuple[float, str]:
    """Section 5's ranking criteria, applied to one run. Returns
    (numeric_rank_score, star_rating_label). Purely a SELECTION heuristic
    over already-published EA numbers (score strength + duration + data
    completeness) - never a new Market DNA formula, never affects which
    DNA a bar IS, only which historical occurrence is shown first.
    """
    scores = [s for s in run["scores"] if isinstance(s, (int, float))]
    avg_score = sum(scores) / len(scores) if scores else 0.0
    duration = run["endIdx"] - run["startIdx"] + 1
    # Duration credit saturates at 5 bars (a persistent-enough occurrence,
    # per section 5.2/5.3 - "not merely a one-bar transient") - beyond
    # that, more bars doesn't make a BETTER illustrative sample, just a
    # longer one already-served by the window padding below.
    duration_credit = min(duration, 5) / 5.0 * 100.0
    rank_score = avg_score * 0.65 + duration_credit * 0.35
    if rank_score >= 80 and duration >= 3:
        stars = "★★★★★"
    elif rank_score >= 65:
        stars = "★★★★☆"
    elif rank_score >= 45:
        stars = "★★★☆☆"
    elif rank_score >= 25:
        stars = "★★☆☆☆"
    else:
        stars = "★☆☆☆☆"
    return rank_score, stars


def _bar_gap_minutes(rows: list, i: int, j: int) -> float:
    try:
        t1 = datetime.fromisoformat(rows[i]["time"].replace("Z", "+00:00"))
        t2 = datetime.fromisoformat(rows[j]["time"].replace("Z", "+00:00"))
        return abs((t2 - t1).total_seconds()) / 60.0
    except Exception:
        return 0.0


def _build_sample_window(run: dict, rows: list, before: int = 20, after: int = 15) -> dict:
    """Real candle window around one run - section 4's "15-25 before + the
    classification bars + 10-20 after" - clamped to whatever real data
    actually exists on each side (never padded with fabricated candles).
    Every candle in the returned window is a literal row from `rows`
    (itself sourced from Postgres via db.fetch_dna_history()).

    IMPORTANT: the before/after padding walk also stops the instant it
    would cross a data gap bigger than 2 minutes (this dataset has real,
    confirmed multi-hour gaps - EA downtime / thin market periods) - a
    plain fixed index-count expansion would otherwise silently pull in
    candles from hours before/after the actual occurrence, which is
    misleading "context" even though every individual candle is real.
    """
    start = run["startIdx"]
    for _ in range(before):
        if start <= 0 or _bar_gap_minutes(rows, start - 1, start) > 2.0:
            break
        start -= 1
    end = run["endIdx"]
    for _ in range(after):
        if end >= len(rows) - 1 or _bar_gap_minutes(rows, end, end + 1) > 2.0:
            break
        end += 1
    end += 1  # slice-exclusive
    window_rows = rows[start:end]
    candles = [
        {"time": r["time"], "open": r["open"], "high": r["high"], "low": r["low"], "close": r["close"]}
        for r in window_rows
        # Section 10's candle-integrity gate - a row failing basic OHLC
        # geometry is EXCLUDED from the window, never repaired/guessed.
        if r["high"] is not None and r["low"] is not None and r["open"] is not None and r["close"] is not None
        and r["high"] >= max(r["open"], r["close"]) and r["low"] <= min(r["open"], r["close"])
    ]
    scores = [s for s in run["scores"] if isinstance(s, (int, float))]
    duration = run["endIdx"] - run["startIdx"] + 1
    rank_score, stars = _score_run_quality(run, rows)
    return {
        "timestamp": rows[run["startIdx"]]["time"],
        "windowStart": window_rows[0]["time"] if window_rows else rows[run["startIdx"]]["time"],
        "windowEnd": window_rows[-1]["time"] if window_rows else rows[run["endIdx"]]["time"],
        "score": (sum(scores) / len(scores)) if scores else None,
        "durationBars": duration,
        "candles": candles,
        # section 4's "BEFORE -> DNA OCCURRENCE -> AFTER" marker - indices
        # INTO the `candles` array above (not global row indices) marking
        # where the actual classified run sits inside this window, so the
        # frontend can draw a vertical marker without recomputing
        # anything. No gap can exist INSIDE this range by construction -
        # the before/after padding walk above stops the instant it would
        # cross a >2min gap, so every candle here is genuinely contiguous.
        "occurrenceStartIdx": run["startIdx"] - start,
        "occurrenceEndIdx": run["endIdx"] - start,
        "sampleQuality": stars,
        "dataType": "REAL_HISTORICAL",
    }


# 2026-08-31, explicit operator request (FIX HISTORICAL VISUALIZATION
# WINDOW): the Visual Lab's historical section is now pinned to this exact
# 5-day window - never derived from "now", never mixing in 08-23 or
# 08-29+ data. This is a data-selection change only; nothing about DNA
# formulas/calibration/argmax/Minds/execution is touched by it.
_DNA_LAB_HISTORICAL_START = datetime(2026, 8, 24, 0, 0, 0, tzinfo=timezone.utc)
_DNA_LAB_HISTORICAL_END = datetime(2026, 8, 28, 23, 59, 59, tzinfo=timezone.utc)


@app.get("/api/dna/visual-samples")
async def api_dna_visual_samples(
    date_from: str = "2026-08-24", symbol: str = "XAUUSDm", timeframe: str = "M1",
) -> JSONResponse:
    # 2026-08-31: same canonical-symbol resolution the existing historical
    # /api/price/history/before endpoint already uses - Postgres stores
    # bars under the broker's real suffixed symbol (XAUUSDm), while the
    # frontend's own chartSymbol state uses the plain display name
    # (XAUUSD). Without this, a request for "XAUUSD" silently matched
    # zero rows (confirmed live: 0 total bars) despite ~4000 real rows
    # existing under "XAUUSDm".
    symbol = _resolve_bar_symbol(symbol)
    # date_from/date_to are pinned server-side to the fixed historical
    # window (section 1: filtering happens at the backend data-selection
    # layer, not the frontend) - any incoming date_from query param is
    # intentionally ignored so the window can never drift or leak outside
    # 08-24 -> 08-28.
    since = _DNA_LAB_HISTORICAL_START
    until = _DNA_LAB_HISTORICAL_END
    date_from = since.strftime("%Y-%m-%dT%H:%M:%SZ")
    cache_key = (date_from, symbol, timeframe)
    cached = _DNA_SAMPLES_CACHE.get(cache_key)
    now_ts = datetime.now(timezone.utc).timestamp()
    if cached is not None and (now_ts - cached["_cachedAt"]) < _DNA_SAMPLES_CACHE_TTL_SECONDS:
        return JSONResponse(cached["_payload"])

    rows = await db.fetch_dna_history(symbol, timeframe, since, until)
    if rows is None:
        return JSONResponse({
            "ok": False,
            "error": "PostgreSQL unavailable - historical Market DNA samples require the database (bars.jsonl alone does not carry enough back-history for this range).",
            "dateFrom": date_from, "dateTo": until.strftime("%Y-%m-%dT%H:%M:%SZ"), "symbol": symbol, "timeframe": timeframe,
        })

    # Data-quality audit (section 8/12/25) - computed once, over the SAME
    # rows everything else below uses, never re-derived per-DNA.
    total_bars = len(rows)
    missing_bars = 0
    duplicate_timestamps = 0
    invalid_ohlc = 0
    largest_gap_minutes = 0.0
    largest_gap_at = None
    seen_times = set()
    prev_time = None
    for r in rows:
        t = r["time"]
        if t in seen_times:
            duplicate_timestamps += 1
        seen_times.add(t)
        if prev_time is not None:
            try:
                delta_min = (datetime.fromisoformat(t.replace("Z", "+00:00")) - datetime.fromisoformat(prev_time.replace("Z", "+00:00"))).total_seconds() / 60.0
                if delta_min > 1.5:
                    missing_bars += int(round(delta_min)) - 1
                if delta_min > largest_gap_minutes:
                    largest_gap_minutes = delta_min
                    largest_gap_at = prev_time
            except Exception:
                pass
        prev_time = t
        if r["high"] is None or r["low"] is None or r["open"] is None or r["close"] is None:
            invalid_ohlc += 1
        elif not (
            r["low"] <= r["open"] and r["low"] <= r["close"]
            and r["high"] >= r["open"] and r["high"] >= r["close"]
            and r["high"] >= r["low"]
        ):
            invalid_ohlc += 1

    runs = _group_dna_runs(rows)
    by_state: dict = {}
    for run in runs:
        by_state.setdefault(run["dnaState"], []).append(run)

    states_out = []
    for dna_name in MARKET_DNA_STATE_ORDER:
        state_runs = by_state.get(dna_name, [])
        observations = len(state_runs)
        if observations == 0:
            states_out.append({
                "dna": dna_name, "observations": 0, "bestScore": None,
                "bestSample": None, "alternates": [], "longestRunBars": 0,
                "note": "NO REAL SAMPLE FOUND in 2026-08-24 -> 2026-08-28 (0 observations)",
                "zeroSampleReason": _diagnose_zero_sample_reason(dna_name),
            })
            continue
        ranked = sorted(state_runs, key=lambda run: _score_run_quality(run, rows)[0], reverse=True)
        top = ranked[:3]
        samples = [_build_sample_window(run, rows) for run in top]
        best_scores = [s["score"] for s in samples if s["score"] is not None]
        longest_run = max((r["endIdx"] - r["startIdx"] + 1) for r in state_runs)
        states_out.append({
            "dna": dna_name,
            "observations": observations,
            "bestScore": max(best_scores) if best_scores else None,
            "bestSample": samples[0] if samples else None,
            "alternates": samples[1:] if len(samples) > 1 else [],
            "longestRunBars": longest_run,
        })

    states_out.sort(key=lambda s: MARKET_DNA_STATE_ORDER.index(s["dna"]) if s["dna"] in MARKET_DNA_STATE_ORDER else 999)

    payload = {
        "ok": True,
        "dateFrom": since.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "dateTo": until.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "symbol": symbol,
        "timeframe": timeframe,
        "dataType": "REAL_HISTORICAL",
        "coverage": {
            "totalBars": total_bars,
            "earliestTimestamp": rows[0]["time"] if rows else None,
            "latestTimestamp": rows[-1]["time"] if rows else None,
            "missingBarsEstimate": missing_bars,
            "duplicateTimestamps": duplicate_timestamps,
            "invalidOhlcRows": invalid_ohlc,
            "largestGapMinutes": round(largest_gap_minutes, 1),
            "largestGapAt": largest_gap_at,
            "totalDnaObservations": sum(s["observations"] for s in states_out),
            "syntheticCandleCount": 0,  # section 12/16's explicit expected value - this pipeline never generates a candle; always literally 0, never computed
        },
        # section 11 - dynamic 25-DNA overview, computed from the SAME
        # states_out every tile/table already renders, never hardcoded.
        "overview": {
            "totalDnaStates": len(states_out),
            "withRealSamples": sum(1 for s in states_out if s["observations"] > 0),
            "withoutRealSamples": sum(1 for s in states_out if s["observations"] == 0),
        },
        "states": states_out,
    }
    _DNA_SAMPLES_CACHE[cache_key] = {"_payload": payload, "_cachedAt": now_ts}
    return JSONResponse(payload)


@app.get("/api/audit/log")
async def api_audit_log(
    date: Optional[str] = None, category: Optional[str] = None,
    severity: Optional[str] = None, limit: int = 100, offset: int = 0,
    search: Optional[str] = None,
) -> JSONResponse:
    logs = _logs(limit)
    items = [
        {
            "audit_id": str(i),
            "timestamp": e.get("time"),
            "action": e.get("tag", "LOG"),
            "result": "SUCCESS",
            "severity": "INFO",
        }
        for i, e in enumerate(reversed(logs))
    ]
    return JSONResponse({"ok": True, "items": items, "total": len(items)})


@app.get("/api/audit/summary/today")
async def api_audit_summary_today() -> JSONResponse:
    return JSONResponse({"ok": True, "total_today": len(_logs(1000))})


@app.get("/api/telemetry/recent")
async def api_telemetry_recent(limit: int = 50) -> JSONResponse:
    # PLACEHOLDER - no per-bar telemetry stream from the EA yet.
    return JSONResponse({"ok": True, "items": []})


@app.get("/api/telemetry/summary")
async def api_telemetry_summary() -> JSONResponse:
    return JSONResponse({
        "ok": True,
        "decision_rows_today": 0, "rejection_rows_today": 0, "outcome_rows_today": 0,
        "ema_flip_count": 0, "avg_cp_agreements": 0,
        "last_signal_id": None, "last_signal_timestamp": None,
        "telemetry_alive": False, "last_row_age_seconds": None,
    })


@app.get("/api/audit/entry/{audit_id}")
async def api_audit_entry(audit_id: str, date: Optional[str] = None) -> JSONResponse:
    return JSONResponse({"ok": False, "error": "audit_id not found"}, status_code=404)


@app.get("/api/audit/trace/{request_id}")
async def api_audit_trace(request_id: str, date: Optional[str] = None) -> JSONResponse:
    return JSONResponse({"ok": True, "request_id": request_id, "items": []})


@app.get("/api/audit/export")
async def api_audit_export(date: Optional[str] = None) -> PlainTextResponse:
    body = "\n".join(json.dumps(e) for e in _logs(1000))
    return PlainTextResponse(body, media_type="application/x-jsonlines")


@app.get("/api/alerts/db")
async def api_alerts_db(include_dismissed: bool = False, limit: int = 50) -> JSONResponse:
    return JSONResponse({"ok": True, "items": [], "active_counts_by_severity": {}})


@app.post("/api/alerts/{alert_id}/dismiss")
async def api_alerts_dismiss(alert_id: str, request: Request) -> JSONResponse:
    return JSONResponse({"ok": True, "dismissed": True})


@app.delete("/api/alerts/clear-all")
async def api_alerts_clear_all(request: Request) -> JSONResponse:
    return JSONResponse({"ok": True, "dismissed_count": 0})


@app.post("/api/control/halt")
async def api_control_halt(request: Request) -> JSONResponse:
    # In-memory only - nothing real to halt yet. A genuine toggle, not a
    # dead button, so the UI behaves exactly like the original.
    _halted["value"] = True
    return JSONResponse({"ok": True, "is_halted": True})


@app.post("/api/control/resume")
async def api_control_resume(request: Request) -> JSONResponse:
    _halted["value"] = False
    return JSONResponse({"ok": True, "is_halted": False})


@app.get("/api/mos/status")
async def api_mos_status() -> JSONResponse:
    return JSONResponse({"ok": False, "error": "mos_infra not applicable to this dashboard"})


@app.get("/api/health")
async def api_health() -> JSONResponse:
    return JSONResponse({
        "ok": True,
        "log_dir_exists": DATA_DIR.exists(),
        "log_dir": str(DATA_DIR),
        "halt_state_path_exists": False,
        "live_state_path_exists": (DATA_DIR / "positions.json").exists(),
        "dashboard_started_at_iso": started_at.isoformat(),
    })


@app.get("/api/db/status")
async def api_db_status() -> JSONResponse:
    pool = await db.get_pool()
    if pool is None:
        return JSONResponse({
            "ok": True, "connected": False,
            "reason": "DATABASE_URL not set or connection failed - dashboard is reading data/*.json(l) directly.",
        })
    async with pool.acquire() as conn:
        counts = {}
        for table in ("bars", "trades", "logs", "equity", "positions", "live_signal"):
            counts[table] = await conn.fetchval(f"SELECT count(*) FROM {table}")
    return JSONResponse({
        "ok": True, "connected": True,
        "sync_interval_seconds": _SYNC_INTERVAL_SECONDS,
        "row_counts": counts,
    })


# ---------------------------------------------------------------------------
# Static frontend - mounted at /static (matching the original's own mount
# point; the copied index.html references /static/vendor/... directly).
# ---------------------------------------------------------------------------

if STATIC_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


@app.get("/", response_class=HTMLResponse)
async def index() -> HTMLResponse:
    index_path = STATIC_DIR / "index.html"
    if not index_path.exists():
        return HTMLResponse("<!doctype html><html><body>index.html missing</body></html>", status_code=500)
    return HTMLResponse(index_path.read_text(encoding="utf-8"))
